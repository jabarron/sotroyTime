// =============================================================================
// main.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// The application entry point. Runs ONCE when the page loads.
// Responsibilities (in order):
//   1. Create and configure the canvas (retina resolution fix)
//   2. Create the global Game namespace
//   3. Initialize every system in dependency order
//   4. Attach global event listeners (visibility, orientation, back button)
//   5. Start the game loop
//   6. Handle all canvas-level tap/click/move events and route them
//
// This file is loaded LAST in index.html — after every other script.
// By the time this runs, every other Game.* module is already defined.
// =============================================================================

(function() {
  'use strict';

  // ---------------------------------------------------------------------------
  // WAIT FOR DOM
  // ---------------------------------------------------------------------------
  document.addEventListener('DOMContentLoaded', function() {
    init();
  });

  // ---------------------------------------------------------------------------
  // INIT
  // The full initialization sequence.
  // ---------------------------------------------------------------------------
  function init() {

    console.log('main.js: Initializing iWillGetToYou...');

    // -------------------------------------------------------------------------
    // STEP 1: Canvas setup
    // -------------------------------------------------------------------------
    const canvas = document.getElementById('game-canvas');
    if (!canvas) {
      console.error('main.js: Canvas element #game-canvas not found.');
      return;
    }

    const ctx = canvas.getContext('2d');

    // --- Retina / HiDPI resolution fix ---
    // On high-density screens (Retina, OLED phones), 1 CSS pixel = 2+ device pixels.
    // Without this fix, all sprites and text look blurry on modern phones.
    const dpr  = window.devicePixelRatio || 1;
    const C    = window.Game.constants;
    const logW = C.CANVAS_WIDTH;    // logical (CSS) size
    const logH = C.CANVAS_HEIGHT;

    // Set canvas internal resolution to device pixels
    canvas.width  = logW * dpr;
    canvas.height = logH * dpr;

    // Set CSS display size (what the user sees)
    canvas.style.width  = logW + 'px';
    canvas.style.height = logH + 'px';

    // Scale the context so all drawing commands use logical coordinates
    // (you draw at 640, it renders at 1280 on a 2x screen — sharp)
    ctx.scale(dpr, dpr);

    // Disable image smoothing — critical for pixel art sprites to stay crisp
    ctx.imageSmoothingEnabled = false;

    // -------------------------------------------------------------------------
    // STEP 2: Attach canvas and context to global Game namespace
    // -------------------------------------------------------------------------
    window.Game.canvas = canvas;
    window.Game.ctx    = ctx;

    console.log(`main.js: Canvas ${logW}×${logH} (DPR: ${dpr}, physical: ${canvas.width}×${canvas.height})`);

    // -------------------------------------------------------------------------
    // STEP 3: Initialize all systems in dependency order
    // constants.js already ran — Game.constants is available
    // stateManager.js already ran — Game.state is available
    // -------------------------------------------------------------------------

    // Save system — load persisted data from localStorage
    if (window.Game.save) {
      window.Game.save.load();
    }

    // Particle pool pre-allocation
    if (window.Game.particles) {
      window.Game.particles.init();
    }

    // Audio system — creates HTMLAudioElement objects, reads mute pref
    if (window.Game.audio) {
      window.Game.audio.init();
    }

    // Input system — attaches touch and keyboard listeners to DOM buttons
    if (window.Game.controls) {
      window.Game.controls.init();
    }

    // -------------------------------------------------------------------------
    // STEP 4: Set up splash screen enter handler
    // The first state is SPLASH — tell it to begin
    // -------------------------------------------------------------------------
    if (window.Game.screens && window.Game.screens.splash) {
      window.Game.screens.splash.enter();
    }

    // -------------------------------------------------------------------------
    // STEP 5: Attach global event listeners
    // -------------------------------------------------------------------------

    // --- Tab visibility change — pause when player switches away ---
    document.addEventListener('visibilitychange', function() {
      if (document.hidden) {
        // Tab is hidden — pause if currently playing
        if (window.Game.state.current === 'GAMEPLAY') {
          window.Game.state.transition('PAUSED');
          // Enter pause menu screen
          if (window.Game.screens.pauseMenu) {
            window.Game.screens.pauseMenu.enter();
          }
        }
      }
    });

    // --- Browser back button intercept ---
    // Prevents accidental navigation away from the game mid-play.
    // Push a dummy history state so back button triggers popstate, not navigation.
    history.pushState({ game: true }, '', window.location.href);
    window.addEventListener('popstate', function(e) {
      // Re-push so back button never leaves the page
      history.pushState({ game: true }, '', window.location.href);

      // Treat back button as pause during gameplay
      if (window.Game.state.current === 'GAMEPLAY') {
        window.Game.state.transition('PAUSED');
        if (window.Game.screens.pauseMenu) {
          window.Game.screens.pauseMenu.enter();
        }
      } else if (window.Game.state.current === 'PAUSED') {
        window.Game.state.transition('GAMEPLAY');
      }
    });

    // --- Orientation change — show rotation warning if portrait ---
    window.addEventListener('orientationchange', function() {
      setTimeout(checkOrientation, 200);   // slight delay for OS to finish rotating
    });
    window.addEventListener('resize', checkOrientation);

    // -------------------------------------------------------------------------
    // STEP 6: Canvas input routing
    // Routes tap/click/move events from the canvas to the correct screen handler.
    // -------------------------------------------------------------------------
    setupInputRouting(canvas, ctx, dpr);

    // -------------------------------------------------------------------------
    // STEP 7: Loading state hook
    // When state transitions to LOADING, start the preloader.
    // We patch stateManager._onEnter to intercept the LOADING state.
    // -------------------------------------------------------------------------
    const originalOnEnter = window.Game.state._onEnter.bind(window.Game.state);
    window.Game.state._onEnter = function(state) {
      originalOnEnter(state);

      if (state === 'LOADING') {
        const gender = window.Game.state.selectedGender || 'male';

        // Start loading assets for the selected gender path
        window.Game.preloader.load(gender, function() {
          // All assets loaded — advance to main menu
          console.log('main.js: Assets loaded. Advancing to MAIN_MENU.');

          // Enter the main menu screen
          if (window.Game.screens.mainMenu) {
            window.Game.screens.mainMenu.enter();
          }

          window.Game.state.transition('MAIN_MENU');
        });
      }

      if (state === 'CUTSCENE_INTRO') {
        if (window.Game.screens.cutscene) {
          window.Game.screens.cutscene.enter('intro');
        }
      }

      if (state === 'CUTSCENE_OUTRO') {
        if (window.Game.screens.cutscene) {
          window.Game.screens.cutscene.enter('outro');
        }
      }

      if (state === 'GENDER_SELECT') {
        if (window.Game.screens.genderSelect) {
          window.Game.screens.genderSelect.enter();
        }
      }

      if (state === 'LEVEL_SELECT') {
        if (window.Game.screens.levelSelect) {
          window.Game.screens.levelSelect.enter();
        }
      }

      if (state === 'PAUSED') {
        if (window.Game.screens.pauseMenu) {
          window.Game.screens.pauseMenu.enter();
        }
      }

      if (state === 'LEVEL_COMPLETE') {
        if (window.Game.screens.levelComplete) {
          window.Game.screens.levelComplete.enter();
        }
      }

      if (state === 'GAME_OVER') {
        if (window.Game.screens.gameOver) {
          window.Game.screens.gameOver.enter();
        }
      }

      if (state === 'CREDITS' || state === 'VICTORY') {
        if (window.Game.screens.victory) {
          window.Game.screens.victory.enter();
        }
      }
    };

    // -------------------------------------------------------------------------
    // STEP 8: Start the game loop — everything is ready
    // -------------------------------------------------------------------------
    window.Game.loop.start();

    // Initial orientation check
    checkOrientation();

    console.log('main.js: Initialization complete. Game loop running.');
  }

  // ---------------------------------------------------------------------------
  // SETUP INPUT ROUTING
  // All canvas touch and mouse events are captured here and dispatched to
  // the correct screen handler based on the current game state.
  // ---------------------------------------------------------------------------
  function setupInputRouting(canvas, ctx, dpr) {

    // Convert raw event coordinates to canvas logical coordinates
    function getCanvasCoords(e) {
      const rect    = canvas.getBoundingClientRect();
      const scaleX  = window.Game.constants.CANVAS_WIDTH  / rect.width;
      const scaleY  = window.Game.constants.CANVAS_HEIGHT / rect.height;

      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;

      return {
        x: (clientX - rect.left) * scaleX,
        y: (clientY - rect.top)  * scaleY,
      };
    }

    // Dispatch tap to the correct screen
    function handleTap(coords) {
      const state   = window.Game.state.current;
      const screens = window.Game.screens;

      switch (state) {
        case 'SPLASH':
          if (screens.splash) screens.splash.handleTap();
          break;
        case 'GENDER_SELECT':
          if (screens.genderSelect) screens.genderSelect.handleTap(coords.x, coords.y);
          break;
        case 'MAIN_MENU':
          if (screens.mainMenu) screens.mainMenu.handleTap(coords.x, coords.y);
          break;
        case 'LEVEL_SELECT':
          if (screens.levelSelect) screens.levelSelect.handleTap(coords.x, coords.y);
          break;
        case 'CUTSCENE_INTRO':
        case 'CUTSCENE_OUTRO':
          if (screens.cutscene) screens.cutscene.handleTap();
          break;
        case 'PAUSED':
          if (screens.pauseMenu) screens.pauseMenu.handleTap(coords.x, coords.y);
          break;
        case 'LEVEL_COMPLETE':
          if (screens.levelComplete) screens.levelComplete.handleTap(coords.x, coords.y);
          break;
        case 'GAME_OVER':
          if (screens.gameOver) screens.gameOver.handleTap(coords.x, coords.y);
          break;
        case 'CREDITS':
        case 'VICTORY':
          if (screens.victory) screens.victory.handleTap(coords.x, coords.y);
          break;
        // GAMEPLAY taps are handled by the DOM buttons (controls.js)
        // not by canvas click — so no case needed here for GAMEPLAY
      }
    }

    // Dispatch hover/move (for desktop hover effects)
    function handleMove(coords) {
      const state   = window.Game.state.current;
      const screens = window.Game.screens;

      if (state === 'GENDER_SELECT' && screens.genderSelect) {
        screens.genderSelect.handleMove(coords.x, coords.y);
      }
    }

    // Touch events (mobile primary)
    canvas.addEventListener('touchstart', function(e) {
      e.preventDefault();
      const coords = getCanvasCoords(e);
      handleTap(coords);
    }, { passive: false });

    canvas.addEventListener('touchmove', function(e) {
      e.preventDefault();
    }, { passive: false });

    canvas.addEventListener('touchend', function(e) {
      e.preventDefault();
    }, { passive: false });

    // Mouse events (desktop testing)
    canvas.addEventListener('mousedown', function(e) {
      const coords = getCanvasCoords(e);
      handleTap(coords);
    });

    canvas.addEventListener('mousemove', function(e) {
      const coords = getCanvasCoords(e);
      handleMove(coords);
    });
  }

  // ---------------------------------------------------------------------------
  // CHECK ORIENTATION
  // Shows a rotation warning overlay if the device is in portrait mode.
  // The overlay is a DOM element (not canvas) for reliable display.
  // ---------------------------------------------------------------------------
  function checkOrientation() {
    const isPortrait = window.innerHeight > window.innerWidth;
    const warning    = document.getElementById('rotation-warning');

    if (warning) {
      warning.style.display = isPortrait ? 'flex' : 'none';

      // Pause the game when showing the warning
      if (isPortrait && window.Game.state.current === 'GAMEPLAY') {
        window.Game.state.transition('PAUSED');
        if (window.Game.screens.pauseMenu) {
          window.Game.screens.pauseMenu.enter();
        }
      }
    }
  }

})();
