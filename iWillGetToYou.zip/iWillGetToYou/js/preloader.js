// =============================================================================
// preloader.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Loads every image asset before the game starts.
// Shows a progress bar during loading.
// Audio is loaded separately by audio.js.
// Nothing draws a sprite until preloader.ready === true.
//
// Called after gender select. The loading screen state is active while this runs.
// When complete, calls its onComplete callback to advance the state.
// =============================================================================

window.Game = window.Game || {};

window.Game.preloader = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  ready:    false,    // true when ALL assets are loaded
  progress: 0,        // 0.0 to 1.0 — drives the loading bar width
  total:    0,        // total number of assets to load
  loaded:   0,        // number of assets successfully loaded so far

  // ---------------------------------------------------------------------------
  // ASSET REGISTRY
  // Populated after load() completes.
  // Every system that draws an image reads from here — never loads its own.
  // ---------------------------------------------------------------------------
  assets: {
    sprites: {},      // character sprites
    tiles:   {},      // environment tiles
    collect: {},      // rings, checkpoint ring
    ui:      {},      // HUD icons, doors, logo
  },

  // ---------------------------------------------------------------------------
  // ASSET MANIFEST
  // Defines WHAT to load and WHERE to put it.
  // Path is relative to index.html.
  // key is the name used to access it via preloader.assets.category.key
  // ---------------------------------------------------------------------------
  _manifest(gender) {
    // Currently only male path assets — female path added in a future build
    return [

      // --- Player sprites ---
      { category: 'sprites', key: 'idle',        path: 'assets/sprites/male/spacesuit_idle.svg'  },
      { category: 'sprites', key: 'run',         path: 'assets/sprites/male/spacesuit_run.svg'   },
      { category: 'sprites', key: 'jump',        path: 'assets/sprites/male/spacesuit_jump.svg'  },
      { category: 'sprites', key: 'dash',        path: 'assets/sprites/male/spacesuit_dash.svg'  },
      { category: 'sprites', key: 'death',       path: 'assets/sprites/male/spacesuit_death.svg' },

      // --- Environment tiles ---
      { category: 'tiles',   key: 'floor',       path: 'assets/tiles/male/tile_floor.svg'   },
      { category: 'tiles',   key: 'wall',        path: 'assets/tiles/male/tile_wall.svg'    },
      { category: 'tiles',   key: 'ceiling',     path: 'assets/tiles/male/tile_ceiling.svg' },

      // --- Collectibles ---
      { category: 'collect', key: 'ring',        path: 'assets/collectibles/ring.svg'             },
      { category: 'collect', key: 'checkpoint',  path: 'assets/collectibles/ring_checkpoint.svg'  },
      { category: 'collect', key: 'doorLocked',  path: 'assets/collectibles/door_locked.svg'      },
      { category: 'collect', key: 'doorOpen',    path: 'assets/collectibles/door_open.svg'        },

      // --- UI / HUD ---
      { category: 'ui',      key: 'logo',        path: 'assets/ui/logo_ji.svg'      },
      { category: 'ui',      key: 'heartFull',   path: 'assets/ui/heart_full.svg'   },
      { category: 'ui',      key: 'heartEmpty',  path: 'assets/ui/heart_empty.svg'  },
      { category: 'ui',      key: 'ringIcon',    path: 'assets/ui/ring_icon.svg'    },
      { category: 'ui',      key: 'starFull',    path: 'assets/ui/star_full.svg'    },
      { category: 'ui',      key: 'starEmpty',   path: 'assets/ui/star_empty.svg'   },
    ];
  },

  // ---------------------------------------------------------------------------
  // LOAD
  // Starts loading all assets for the given gender path.
  // onComplete is called when every asset has loaded (or failed gracefully).
  // ---------------------------------------------------------------------------
  load(gender, onComplete) {

    this.ready    = false;
    this.progress = 0;
    this.loaded   = 0;

    const manifest = this._manifest(gender);
    this.total = manifest.length;

    if (this.total === 0) {
      // Nothing to load — go straight to complete
      this.ready    = true;
      this.progress = 1;
      onComplete();
      return;
    }

    // Load each asset as an HTMLImageElement
    manifest.forEach(item => {
      const img = new Image();

      img.onload = () => {
        // Success — store the loaded image in the correct category
        this.assets[item.category][item.key] = img;
        this._onAssetLoaded(onComplete);
      };

      img.onerror = () => {
        // Failure — log the error but don't block the game
        // SVG placeholders should never fail, but graceful handling is important
        console.warn(`preloader: Failed to load "${item.path}". Using null.`);
        this.assets[item.category][item.key] = null;
        this._onAssetLoaded(onComplete);
      };

      // Start loading — assigning src triggers the browser fetch
      img.src = item.path;
    });
  },

  // ---------------------------------------------------------------------------
  // _onAssetLoaded (private)
  // Called each time one asset finishes (success or failure).
  // Updates progress and calls onComplete when all are done.
  // ---------------------------------------------------------------------------
  _onAssetLoaded(onComplete) {
    this.loaded++;
    this.progress = this.loaded / this.total;   // 0.0 → 1.0

    if (this.loaded >= this.total) {
      // All assets accounted for
      this.ready = true;
      console.log(`preloader: All ${this.total} assets loaded.`);

      // Small delay so the progress bar visually completes before advancing
      setTimeout(onComplete, 200);
    }
  },

  // ---------------------------------------------------------------------------
  // DRAW LOADING SCREEN
  // Called by game.js every frame while state === 'LOADING'.
  // Draws the progress bar directly on the canvas.
  // ---------------------------------------------------------------------------
  drawLoadingScreen(ctx) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    // --- Background: deep space black ---
    ctx.fillStyle = '#0a0a1a';
    ctx.fillRect(0, 0, cw, ch);

    // --- "Loading..." label ---
    ctx.fillStyle    = 'rgba(255,255,255,0.6)';
    ctx.font         = '20px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Loading...', cw / 2, ch / 2 - 40);

    // --- Progress bar background ---
    const barW = 360;
    const barH = 8;
    const barX = (cw - barW) / 2;
    const barY = ch / 2;

    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    ctx.beginPath();
    ctx.roundRect(barX, barY, barW, barH, 4);
    ctx.fill();

    // --- Progress bar fill (glowing white) ---
    const fillW = Math.max(0, barW * this.progress);
    if (fillW > 0) {
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.roundRect(barX, barY, fillW, barH, 4);
      ctx.fill();
    }

    // --- Percentage label ---
    ctx.fillStyle    = 'rgba(255,255,255,0.4)';
    ctx.font         = '14px "Roboto", sans-serif';
    ctx.fillText(
      Math.round(this.progress * 100) + '%',
      cw / 2,
      ch / 2 + 30
    );
  },

};
