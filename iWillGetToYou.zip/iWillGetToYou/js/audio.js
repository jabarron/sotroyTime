// =============================================================================
// audio.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// ALL audio goes through this file. No other file plays sound directly.
// Handles:
//   - iOS Safari audio unlock (requires first user tap)
//   - Background music looping
//   - Sound effect playback
//   - Mute toggle (saved to localStorage)
//   - Volume control per category (music vs sfx)
// =============================================================================

window.Game = window.Game || {};

window.Game.audio = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  unlocked: false,    // iOS gate — audio cannot play until first user tap
  muted:    false,    // player-controlled mute toggle
  
  // Currently playing music track name (so we don't restart the same track)
  _currentMusic: null,

  // ---------------------------------------------------------------------------
  // AUDIO ELEMENTS
  // Each sound is a pre-created HTMLAudioElement.
  // Populated by init() — nothing plays before init() runs.
  // ---------------------------------------------------------------------------
  tracks: {},

  // ---------------------------------------------------------------------------
  // MANIFEST
  // Defines every audio file the game uses.
  // path is relative to index.html.
  // ---------------------------------------------------------------------------
  _manifest: [
    // Music (loops)
    { key: 'music_level1',    path: 'assets/audio/music/male_level1.mp3',     loop: true  },

    // Sound effects (play once)
    { key: 'jump',            path: 'assets/audio/sfx/jump.mp3',              loop: false },
    { key: 'double_jump',     path: 'assets/audio/sfx/double_jump.mp3',       loop: false },
    { key: 'dash',            path: 'assets/audio/sfx/dash.mp3',              loop: false },
    { key: 'collect',         path: 'assets/audio/sfx/collect.mp3',           loop: false },
    { key: 'checkpoint',      path: 'assets/audio/sfx/checkpoint.mp3',        loop: false },
    { key: 'death',           path: 'assets/audio/sfx/death.mp3',             loop: false },
    { key: 'level_complete',  path: 'assets/audio/sfx/level_complete.mp3',    loop: false },
    { key: 'game_over',       path: 'assets/audio/sfx/game_over.mp3',         loop: false },
    { key: 'door_unlock',     path: 'assets/audio/sfx/door_unlock.mp3',       loop: false },
    { key: 'timer_warning',   path: 'assets/audio/sfx/timer_warning.mp3',     loop: false },
  ],

  // ---------------------------------------------------------------------------
  // INIT
  // Creates all HTMLAudioElement objects and sets volumes.
  // Does NOT play anything yet.
  // Called once by main.js on startup.
  // ---------------------------------------------------------------------------
  init() {
    const C = window.Game.constants;

    this._manifest.forEach(item => {
      const audio = new Audio();

      // Preload the audio file metadata (faster first play)
      audio.preload = 'auto';
      audio.loop    = item.loop;

      // Set volume based on category
      audio.volume  = item.loop ? C.MUSIC_VOLUME : C.SFX_VOLUME;

      // Assign the source — browser begins buffering
      audio.src = item.path;

      // Store by key
      this.tracks[item.key] = audio;
    });

    // Read mute preference from localStorage
    try {
      const muted = localStorage.getItem('iWillGetToYou_muted');
      if (muted !== null) {
        this.muted = (muted === 'true');
      }
    } catch(e) {
      // localStorage unavailable — continue unmuted
    }

    console.log('audio.js: Initialized. Waiting for user gesture (iOS unlock).');
  },

  // ---------------------------------------------------------------------------
  // UNLOCK
  // iOS Safari blocks audio until the user has interacted with the page.
  // Call this on the FIRST tap/click anywhere on the screen.
  // It plays a silent buffer which "unlocks" the audio context.
  // After this, all subsequent audio plays normally.
  // ---------------------------------------------------------------------------
  unlock() {
    if (this.unlocked) return;   // already unlocked, do nothing

    // Play every track silently and immediately pause it.
    // This satisfies the browser's "user gesture" requirement.
    Object.values(this.tracks).forEach(audio => {
      audio.volume = 0;
      const playPromise = audio.play();

      if (playPromise !== undefined) {
        playPromise.then(() => {
          audio.pause();
          audio.currentTime = 0;
          // Restore correct volume after the silent play
          const isMusic = audio.loop;
          const C = window.Game.constants;
          audio.volume = isMusic ? C.MUSIC_VOLUME : C.SFX_VOLUME;
        }).catch(() => {
          // Silent fail — some browsers still block even with gesture
        });
      }
    });

    this.unlocked = true;
    console.log('audio.js: Audio unlocked.');
  },

  // ---------------------------------------------------------------------------
  // PLAY
  // Plays a sound effect once from the beginning.
  // Safe to call even if audio is locked or file is missing.
  // ---------------------------------------------------------------------------
  play(key) {
    if (this.muted)          return;
    if (!this.unlocked)      return;
    if (!this.tracks[key]) {
      console.warn(`audio.js: Track "${key}" not found.`);
      return;
    }

    const audio = this.tracks[key];

    // Rewind to start so rapid repeated calls (e.g. fast ring collecting)
    // always play from the beginning rather than queuing
    audio.currentTime = 0;

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch(err => {
        // Autoplay policy or audio not ready — silent fail
        console.warn(`audio.js: Could not play "${key}".`, err);
      });
    }
  },

  // ---------------------------------------------------------------------------
  // LOOP
  // Starts a music track looping.
  // If the same track is already playing, does nothing (no restart).
  // If a different track was playing, stops it first.
  // ---------------------------------------------------------------------------
  loop(key) {
    if (this.muted)     return;
    if (!this.unlocked) return;
    if (!this.tracks[key]) {
      console.warn(`audio.js: Track "${key}" not found.`);
      return;
    }

    // Don't restart if already playing this track
    if (this._currentMusic === key) return;

    // Stop the current music if any
    this.stopMusic();

    const audio = this.tracks[key];
    audio.currentTime = 0;
    audio.loop = true;

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch(err => {
        console.warn(`audio.js: Could not loop "${key}".`, err);
      });
    }

    this._currentMusic = key;
  },

  // ---------------------------------------------------------------------------
  // STOP (single track)
  // Stops a specific track and rewinds it.
  // ---------------------------------------------------------------------------
  stop(key) {
    if (!this.tracks[key]) return;

    const audio = this.tracks[key];
    audio.pause();
    audio.currentTime = 0;

    if (this._currentMusic === key) {
      this._currentMusic = null;
    }
  },

  // ---------------------------------------------------------------------------
  // STOP MUSIC
  // Stops only the currently playing music track.
  // Sound effects are unaffected.
  // ---------------------------------------------------------------------------
  stopMusic() {
    if (this._currentMusic) {
      this.stop(this._currentMusic);
    }
  },

  // ---------------------------------------------------------------------------
  // STOP ALL
  // Stops everything — music AND sound effects.
  // Called on pause, game over, and state transitions.
  // ---------------------------------------------------------------------------
  stopAll() {
    Object.keys(this.tracks).forEach(key => {
      this.stop(key);
    });
    this._currentMusic = null;
  },

  // ---------------------------------------------------------------------------
  // SET MUTE
  // Toggles mute on or off. Saves preference to localStorage.
  // ---------------------------------------------------------------------------
  setMute(shouldMute) {
    this.muted = shouldMute;

    if (shouldMute) {
      // Pause all currently playing audio
      Object.values(this.tracks).forEach(audio => {
        audio.pause();
      });
    } else {
      // Resume music if a track was active
      if (this._currentMusic) {
        const key = this._currentMusic;
        this._currentMusic = null;  // reset so loop() doesn't skip it
        this.loop(key);
      }
    }

    // Persist preference
    try {
      localStorage.setItem('iWillGetToYou_muted', String(shouldMute));
    } catch(e) {
      // localStorage unavailable
    }
  },

  // ---------------------------------------------------------------------------
  // TOGGLE MUTE
  // Convenience method for the mute button in settings/pause.
  // ---------------------------------------------------------------------------
  toggleMute() {
    this.setMute(!this.muted);
  },

};
