// =============================================================================
// camera.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// The camera follows the player horizontally across the level.
// Uses lerp (linear interpolation) for smooth, lag-free following.
// Clamps to level boundaries so we never show empty space beyond the level.
//
// HOW IT WORKS:
//   Every frame: camera.apply(ctx) shifts the canvas coordinate system
//   so that "world position 500" draws at the correct screen position.
//   After drawing everything: camera.reset(ctx) undoes the shift.
//   The HUD is drawn AFTER reset() so it's always screen-fixed.
// =============================================================================

window.Game = window.Game || {};

window.Game.camera = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  x:          0,     // current camera X offset (world units)
  y:          0,     // current camera Y offset (world units)
  targetX:    0,     // where the camera wants to be this frame
  targetY:    0,
  levelWidth: 0,     // set by levelLoader — camera won't scroll beyond this
  levelHeight: 0,    // set by levelLoader

  // ---------------------------------------------------------------------------
  // INIT
  // Sets up the camera for a new level.
  // Called by levelLoader after level data is read.
  // ---------------------------------------------------------------------------
  init(levelWidth, levelHeight) {
    this.levelWidth  = levelWidth;
    this.levelHeight = levelHeight || window.Game.constants.CANVAS_HEIGHT;
    this.x           = 0;
    this.y           = 0;
    this.targetX     = 0;
    this.targetY     = 0;
    console.log(`camera.js: Initialized for level ${levelWidth}×${levelHeight}px.`);
  },

  // ---------------------------------------------------------------------------
  // FOLLOW
  // Called every frame during GAMEPLAY.
  // Smoothly moves the camera toward the player's position.
  // deltaTime in seconds.
  // ---------------------------------------------------------------------------
  follow(playerX, playerY, deltaTime) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    // Target: center player on screen, with a lookahead in their direction
    const player = window.Game.player;
    const lookDir = player ? player.facingDirection : 1;

    // Horizontal target: player centered + lookahead in facing direction
    this.targetX = playerX - (cw / 2) + (C.CAMERA_LOOKAHEAD * lookDir);

    // Clamp target to level bounds
    // Left bound: don't scroll past the start of the level
    this.targetX = Math.max(0, this.targetX);
    // Right bound: don't scroll past the end of the level
    this.targetX = Math.min(this.levelWidth - cw, this.targetX);

    // Vertical target: keep player centered vertically
    this.targetY = playerY - (ch / 2);
    this.targetY = Math.max(0, this.targetY);
    this.targetY = Math.min(this.levelHeight - ch, this.targetY);

    // Lerp toward target — smooth catch-up rather than instant snap
    // Higher CAMERA_LERP = snappier. Lower = dreamier lag.
    this.x += (this.targetX - this.x) * C.CAMERA_LERP;
    this.y += (this.targetY - this.y) * C.CAMERA_Y_LERP;

    // Round to nearest pixel to prevent sub-pixel blurriness on sprites
    this.x = Math.round(this.x);
    this.y = Math.round(this.y);
  },

  // ---------------------------------------------------------------------------
  // APPLY
  // Shifts the canvas context so world coordinates map to screen correctly.
  // Call this BEFORE drawing any world-space objects.
  // Must be paired with reset() after drawing.
  // ---------------------------------------------------------------------------
  apply(ctx) {
    ctx.save();
    ctx.translate(-this.x, -this.y);
  },

  // ---------------------------------------------------------------------------
  // RESET
  // Undoes the camera translation.
  // Call this AFTER drawing world-space objects, BEFORE drawing the HUD.
  // ---------------------------------------------------------------------------
  reset(ctx) {
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // WORLD TO SCREEN
  // Converts a world position to screen (pixel) coordinates.
  // Use this when you need to know where something appears on screen.
  // e.g. placing a UI element above a world object.
  // ---------------------------------------------------------------------------
  worldToScreen(worldX, worldY) {
    return {
      x: worldX - this.x,
      y: worldY - this.y,
    };
  },

  // ---------------------------------------------------------------------------
  // SCREEN TO WORLD
  // Converts a screen position (e.g. touch coordinates) to world coordinates.
  // Use this to translate a tap location into the game world.
  // ---------------------------------------------------------------------------
  screenToWorld(screenX, screenY) {
    return {
      x: screenX + this.x,
      y: screenY + this.y,
    };
  },

  // ---------------------------------------------------------------------------
  // SNAP TO PLAYER
  // Instantly places the camera on the player with no lerp.
  // Used on level start and respawn so there's no dramatic camera slide.
  // ---------------------------------------------------------------------------
  snapToPlayer(playerX, playerY) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    this.x = Math.max(0, Math.min(playerX - cw / 2, this.levelWidth - cw));
    this.y = Math.max(0, Math.min(playerY - ch / 2, this.levelHeight - ch));

    this.targetX = this.x;
    this.targetY = this.y;
  },

  // ---------------------------------------------------------------------------
  // IS VISIBLE
  // Returns true if a world-space rectangle is currently visible on screen.
  // Use this for culling — don't draw objects the camera can't see.
  // Adds a small margin so objects just off-screen still draw (prevents pop-in).
  // ---------------------------------------------------------------------------
  isVisible(worldX, worldY, width, height) {
    const C      = window.Game.constants;
    const margin = 64;   // pixels of extra margin

    return (
      worldX + width  > this.x - margin &&
      worldX          < this.x + C.CANVAS_WIDTH  + margin &&
      worldY + height > this.y - margin &&
      worldY          < this.y + C.CANVAS_HEIGHT + margin
    );
  },

};
