// =============================================================================
// game.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// The master game loop. Ties every system together.
// Uses requestAnimationFrame for smooth 60fps rendering.
//
// EVERY FRAME:
//   1. Calculate deltaTime (capped at 50ms to prevent huge jumps)
//   2. Check current state
//   3. Update the correct systems for that state
//   4. Draw everything in the correct painter's order
//   5. Clear single-frame input flags (MUST be last)
//
// DRAW ORDER (back to front — painter's algorithm):
//   World space (camera applied):
//     background + platforms  (levelLoader.draw)
//     obstacles               (obstacleManager.draw)
//     collectibles            (collectibleManager.draw)
//     particles               (particles.draw)
//     player                  (player.draw)
//   Screen space (camera reset):
//     HUD                     (hud.draw)
//   Screen overlays:
//     pause menu / cutscene / any screen
// =============================================================================

window.Game = window.Game || {};

window.Game.loop = {

  // ---------------------------------------------------------------------------
  // INTERNAL STATE
  // ---------------------------------------------------------------------------
  _lastTimestamp:  0,     // timestamp of the previous frame (ms)
  _animFrameId:    null,  // requestAnimationFrame handle
  _running:        false, // true while the loop is active

  // Maximum deltaTime cap — prevents huge physics jumps after tab switch
  MAX_DELTA: 0.05,   // 50ms = equivalent of 20fps minimum

  // ---------------------------------------------------------------------------
  // START
  // Called once by main.js after all systems are initialized.
  // Kicks off the animation loop.
  // ---------------------------------------------------------------------------
  start() {
    if (this._running) return;   // prevent double-start
    this._running      = true;
    this._lastTimestamp = performance.now();

    // Bind tick so 'this' is correct inside requestAnimationFrame callback
    this._boundTick = this._tick.bind(this);
    this._animFrameId = requestAnimationFrame(this._boundTick);

    console.log('game.js: Loop started.');
  },

  // ---------------------------------------------------------------------------
  // STOP
  // Halts the animation loop. Used when navigating away or on critical error.
  // ---------------------------------------------------------------------------
  stop() {
    this._running = false;
    if (this._animFrameId) {
      cancelAnimationFrame(this._animFrameId);
      this._animFrameId = null;
    }
    console.log('game.js: Loop stopped.');
  },

  // ---------------------------------------------------------------------------
  // _tick (private)
  // The core function called every frame by the browser.
  // timestamp: high-resolution time in ms provided by requestAnimationFrame.
  // ---------------------------------------------------------------------------
  _tick(timestamp) {
    if (!this._running) return;

    // --- Calculate deltaTime ---
    let deltaTime = (timestamp - this._lastTimestamp) / 1000;   // convert to seconds
    this._lastTimestamp = timestamp;

    // Cap deltaTime — prevents physics explosion if tab was backgrounded
    if (deltaTime > this.MAX_DELTA) deltaTime = this.MAX_DELTA;
    // Clamp minimum to avoid zero-division edge cases
    if (deltaTime < 0.001) deltaTime = 0.001;

    // --- Get canvas context ---
    const canvas = window.Game.canvas;
    const ctx    = window.Game.ctx;

    if (!canvas || !ctx) {
      this._animFrameId = requestAnimationFrame(this._boundTick);
      return;
    }

    // --- Clear canvas ---
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // --- Route to correct update + draw based on state ---
    const state = window.Game.state.current;

    switch (state) {

      case 'SPLASH':
        this._updateScreen('splash', deltaTime);
        this._drawScreen('splash', ctx);
        break;

      case 'GENDER_SELECT':
        this._updateScreen('genderSelect', deltaTime);
        this._drawScreen('genderSelect', ctx);
        break;

      case 'LOADING':
        // Preloader runs asynchronously — just draw the loading screen
        if (window.Game.preloader) {
          window.Game.preloader.drawLoadingScreen(ctx);
        }
        break;

      case 'MAIN_MENU':
        this._updateScreen('mainMenu', deltaTime);
        this._drawScreen('mainMenu', ctx);
        break;

      case 'LEVEL_SELECT':
        this._updateScreen('levelSelect', deltaTime);
        this._drawScreen('levelSelect', ctx);
        break;

      case 'CUTSCENE_INTRO':
      case 'CUTSCENE_OUTRO':
        this._updateScreen('cutscene', deltaTime);
        this._drawScreen('cutscene', ctx);
        break;

      case 'GAMEPLAY':
        this._updateGameplay(deltaTime, ctx);
        this._drawGameplay(ctx);
        break;

      case 'PAUSED':
        // Draw frozen game world first, then overlay pause menu on top
        this._drawGameplay(ctx);
        this._updateScreen('pauseMenu', deltaTime);
        this._drawScreen('pauseMenu', ctx);
        break;

      case 'DEATH_ANIMATION':
        // Game world continues to draw (player flash animation runs)
        // No physics update — player is frozen in place
        if (window.Game.particles) window.Game.particles.update(deltaTime);
        if (window.Game.animator)  window.Game.animator.update(deltaTime, window.Game.player);
        this._drawGameplay(ctx);
        break;

      case 'LEVEL_COMPLETE':
        this._updateScreen('levelComplete', deltaTime);
        this._drawScreen('levelComplete', ctx);
        break;

      case 'GAME_OVER':
        this._updateScreen('gameOver', deltaTime);
        this._drawScreen('gameOver', ctx);
        break;

      case 'CREDITS':
      case 'VICTORY':
        this._updateScreen('victory', deltaTime);
        this._drawScreen('victory', ctx);
        break;

      default:
        // Unknown state — draw black and log
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        console.warn(`game.js: Unknown state "${state}"`);
        break;
    }

    // --- Clear single-frame input flags (MUST be last every frame) ---
    if (window.Game.controls) {
      window.Game.controls.clearFrameInputs();
    }

    // --- Queue next frame ---
    this._animFrameId = requestAnimationFrame(this._boundTick);
  },

  // ---------------------------------------------------------------------------
  // _updateGameplay (private)
  // Updates all active gameplay systems.
  // Only runs when state === 'GAMEPLAY'.
  // ---------------------------------------------------------------------------
  _updateGameplay(deltaTime, ctx) {
    // Player (movement, physics, state machine)
    if (window.Game.player) {
      window.Game.player.update(deltaTime);
    }

    // Obstacles (move crushers, platforms, explosions + collision vs player)
    if (window.Game.obstacles) {
      window.Game.obstacles.update(deltaTime, window.Game.player);
    }

    // Collectibles (animate rings, detect pickup)
    if (window.Game.collectibles) {
      window.Game.collectibles.update(deltaTime, window.Game.player);
    }

    // Particles (move, age, kill)
    if (window.Game.particles) {
      window.Game.particles.update(deltaTime);
    }

    // Animator (advance sprite frames)
    if (window.Game.animator && window.Game.player) {
      window.Game.animator.update(deltaTime, window.Game.player);
    }

    // Camera (follow player)
    if (window.Game.camera && window.Game.player) {
      window.Game.camera.follow(
        window.Game.player.x + window.Game.player.width  / 2,
        window.Game.player.y + window.Game.player.height / 2,
        deltaTime
      );
    }

    // HUD (tick timer, manage callouts)
    if (window.Game.hud) {
      window.Game.hud.update(deltaTime);
    }

    // Level callouts (check position triggers)
    if (window.Game.level && window.Game.player) {
      window.Game.level.checkCallouts(window.Game.player.x);
    }

    // Exit check — did player reach the unlocked door?
    if (window.Game.level && window.Game.player &&
        !window.Game.player.isDead &&
        window.Game.state.current === 'GAMEPLAY') {

      if (window.Game.level.checkExit(window.Game.player)) {
        // Level cleared — play outro cutscene
        window.Game.state.levelComplete = true;
        if (window.Game.screens.cutscene) {
          window.Game.screens.cutscene.enter('outro');
        }
        window.Game.state.transition('CUTSCENE_OUTRO');
      }
    }
  },

  // ---------------------------------------------------------------------------
  // _drawGameplay (private)
  // Draws the full game world and HUD.
  // Called for GAMEPLAY, PAUSED (frozen world), and DEATH_ANIMATION states.
  // ---------------------------------------------------------------------------
  _drawGameplay(ctx) {
    const C = window.Game.constants;

    // Apply camera transform — everything below is in WORLD space
    if (window.Game.camera) window.Game.camera.apply(ctx);

    // 1. Level background + static platforms + exit door
    if (window.Game.level) window.Game.level.draw(ctx);

    // 2. Obstacles (explosions, moving platforms, crushers)
    if (window.Game.obstacles) window.Game.obstacles.draw(ctx);

    // 3. Collectibles (rings, checkpoint ring)
    if (window.Game.collectibles) window.Game.collectibles.draw(ctx);

    // 4. Particles (exhaust trails, sparkles, explosion debris)
    if (window.Game.particles) window.Game.particles.draw(ctx);

    // 5. Player (on top of all world elements)
    if (window.Game.player) window.Game.player.draw(ctx);

    // Reset camera transform — everything below is in SCREEN space
    if (window.Game.camera) window.Game.camera.reset(ctx);

    // 6. HUD (lives, ring counter, timer, callouts, dash bar)
    // Always screen-fixed — drawn after camera reset
    if (window.Game.hud && window.Game.state.current !== 'PAUSED') {
      window.Game.hud.draw(ctx);
    } else if (window.Game.hud) {
      // Draw HUD under pause overlay too (stats visible through dim)
      window.Game.hud.draw(ctx);
    }
  },

  // ---------------------------------------------------------------------------
  // _updateScreen (private)
  // Calls the update() method on the named screen module if it exists.
  // ---------------------------------------------------------------------------
  _updateScreen(screenName, deltaTime) {
    const screen = window.Game.screens[screenName];
    if (screen && typeof screen.update === 'function') {
      screen.update(deltaTime);
    }
  },

  // ---------------------------------------------------------------------------
  // _drawScreen (private)
  // Calls the draw() method on the named screen module if it exists.
  // ---------------------------------------------------------------------------
  _drawScreen(screenName, ctx) {
    const screen = window.Game.screens[screenName];
    if (screen && typeof screen.draw === 'function') {
      screen.draw(ctx);
    }
  },

};
