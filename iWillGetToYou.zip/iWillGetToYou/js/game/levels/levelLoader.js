// =============================================================================
// levelLoader.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Reads a level data object and wires up every game system for that level.
// Also owns: background drawing, platform drawing, exit door drawing,
// callout checking, and exit condition checking.
//
// LOAD SEQUENCE (called once per level start):
//   1. Select correct level data (e.g. male_1)
//   2. Initialize camera bounds
//   3. Initialize player start position
//   4. Initialize collectibles from ring data
//   5. Initialize obstacles from obstacle data
//   6. Start background music
//   7. Snap camera to player start
//
// EVERY FRAME (called by game.js):
//   - draw()         — background, platforms, exit door
//   - checkCallouts()— fires contextual text when player reaches trigger X
//   - checkExit()    — returns true if player reaches unlocked door
// =============================================================================

window.Game = window.Game || {};

window.Game.level = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  data:        null,   // reference to the active level data object
  loaded:      false,  // true once load() has completed successfully

  // Background scroll layers (parallax)
  _bgOffset:   0,      // current parallax scroll offset

  // ---------------------------------------------------------------------------
  // LOAD
  // Selects and initializes the correct level for the given gender and number.
  // Called by game.js when entering the CUTSCENE_INTRO → GAMEPLAY transition.
  // ---------------------------------------------------------------------------
  load(gender, levelNumber) {

    // Build the data key — e.g. 'male_1'
    const key = `${gender}_${levelNumber}`;

    if (!window.Game.levelData || !window.Game.levelData[key]) {
      console.error(`levelLoader.js: No level data found for key "${key}".`);
      return false;
    }

    this.data   = window.Game.levelData[key];
    this.loaded = false;

    console.log(`levelLoader.js: Loading "${this.data.name}"...`);

    // --- Initialize camera ---
    window.Game.camera.init(this.data.width, window.Game.constants.CANVAS_HEIGHT);

    // --- Initialize player ---
    window.Game.player.init(
      this.data.playerStart.x,
      this.data.playerStart.y
    );

    // --- Initialize collectibles ---
    window.Game.collectibles.init(this.data.rings);

    // --- Initialize obstacles ---
    window.Game.obstacles.init(this.data.obstacles);

    // --- Reset state for new level ---
    window.Game.state.reset();
    window.Game.state.ringsTotal = window.Game.collectibles.totalRings;

    // --- Snap camera to player immediately (no lerp on level start) ---
    window.Game.camera.snapToPlayer(
      this.data.playerStart.x,
      this.data.playerStart.y
    );

    // --- Start background music ---
    if (window.Game.audio) {
      window.Game.audio.loop(this.data.music);
    }

    // --- Reset background parallax ---
    this._bgOffset = 0;

    this.loaded = true;
    console.log(`levelLoader.js: "${this.data.name}" loaded. ` +
      `${window.Game.collectibles.totalRings} rings. ` +
      `Width: ${this.data.width}px.`);

    return true;
  },

  // ---------------------------------------------------------------------------
  // GET ALL SOLID PLATFORMS
  // Returns combined array of static platforms + obstacle platforms.
  // Called by player.update() every frame to pass into physics.moveAndCollide().
  // ---------------------------------------------------------------------------
  getAllSolidPlatforms() {
    if (!this.data) return [];
    // obstacleManager combines static + moving platforms + crushers
    return window.Game.obstacles.getAllSolidPlatforms(this.data.platforms);
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Called every frame by game.js after camera.apply().
  // Draws: background → platforms → exit door.
  // Obstacles and collectibles are drawn by their own managers.
  // ---------------------------------------------------------------------------
  draw(ctx) {
    if (!this.data) return;

    // 1. Background (space ship interior)
    this._drawBackground(ctx);

    // 2. Static platforms
    this._drawPlatforms(ctx);

    // 3. Exit door
    this._drawExitDoor(ctx);
  },

  // ---------------------------------------------------------------------------
  // _drawBackground (private)
  // Draws the space ship interior environment.
  // Uses parallax layers for depth — background moves slower than foreground.
  // ---------------------------------------------------------------------------
  _drawBackground(ctx) {
    const C    = window.Game.constants;
    const camX = window.Game.camera.x;
    const W    = this.data.width;
    const H    = C.CANVAS_HEIGHT;

    // --- Layer 0: Deep space (stars) — barely moves ---
    ctx.fillStyle = '#05050f';
    ctx.fillRect(camX, 0, C.CANVAS_WIDTH, H);

    // Draw stars — seeded by position so they stay fixed in the world
    // Use a simple deterministic pattern based on level width
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    const starSeed = 42;
    for (let i = 0; i < 120; i++) {
      // Pseudo-random but deterministic star positions
      const sx = ((i * 137 + starSeed) % W);
      const sy = ((i * 91  + starSeed) % (H - 80));
      // Parallax: stars move at 10% of camera speed
      const parallaxX = sx - camX * 0.1;
      // Wrap stars so they always fill the screen
      const screenX = ((parallaxX % C.CANVAS_WIDTH) + C.CANVAS_WIDTH) % C.CANVAS_WIDTH + camX;
      const radius = (i % 3 === 0) ? 1.5 : 0.8;
      ctx.beginPath();
      ctx.arc(screenX, sy, radius, 0, Math.PI * 2);
      ctx.fill();
    }

    // --- Layer 1: Ship hull exterior visible through portholes ---
    // Draw black hole as a distant visual element (atmospheric, not interactive)
    const bhX = 6000 - camX * 0.15 + camX;   // very slow parallax
    const bhY = 160;
    const bhR = 80;

    // Black hole — dark void with gravitational lensing ring
    const bhGrad = ctx.createRadialGradient(bhX, bhY, 0, bhX, bhY, bhR * 2);
    bhGrad.addColorStop(0,   'rgba(0,0,0,1)');
    bhGrad.addColorStop(0.5, 'rgba(10,0,20,0.8)');
    bhGrad.addColorStop(0.8, 'rgba(80,20,120,0.4)');
    bhGrad.addColorStop(1,   'rgba(0,0,0,0)');
    ctx.fillStyle = bhGrad;
    ctx.beginPath();
    ctx.arc(bhX, bhY, bhR * 2, 0, Math.PI * 2);
    ctx.fill();

    // Accretion ring
    ctx.strokeStyle = 'rgba(180, 100, 255, 0.5)';
    ctx.lineWidth   = 4;
    ctx.shadowColor = '#aa44ff';
    ctx.shadowBlur  = 20;
    ctx.beginPath();
    ctx.ellipse(bhX, bhY, bhR * 1.6, bhR * 0.4, -0.2, 0, Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // --- Layer 2: Ship interior walls (mid parallax ~40% camera speed) ---
    // Draw repeating panel sections along the top and bottom
    const panelW  = 320;
    const panelH  = 60;
    const startI  = Math.floor(camX * 0.4 / panelW) - 1;
    const endI    = startI + Math.ceil(C.CANVAS_WIDTH / panelW) + 2;

    for (let i = startI; i <= endI; i++) {
      const px = i * panelW - camX * 0.4 + camX;

      // Top wall panels
      ctx.fillStyle = '#1a2030';
      ctx.fillRect(px, 0, panelW - 2, panelH);
      // Panel highlight
      ctx.fillStyle = '#2a3040';
      ctx.fillRect(px, 0, panelW - 2, 4);
      // Rivet dots
      ctx.fillStyle = '#3a4050';
      for (let r = 0; r < 3; r++) {
        ctx.beginPath();
        ctx.arc(px + 20 + r * 30, panelH - 12, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // Bottom wall panels (above floor)
      ctx.fillStyle = '#1a2030';
      ctx.fillRect(px, H - panelH - 80, panelW - 2, panelH);
      ctx.fillStyle = '#2a3040';
      ctx.fillRect(px, H - panelH - 80, panelW - 2, 4);
    }

    // --- Flickering alarm lights (atmospheric — ship in distress) ---
    const time    = Date.now() / 1000;
    const alarmOn = Math.sin(time * 3.5) > 0.3;   // flickers at ~3.5Hz

    if (alarmOn) {
      // Red alarm overlay — subtle tint across the whole level section visible
      ctx.fillStyle = 'rgba(255, 0, 0, 0.04)';
      ctx.fillRect(camX, 0, C.CANVAS_WIDTH, H);

      // Alarm light sources on ceiling
      for (let i = 0; i < 4; i++) {
        const lx = camX + (i + 0.5) * (C.CANVAS_WIDTH / 4);
        const ly = 30;
        const lr = 18 + 6 * Math.sin(time * 7 + i);

        const alarmGrad = ctx.createRadialGradient(lx, ly, 0, lx, ly, lr * 3);
        alarmGrad.addColorStop(0, `rgba(255, 60, 0, ${0.4 + 0.2 * Math.sin(time * 8)})`);
        alarmGrad.addColorStop(1, 'rgba(255, 0, 0, 0)');
        ctx.fillStyle = alarmGrad;
        ctx.beginPath();
        ctx.arc(lx, ly, lr * 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  },

  // ---------------------------------------------------------------------------
  // _drawPlatforms (private)
  // Draws all static platforms with ship-interior tile aesthetics.
  // ---------------------------------------------------------------------------
  _drawPlatforms(ctx) {
    const platforms = this.data.platforms;
    const camera    = window.Game.camera;

    platforms.forEach(plat => {
      // Cull — skip if off-screen
      if (!camera.isVisible(plat.x, plat.y, plat.width, plat.height)) return;

      ctx.save();

      switch (plat.type) {

        case 'floor': {
          // Main floor panel — dark steel with top highlight
          ctx.fillStyle = '#1e2a3a';
          ctx.fillRect(plat.x, plat.y, plat.width, plat.height);

          // Top edge — bright teal line (walkable surface indicator)
          ctx.fillStyle = '#3af0b0';
          ctx.fillRect(plat.x, plat.y, plat.width, 3);

          // Panel seams — vertical dividers every 64px
          ctx.fillStyle = '#0e1a2a';
          for (let sx = plat.x + 64; sx < plat.x + plat.width; sx += 64) {
            ctx.fillRect(sx, plat.y, 2, plat.height);
          }
          break;
        }

        case 'ledge': {
          // Floating ledge — thinner, brighter edge
          ctx.fillStyle = '#1e3040';
          ctx.fillRect(plat.x, plat.y, plat.width, plat.height);

          // Top edge — glowing teal
          ctx.shadowColor = '#3af0b0';
          ctx.shadowBlur  = 6;
          ctx.fillStyle   = '#4affcc';
          ctx.fillRect(plat.x, plat.y, plat.width, 3);
          ctx.shadowBlur  = 0;
          break;
        }

        case 'wall': {
          // Vertical wall panel
          ctx.fillStyle = '#162030';
          ctx.fillRect(plat.x, plat.y, plat.width, plat.height);

          // Highlight edge on the inner facing side
          ctx.fillStyle = '#2a3a4a';
          ctx.fillRect(plat.x, plat.y, 3, plat.height);

          // Wall jump indicator (green stripe if jumpable)
          if (plat.wallJumpable) {
            ctx.fillStyle   = 'rgba(0, 255, 140, 0.25)';
            ctx.fillRect(plat.x, plat.y, plat.width, plat.height);
            ctx.fillStyle   = 'rgba(0, 255, 140, 0.6)';
            ctx.fillRect(plat.x, plat.y, 2, plat.height);
          }
          break;
        }

        case 'ceiling': {
          // Ceiling obstacle — hazard coloring (darker, warning stripe)
          ctx.fillStyle = '#1a1520';
          ctx.fillRect(plat.x, plat.y, plat.width, plat.height);

          // Bottom edge — warning orange line
          ctx.fillStyle = '#cc4400';
          ctx.fillRect(plat.x, plat.y + plat.height - 3, plat.width, 3);

          // Hazard stripes on bottom face
          ctx.save();
          ctx.beginPath();
          ctx.rect(plat.x, plat.y + plat.height - 10, plat.width, 10);
          ctx.clip();
          const stripeW = 10;
          ctx.fillStyle = 'rgba(180, 60, 0, 0.4)';
          for (let s = -plat.width; s < plat.width * 2; s += stripeW * 2) {
            ctx.fillRect(plat.x + s, plat.y + plat.height - 10, stripeW, 10);
          }
          ctx.restore();
          break;
        }

        default: {
          ctx.fillStyle = '#1e2a3a';
          ctx.fillRect(plat.x, plat.y, plat.width, plat.height);
          break;
        }
      }

      ctx.restore();
    });
  },

  // ---------------------------------------------------------------------------
  // _drawExitDoor (private)
  // Draws the hangar exit door.
  // Locked: dark metal with red light.
  // Unlocked: glowing gold, animated pulse.
  // ---------------------------------------------------------------------------
  _drawExitDoor(ctx) {
    if (!this.data.exitDoor) return;
    const door   = this.data.exitDoor;
    const camera = window.Game.camera;

    if (!camera.isVisible(door.x, door.y, door.width, door.height)) return;

    const unlocked = window.Game.state.doorUnlocked;
    const time     = Date.now() / 1000;

    ctx.save();

    if (unlocked) {
      // --- UNLOCKED: glowing gold door ---
      const pulse = 0.7 + 0.3 * Math.sin(time * 3);

      // Outer glow halo
      const halo = ctx.createRadialGradient(
        door.x + door.width / 2, door.y + door.height / 2, 0,
        door.x + door.width / 2, door.y + door.height / 2, door.width * 1.5
      );
      halo.addColorStop(0,   `rgba(255, 220, 80, ${pulse * 0.5})`);
      halo.addColorStop(0.5, `rgba(255, 160, 0, ${pulse * 0.2})`);
      halo.addColorStop(1,   'rgba(0,0,0,0)');
      ctx.fillStyle = halo;
      ctx.fillRect(
        door.x - door.width,
        door.y - door.height,
        door.width  * 3,
        door.height * 3
      );

      // Door body
      ctx.fillStyle = '#3a2800';
      ctx.fillRect(door.x, door.y, door.width, door.height);

      // Gold frame
      ctx.shadowColor = '#ffd700';
      ctx.shadowBlur  = 20 * pulse;
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth   = 4;
      ctx.strokeRect(door.x + 2, door.y + 2, door.width - 4, door.height - 4);
      ctx.shadowBlur  = 0;

      // Inner light — bright gold fill
      ctx.fillStyle = `rgba(255, 200, 50, ${0.15 + 0.1 * pulse})`;
      ctx.fillRect(door.x + 4, door.y + 4, door.width - 8, door.height - 8);

      // "EXIT" label
      ctx.fillStyle    = `rgba(255, 220, 100, ${0.8 + 0.2 * pulse})`;
      ctx.font         = 'bold 14px "Roboto", sans-serif';
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor  = '#ffd700';
      ctx.shadowBlur   = 10;
      ctx.fillText('EXIT', door.x + door.width / 2, door.y + door.height / 2);
      ctx.shadowBlur   = 0;

    } else {
      // --- LOCKED: dark metal door with red warning light ---
      ctx.fillStyle = '#1a1a1a';
      ctx.fillRect(door.x, door.y, door.width, door.height);

      // Dark frame
      ctx.strokeStyle = '#333333';
      ctx.lineWidth   = 3;
      ctx.strokeRect(door.x + 2, door.y + 2, door.width - 4, door.height - 4);

      // Red warning light (small pulsing dot at top of door)
      const redPulse  = 0.5 + 0.5 * Math.sin(time * 2);
      ctx.fillStyle   = `rgba(255, 40, 0, ${redPulse})`;
      ctx.shadowColor = '#ff0000';
      ctx.shadowBlur  = 10 * redPulse;
      ctx.beginPath();
      ctx.arc(door.x + door.width / 2, door.y + 20, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Lock icon — simple padlock shape
      ctx.fillStyle = '#555555';
      ctx.fillRect(door.x + door.width / 2 - 10, door.y + door.height / 2, 20, 16);
      ctx.strokeStyle = '#555555';
      ctx.lineWidth   = 3;
      ctx.beginPath();
      ctx.arc(door.x + door.width / 2, door.y + door.height / 2, 8, Math.PI, 0);
      ctx.stroke();
    }

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // CHECK CALLOUTS
  // Called every frame with the player's current world X position.
  // Fires callout text the first time player crosses each trigger threshold.
  // Returns the callout text if one fired this frame, otherwise null.
  // ---------------------------------------------------------------------------
  checkCallouts(playerX) {
    if (!this.data || !this.data.callouts) return null;

    const state = window.Game.state;

    for (let i = 0; i < this.data.callouts.length; i++) {
      const callout = this.data.callouts[i];

      // Skip if already fired this run
      if (state.firedCallouts[callout.triggerX]) continue;

      // Fire if player has passed the trigger X position
      if (playerX >= callout.triggerX) {
        state.firedCallouts[callout.triggerX] = true;

        // Show via HUD
        if (window.Game.hud) {
          window.Game.hud.showCallout(callout.text);
        }

        return callout.text;
      }
    }

    return null;
  },

  // ---------------------------------------------------------------------------
  // CHECK EXIT
  // Returns true if the player is overlapping the exit door AND the door
  // is unlocked (80% rings collected). Called every frame by game.js.
  // ---------------------------------------------------------------------------
  checkExit(player) {
    if (!this.data || !this.data.exitDoor) return false;
    if (!window.Game.state.doorUnlocked)   return false;

    const door    = this.data.exitDoor;
    const physics = window.Game.physics;

    return physics.checkOverlap(player, door);
  },

};
