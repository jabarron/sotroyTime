# Level Design Notes — iWillGetToYou
## J&I Studios, 2026

---

## Core Design Philosophy

Every mechanic must be TAUGHT before it is TESTED.
The player must never feel cheated — only challenged.
If a player dies, they should immediately understand why and how to avoid it next time.

The teaching order is strict and must be respected when placing obstacles in level data.

---

## Mechanic Teaching Sequence — Level 1: The Shipwreck

```
ZONE 1: The Corridor (x: 0 – 1200)
────────────────────────────────────
TEACH: Walk left/right
TEACH: Basic jump
OBSTACLES: None — safe zone
RINGS: 6 common rings in a gentle arc the player naturally follows
CALLOUT at x=200: "The ship is tearing apart. Follow the rings."

  ───────────────────────────────────
  [START]  ○  ○  ○     ○  ○  ○
  ═══════════════════════════════════  ← floor
                      ↑
                  small gap (jump to cross)


ZONE 2: The Engine Room (x: 1200 – 2400)
────────────────────────────────────────
TEACH: Double jump (introduced by a gap too wide for single jump)
TEACH: Moving platforms (one slow horizontal platform, easy to read)
OBSTACLES: 1 moving platform (horizontal, slow)
RINGS: 8 common rings, 2 placed on the moving platform to incentivize riding it
CALLOUT at x=1500: "Jump. Then jump again."

  ════════════   [moving platform →←]   ════════════
                      ○  ○
  — — — — — — — — — — — — — — — — — — — — — — —  (gap — requires double jump to cross)
  ════════════════════════════════════════════════


ZONE 3: The Fuel Bay (x: 2400 – 3600)
──────────────────────────────────────
TEACH: Dash (rocket boost)
TEACH: Dash to clear a horizontal gap too long for jump alone
OBSTACLES: 1 explosion zone (static position, long warning time — very safe intro)
RINGS: 8 common rings, 2 placed PAST the explosion zone (reward for timing it)
CALLOUT at x=2600: "Use your thrusters to get through."

  ════════  [EXPLOSION ZONE]  ════════════════════
               ⚠ ⚠ ⚠                  ○  ○
  ════════════════════════════════════════════════
                          ↑
              long horizontal gap (requires dash)


ZONE 4: CHECKPOINT (x: 3600 – 4000)
──────────────────────────────────────
  Safe landing zone before the midpoint.
  Checkpoint ring is placed on a wide, stable platform.
  No obstacles within 300px of the checkpoint.
  CALLOUT on checkpoint touch: "Checkpoint. Keep going."

  ════════════════════════════════════════════════
       ⊙ ← large checkpoint ring (center of platform)
  ════════════════════════════════════════════════


ZONE 5: The Cargo Hold (x: 4000 – 5200)
─────────────────────────────────────────
TEACH: Wall jump (a tall vertical shaft with two parallel walls)
TEACH: Crusher (one crusher, warning time is generous — 800ms)
OBSTACLES: 1 crusher (vertical, drops from ceiling)
           1 explosion zone (timed with the crusher so only one is active at once)
RINGS: 10 common rings — several on high ledges only reachable via wall jump
CALLOUT at x=4200: "The walls can save you."

  ║ ○          ║   ← tall vertical shaft
  ║    ○       ║   ← rings placed mid-height (incentivize wall jump)
  ║       ○    ║
  ║            ║
  [CRUSHER ↓]  ║
  ═════════════╝


ZONE 6: The Bridge (x: 5200 – 6400)
──────────────────────────────────────
TEACH: Double jump + dash COMBO
INTRODUCE: Two explosion zones (offset timing — not simultaneous)
INTRODUCE: Second crusher (faster than Zone 5 crusher)
RINGS: 10 common rings — several only reachable with double jump + dash combo
CALLOUT at x=5400: "You'll need everything you've got."

  Platform layout forces: jump → double jump (height) → dash (distance)
  to reach the far ledge where rings are clustered.

  ════╗                              ╔══════
      ║     ○  ○  ○                  ║
      ║  [EXPLOSION] [EXPLOSION]     ║
  ════╝                              ╚══════
                                     ↑
                               requires combo to reach


ZONE 7: The Final Approach (x: 6400 – 7600)
──────────────────────────────────────────────
ALL MECHANICS COMBINED — hardest section
OBSTACLES: 2 crushers + 2 explosion zones + 2 moving platforms
RINGS: 8 common rings — placed to guide path through obstacles
No new mechanics — pure execution of everything learned

  This zone separates 1-star runs (survive) from 2-star runs (collect all rings).
  Rings are placed in positions that require precision but are achievable.

CALLOUT at x=6600: "Almost there."


ZONE 8: The Hangar (x: 7600 – 8000)
──────────────────────────────────────
SAFE ZONE — reward for surviving
Wide open platform, no obstacles
EXIT DOOR at x: 7850
Door glows gold if 80% rings collected, dark if not
Final ring cluster (6 rings) guides player to the door

CALLOUT at x=7700: "The hangar. Go!"
CALLOUT on door unlock: "Hangar unlocked!"
CALLOUT on door locked (player reaches door without enough rings): shown via HUD only
```

---

## Ring Count Summary

| Zone | Common Rings | Checkpoint Rings | Cumulative |
|------|-------------|-----------------|------------|
| 1 — Corridor       | 6  | 0 | 6  |
| 2 — Engine Room    | 8  | 0 | 14 |
| 3 — Fuel Bay       | 8  | 0 | 22 |
| 4 — Checkpoint     | 0  | 1 | 22 |
| 5 — Cargo Hold     | 10 | 0 | 32 |
| 6 — Bridge         | 10 | 0 | 42 |
| 7 — Final Approach | 8  | 0 | 50 |
| 8 — Hangar         | 6  | 0 | 56 |
| **TOTAL**          | **56** | **1** | — |

**80% threshold = 45 rings** (56 × 0.80 = 44.8, rounded up to 45)

The player can miss 11 rings and still unlock the door.
This gives enough forgiveness that casual players can progress
while rewarding thorough explorers with the 2-star and 3-star ratings.

---

## Obstacle Timing Reference

| Obstacle | Zone | Phase Timings | Notes |
|----------|------|---------------|-------|
| Moving Platform 1 | 2 | speed: 80px/s, horizontal | Introduces moving platforms gently |
| Explosion Zone 1  | 3 | cool:2000ms warn:900ms exp:300ms | Long cool — player has time to study it |
| Crusher 1         | 5 | idle:2000ms warn:700ms crush:150ms hold:500ms retract:800ms | Generous warning |
| Explosion Zone 2  | 5 | cool:1600ms warn:800ms exp:300ms | Offset from crusher so they don't sync |
| Moving Platform 2 | 6 | speed: 100px/s, vertical | Vertical movement — new axis |
| Explosion Zone 3  | 6 | cool:1400ms warn:700ms exp:300ms | Faster cycle — more pressure |
| Crusher 2         | 6 | idle:1500ms warn:600ms crush:120ms hold:400ms retract:700ms | Faster than Crusher 1 |
| Moving Platform 3 | 7 | speed: 120px/s, diagonal | Hardest platform — combined movement |
| Explosion Zone 4  | 7 | cool:1200ms warn:600ms exp:300ms | Fast cycle — high skill required |
| Crusher 3         | 7 | idle:1400ms warn:500ms crush:100ms hold:300ms retract:600ms | Fastest crusher |

---

## Wall Jump Surface Tags

The following platform segments are tagged `wallJumpable: true`:
- Zone 5 vertical shaft walls (left and right)
- Zone 6 bridge vertical supports (left sides only — one direction)
- Selected tall walls in Zone 7

All other walls are `wallJumpable: false`.
The player CAN touch non-jumpable walls but cannot wall jump from them.

---

## Callout Trigger Map

| Trigger | Type | Text |
|---------|------|------|
| x: 200   | position | "The ship is tearing apart. Follow the rings." |
| x: 1500  | position | "Jump. Then jump again." |
| x: 2600  | position | "Use your thrusters to get through." |
| checkpoint touch | event | "Checkpoint. Keep going." |
| x: 4200  | position | "The walls can save you." |
| x: 5400  | position | "You'll need everything you've got." |
| x: 6600  | position | "Almost there." |
| x: 7700  | position | "The hangar. Go!" |
| 80% rings | event | "Hangar unlocked!" |
| timer 30s | event | "The ship won't last much longer." |

---

## Level Dimensions

- **Total width:** 8000px
- **Canvas height:** 720px
- **Floor Y position:** 640px (80px from bottom — leaves room for controls)
- **Ceiling Y position:** 40px (top boundary)
- **Player start:** x: 120, y: 580

---

## Notes for Future Level 2

When Level 2 (The Void Walk) is designed:
- All mechanics from Level 1 are assumed to be mastered
- Introduce: exterior ship sections with wind/drift effect on player
- Introduce: timed sections (airlocks that seal)
- No re-teaching of basics — jump straight into combinations
- Timer: 4 minutes (larger level)
- Ring count: ~70 (more exploration rewarded)
