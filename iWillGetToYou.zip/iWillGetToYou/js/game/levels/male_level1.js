// =============================================================================
// male_level1.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Complete data definition for Level 1: "The Shipwreck" (male path).
// This file contains NO logic — only data.
// levelLoader.js reads this data and passes it to the correct managers.
//
// COORDINATE SYSTEM:
//   x increases rightward, y increases downward.
//   (0, 0) is the top-left corner of the level.
//   Canvas is 1280 × 720. Level is 8000px wide.
//   Floor is at y=640. Ceiling at y=0.
//
// TEACHING ORDER: See levelDesignNotes.md for the full design rationale.
// Zones 1-8 are commented here to match the design document exactly.
// =============================================================================

window.Game          = window.Game          || {};
window.Game.levelData = window.Game.levelData || {};

window.Game.levelData.male_1 = {

  // ---------------------------------------------------------------------------
  // METADATA
  // ---------------------------------------------------------------------------
  name:       'The Shipwreck',
  levelNumber: 1,
  gender:      'male',
  width:       8000,
  background:  'space_ship',   // tells renderer which background scene to draw
  music:       'music_level1',

  // ---------------------------------------------------------------------------
  // PLAYER START
  // ---------------------------------------------------------------------------
  playerStart: { x: 120, y: 575 },

  // ---------------------------------------------------------------------------
  // EXIT DOOR
  // The glowing hangar door at the end of the level.
  // Only activatable when state.doorUnlocked is true (80% rings collected).
  // ---------------------------------------------------------------------------
  exitDoor: {
    x:      7840,
    y:      520,
    width:  80,
    height: 120,
  },

  // ---------------------------------------------------------------------------
  // STATIC PLATFORMS
  // Each platform is a solid rectangle.
  // type: 'floor' | 'wall' | 'ceiling' | 'ledge'
  // wallJumpable: true only on specific vertical surfaces (see levelDesignNotes.md)
  // ---------------------------------------------------------------------------
  platforms: [

    // =========================================================================
    // ZONE 1: THE CORRIDOR (x: 0 – 1200)
    // Teaches: walk, basic jump
    // =========================================================================

    // Main floor — the starting corridor
    { x: 0,    y: 640, width: 900,  height: 80, type: 'floor',   wallJumpable: false },

    // Left boundary wall — player cannot go left of the start
    { x: -60,  y: 0,   width: 60,   height: 720, type: 'wall',   wallJumpable: false },

    // First gap platform — step up to a slightly raised section
    { x: 920,  y: 600, width: 180,  height: 80,  type: 'ledge',  wallJumpable: false },

    // Low ceiling section — player must duck (slide/dash low) to pass
    { x: 600,  y: 180, width: 300,  height: 40,  type: 'ceiling', wallJumpable: false },

    // Second section floor after first gap
    { x: 1100, y: 640, width: 500,  height: 80,  type: 'floor',  wallJumpable: false },

    // =========================================================================
    // ZONE 2: THE ENGINE ROOM (x: 1200 – 2400)
    // Teaches: double jump, moving platforms
    // =========================================================================

    // Engine room floor — lower than corridor (player drops down)
    { x: 1600, y: 640, width: 300,  height: 80,  type: 'floor',  wallJumpable: false },

    // High ledge — requires double jump to reach (rings are up here)
    { x: 1350, y: 440, width: 200,  height: 20,  type: 'ledge',  wallJumpable: false },

    // Engine room far wall — vertical surface, NOT wall-jumpable
    { x: 2380, y: 400, width: 40,   height: 240, type: 'wall',   wallJumpable: false },

    // Far side floor — where moving platform delivers player
    { x: 2100, y: 640, width: 600,  height: 80,  type: 'floor',  wallJumpable: false },

    // =========================================================================
    // ZONE 3: THE FUEL BAY (x: 2400 – 3600)
    // Teaches: dash (rocket boost), explosion zones
    // =========================================================================

    // Fuel bay floor
    { x: 2700, y: 640, width: 900,  height: 80,  type: 'floor',  wallJumpable: false },

    // Raised launch platform — player must dash to reach the far side
    { x: 2700, y: 520, width: 220,  height: 20,  type: 'ledge',  wallJumpable: false },

    // Mid-air stepping stone — placed just within dash range
    { x: 3100, y: 560, width: 120,  height: 20,  type: 'ledge',  wallJumpable: false },

    // Far platform after dash gap
    { x: 3320, y: 640, width: 400,  height: 80,  type: 'floor',  wallJumpable: false },

    // Ceiling overhang — forces player to dash LOW (not jump over)
    { x: 2900, y: 200, width: 400,  height: 40,  type: 'ceiling', wallJumpable: false },

    // =========================================================================
    // ZONE 4: CHECKPOINT (x: 3600 – 4000)
    // Wide safe platform with checkpoint ring
    // =========================================================================

    // Checkpoint platform — wide and stable
    { x: 3720, y: 640, width: 500,  height: 80,  type: 'floor',  wallJumpable: false },

    // =========================================================================
    // ZONE 5: THE CARGO HOLD (x: 4000 – 5200)
    // Teaches: wall jump, crusher
    // =========================================================================

    // Cargo hold entry floor
    { x: 4220, y: 640, width: 300,  height: 80,  type: 'floor',  wallJumpable: false },

    // Left wall of vertical shaft — WALL JUMPABLE
    { x: 4220, y: 300, width: 40,   height: 340, type: 'wall',   wallJumpable: true  },

    // Right wall of vertical shaft — WALL JUMPABLE
    { x: 4500, y: 300, width: 40,   height: 340, type: 'wall',   wallJumpable: true  },

    // Shaft floor — player lands here after wall jumping up
    { x: 4220, y: 300, width: 320,  height: 20,  type: 'ledge',  wallJumpable: false },

    // Upper shaft floor connection
    { x: 4540, y: 500, width: 300,  height: 80,  type: 'floor',  wallJumpable: false },

    // High cargo ledge — only reachable via wall jump
    { x: 4260, y: 200, width: 180,  height: 20,  type: 'ledge',  wallJumpable: false },

    // Cargo hold exit floor
    { x: 4840, y: 640, width: 500,  height: 80,  type: 'floor',  wallJumpable: false },

    // =========================================================================
    // ZONE 6: THE BRIDGE (x: 5200 – 6400)
    // Teaches: double jump + dash combo
    // =========================================================================

    // Bridge entry floor
    { x: 5200, y: 640, width: 300,  height: 80,  type: 'floor',  wallJumpable: false },

    // Left bridge pillar — wall jumpable (one side)
    { x: 5200, y: 320, width: 40,   height: 320, type: 'wall',   wallJumpable: true  },

    // Right bridge pillar — wall jumpable
    { x: 5800, y: 320, width: 40,   height: 320, type: 'wall',   wallJumpable: true  },

    // High bridge deck — requires double jump + dash to reach from entry
    { x: 5500, y: 380, width: 300,  height: 20,  type: 'ledge',  wallJumpable: false },

    // Bridge far side floor
    { x: 5840, y: 640, width: 700,  height: 80,  type: 'floor',  wallJumpable: false },

    // Mid-bridge stepping stone — helps players who can't do full combo yet
    // (allows 2-jump path as alternative to combo, but misses some rings)
    { x: 5400, y: 540, width: 100,  height: 20,  type: 'ledge',  wallJumpable: false },

    // =========================================================================
    // ZONE 7: THE FINAL APPROACH (x: 6400 – 7600)
    // All mechanics combined — hardest section
    // =========================================================================

    // Final approach floor sections (broken up — pits between them)
    { x: 6400, y: 640, width: 200,  height: 80,  type: 'floor',  wallJumpable: false },
    { x: 6700, y: 640, width: 160,  height: 80,  type: 'floor',  wallJumpable: false },
    { x: 6980, y: 640, width: 180,  height: 80,  type: 'floor',  wallJumpable: false },
    { x: 7260, y: 640, width: 200,  height: 80,  type: 'floor',  wallJumpable: false },

    // High ledge cluster — combo required
    { x: 6550, y: 440, width: 140,  height: 20,  type: 'ledge',  wallJumpable: false },
    { x: 6840, y: 360, width: 120,  height: 20,  type: 'ledge',  wallJumpable: false },
    { x: 7100, y: 440, width: 140,  height: 20,  type: 'ledge',  wallJumpable: false },

    // Final tall wall — wall jump to reach upper route
    { x: 7460, y: 280, width: 40,   height: 360, type: 'wall',   wallJumpable: true  },

    // Upper route floor — leads to hangar
    { x: 7500, y: 520, width: 300,  height: 20,  type: 'ledge',  wallJumpable: false },

    // =========================================================================
    // ZONE 8: THE HANGAR (x: 7600 – 8000)
    // Safe zone — exit door — reward
    // =========================================================================

    // Hangar floor — wide and open
    { x: 7500, y: 640, width: 500,  height: 80,  type: 'floor',  wallJumpable: false },

    // Right boundary wall — level end
    { x: 8000, y: 0,   width: 60,   height: 720, type: 'wall',   wallJumpable: false },

  ],

  // ---------------------------------------------------------------------------
  // RINGS
  // 56 common rings + 1 checkpoint ring = 57 total
  // 80% threshold = 45 common rings
  // isCheckpoint: true = large checkpoint ring (not counted in 80%)
  // floatPhase: random offset so rings don't all bob in sync (set by manager)
  // ---------------------------------------------------------------------------
  rings: [

    // =========================================================================
    // ZONE 1: THE CORRIDOR — 6 rings
    // Gentle arc guiding the player right and up
    // =========================================================================
    { x: 280,  y: 590 },
    { x: 440,  y: 570 },
    { x: 580,  y: 555 },
    { x: 710,  y: 545 },
    { x: 840,  y: 555 },
    { x: 960,  y: 570 },

    // =========================================================================
    // ZONE 2: THE ENGINE ROOM — 8 rings
    // 2 on the moving platform (incentivize riding it)
    // 2 on the high ledge (reward double jump)
    // =========================================================================
    { x: 1220, y: 590 },
    { x: 1360, y: 400 },   // on high ledge — double jump needed
    { x: 1440, y: 400 },   // on high ledge
    { x: 1580, y: 590 },
    { x: 1700, y: 390 },   // on moving platform (platform Y ~420)
    { x: 1780, y: 390 },   // on moving platform
    { x: 1960, y: 590 },
    { x: 2060, y: 590 },

    // =========================================================================
    // ZONE 3: THE FUEL BAY — 8 rings
    // 3 on launch platform (reward going up)
    // 2 past explosion zone (reward timing)
    // =========================================================================
    { x: 2760, y: 480 },   // on raised launch platform
    { x: 2820, y: 480 },
    { x: 2880, y: 480 },
    { x: 3000, y: 590 },   // ground level before explosion zone
    { x: 3120, y: 520 },   // on stepping stone
    { x: 3200, y: 590 },   // past explosion zone (reward timing)
    { x: 3320, y: 590 },
    { x: 3440, y: 590 },

    // =========================================================================
    // ZONE 4: CHECKPOINT RING
    // isCheckpoint: true — saves respawn, not counted in 80%
    // =========================================================================
    { x: 3940, y: 590, isCheckpoint: true },

    // =========================================================================
    // ZONE 5: THE CARGO HOLD — 10 rings
    // Several on high ledges only reachable via wall jump
    // =========================================================================
    { x: 4280, y: 590 },
    { x: 4340, y: 590 },
    { x: 4290, y: 260 },   // on high cargo ledge — wall jump required
    { x: 4360, y: 260 },   // on high cargo ledge
    { x: 4440, y: 260 },   // on high cargo ledge
    { x: 4280, y: 450 },   // mid-shaft (wall jump arc)
    { x: 4440, y: 380 },   // mid-shaft (wall jump arc)
    { x: 4600, y: 460 },
    { x: 4720, y: 590 },
    { x: 4900, y: 590 },

    // =========================================================================
    // ZONE 6: THE BRIDGE — 10 rings
    // Several on the high bridge deck (double jump + dash combo)
    // =========================================================================
    { x: 5260, y: 590 },
    { x: 5340, y: 590 },
    { x: 5430, y: 500 },   // on stepping stone
    { x: 5520, y: 340 },   // on high bridge deck — combo required
    { x: 5580, y: 340 },
    { x: 5640, y: 340 },
    { x: 5700, y: 340 },
    { x: 5760, y: 340 },
    { x: 5900, y: 590 },
    { x: 6000, y: 590 },

    // =========================================================================
    // ZONE 7: THE FINAL APPROACH — 8 rings
    // Placed to guide path through obstacles
    // =========================================================================
    { x: 6440, y: 590 },
    { x: 6580, y: 400 },   // on high ledge
    { x: 6660, y: 590 },
    { x: 6860, y: 320 },   // on highest ledge — hardest to reach
    { x: 7020, y: 400 },   // on mid ledge
    { x: 7100, y: 590 },
    { x: 7300, y: 590 },
    { x: 7480, y: 480 },   // on upper route ledge

    // =========================================================================
    // ZONE 8: THE HANGAR — 6 rings
    // Guide path to exit door
    // =========================================================================
    { x: 7580, y: 590 },
    { x: 7650, y: 590 },
    { x: 7710, y: 590 },
    { x: 7760, y: 590 },
    { x: 7800, y: 560 },   // slightly raised — arc toward door
    { x: 7820, y: 530 },   // pointing right at the door

  ],

  // ---------------------------------------------------------------------------
  // OBSTACLES
  // All obstacle data — passed to obstacleManager.init()
  // ---------------------------------------------------------------------------
  obstacles: {

    // =========================================================================
    // MOVING PLATFORMS
    // =========================================================================
    movingPlatforms: [

      // Zone 2: First moving platform — horizontal, slow, gentle intro
      // Bridges the gap in the Engine Room
      {
        x:          1880,
        y:          580,
        width:      160,
        height:     16,
        pathStart:  { x: 1880, y: 580 },
        pathEnd:    { x: 2060, y: 580 },
        speed:      75,
        wallJumpable: false,
        startDelay: 0,
      },

      // Zone 6: Second moving platform — vertical, medium speed
      // Lifts player to the high bridge deck
      {
        x:          5480,
        y:          580,
        width:      120,
        height:     16,
        pathStart:  { x: 5480, y: 580 },
        pathEnd:    { x: 5480, y: 400 },
        speed:      90,
        wallJumpable: false,
        startDelay: 500,
      },

      // Zone 7: Third moving platform — diagonal, fastest
      // Hardest platform — requires timing to board
      {
        x:          6860,
        y:          560,
        width:      100,
        height:     16,
        pathStart:  { x: 6860, y: 560 },
        pathEnd:    { x: 7060, y: 400 },
        speed:      110,
        wallJumpable: false,
        startDelay: 0,
      },

    ],

    // =========================================================================
    // CRUSHERS
    // =========================================================================
    crushers: [

      // Zone 5: First crusher — drops from ceiling above the shaft
      // Generous warning time — teaches the mechanic safely
      {
        x:          4260,
        y:          80,
        width:      260,
        height:     40,
        direction:  'down',
        travelDistance: 220,
        idleMs:     2000,
        warningMs:  700,
        crushMs:    160,
        holdMs:     500,
        retractMs:  900,
      },

      // Zone 6: Second crusher — horizontal, faster than first
      // Comes from right wall — new direction introduces variation
      {
        x:          5760,
        y:          460,
        width:      40,
        height:     120,
        direction:  'left',
        travelDistance: 200,
        idleMs:     1500,
        warningMs:  600,
        crushMs:    130,
        holdMs:     400,
        retractMs:  700,
      },

      // Zone 7: Third crusher — fastest, drops from ceiling
      // Maximum pressure — player must be skilled to dodge
      {
        x:          7000,
        y:          60,
        width:      200,
        height:     40,
        direction:  'down',
        travelDistance: 300,
        idleMs:     1400,
        warningMs:  500,
        crushMs:    100,
        holdMs:     300,
        retractMs:  600,
      },

    ],

    // =========================================================================
    // EXPLOSION ZONES
    // startTimer offsets prevent all explosions from syncing
    // =========================================================================
    explosions: [

      // Zone 3: First explosion — long cooldown, very safe intro
      // Player must dash past it between explosions
      {
        x:           3000,
        y:            620,
        radius:        55,
        coolingMs:    2000,
        warningMs:     900,
        explodingMs:   300,
        startPhase:  'cooling',
        startTimer:    0,
      },

      // Zone 5: Second explosion — in the cargo hold corridor
      // Timed offset from Crusher 1 so they don't both fire simultaneously
      {
        x:           4780,
        y:            620,
        radius:        50,
        coolingMs:    1600,
        warningMs:     800,
        explodingMs:   300,
        startPhase:  'cooling',
        startTimer:    800,    // offset so it fires 800ms after zone starts
      },

      // Zone 6: Third explosion — on the bridge floor
      // Offset from each other so player has a path through
      {
        x:           5560,
        y:            620,
        radius:        55,
        coolingMs:    1400,
        warningMs:     700,
        explodingMs:   300,
        startPhase:  'cooling',
        startTimer:    0,
      },

      // Zone 6: Fourth explosion — second bridge explosion, offset timing
      {
        x:           5720,
        y:            620,
        radius:        55,
        coolingMs:    1400,
        warningMs:     700,
        explodingMs:   300,
        startPhase:  'cooling',
        startTimer:    700,   // fires when Zone 6 first is cooling
      },

      // Zone 7: Fifth explosion — fast cycle, high pressure
      {
        x:           6500,
        y:            620,
        radius:        55,
        coolingMs:    1200,
        warningMs:     600,
        explodingMs:   300,
        startPhase:  'cooling',
        startTimer:    400,
      },

      // Zone 7: Sixth explosion — near the final crusher
      {
        x:           7160,
        y:            620,
        radius:        50,
        coolingMs:    1200,
        warningMs:     600,
        explodingMs:   300,
        startPhase:  'cooling',
        startTimer:    900,
      },

    ],

  },

  // ---------------------------------------------------------------------------
  // CALLOUTS
  // Position-triggered text callouts shown during gameplay.
  // triggerX: player world X position that fires the callout.
  // Each triggerX fires only once per run (tracked in state.firedCallouts).
  // Event-based callouts (checkpoint, door unlock, timer warning) are
  // fired by their respective systems, not by this array.
  // ---------------------------------------------------------------------------
  callouts: [
    { triggerX: 200,  text: 'The ship is tearing apart. Follow the rings.' },
    { triggerX: 1500, text: 'Jump. Then jump again.'                        },
    { triggerX: 2600, text: 'Use your thrusters to get through.'            },
    { triggerX: 4200, text: 'The walls can save you.'                       },
    { triggerX: 5400, text: "You'll need everything you've got."            },
    { triggerX: 6600, text: 'Almost there.'                                 },
    { triggerX: 7700, text: 'The hangar. Go!'                               },
  ],

};
