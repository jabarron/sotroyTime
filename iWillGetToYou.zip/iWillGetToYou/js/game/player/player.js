// =============================================================================
// player.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// The player character. Owns position, velocity, state machine, and lifecycle.
// Does NOT handle input directly — that is movement.js reading controls.js.
// Does NOT draw directly — that is animator.js.
//
// STATE MACHINE (animationState):
//   'idle'        — standing still on ground
//   'run'         — walking/running on ground
//   'jump'        — first jump, ascending
//   'double_jump' — second jump in the air
//   'dash'        — rocket boost active
//   'wall_slide'  — touching a wall while airborne, sliding down slowly
//   'death'       — death animation playing (flashing red)
//   'spawn'       — brief invincibility after respawn
// =============================================================================

window.Game = window.Game || {};

window.Game.player = {

  // ---------------------------------------------------------------------------
  // POSITION & PHYSICS
  // ---------------------------------------------------------------------------
  x:      0,       // world X position (left edge of collision box)
  y:      0,       // world Y position (top edge of collision box)
  vx:     0,       // horizontal velocity (pixels/sec)
  vy:     0,       // vertical velocity (pixels/sec, positive = down)

  // Collision box dimensions — read from constants
  width:  0,
  height: 0,

  // Ground / wall contact — set by physics.moveAndCollide() each frame
  onGround:  false,
  onCeiling: false,
  onWall:    false,

  // ---------------------------------------------------------------------------
  // ANIMATION STATE MACHINE
  // ---------------------------------------------------------------------------
  animationState:  'idle',    // current animation (see list above)
  facingDirection: 1,         // 1 = facing right, -1 = facing left

  // ---------------------------------------------------------------------------
  // JUMP TRACKING
  // ---------------------------------------------------------------------------
  jumpsUsed:      0,      // 0 = can jump, 1 = used first jump, 2 = used both
  canDoubleJump:  true,   // reset to true when player lands on ground

  // Coyote time — player can jump briefly after walking off a ledge
  coyoteTimer:    0,      // ms remaining of coyote time window

  // Jump buffer — jump registered slightly before landing still works
  jumpBufferTimer: 0,     // ms remaining of jump buffer window

  // ---------------------------------------------------------------------------
  // DASH TRACKING
  // ---------------------------------------------------------------------------
  isDashing:      false,
  dashTimer:      0,      // ms remaining in current dash burst
  dashCooldown:   0,      // ms remaining before next dash is allowed
  dashDirection:  1,      // direction at moment dash was triggered

  // ---------------------------------------------------------------------------
  // WALL JUMP TRACKING
  // ---------------------------------------------------------------------------
  isWallSliding:      false,
  wallJumpDirection:  0,    // -1 = wall on right (jump left), 1 = wall on left (jump right)

  // ---------------------------------------------------------------------------
  // INVINCIBILITY
  // Active during dash and after respawn.
  // While true: obstacle collisions are ignored.
  // ---------------------------------------------------------------------------
  isInvincible:     false,
  invincibleTimer:  0,      // ms remaining

  // ---------------------------------------------------------------------------
  // DEATH / RESPAWN
  // ---------------------------------------------------------------------------
  isDead:       false,
  deathTimer:   0,          // ms remaining in death flash animation
  flashTimer:   0,          // ms until next visibility toggle
  visible:      true,       // toggled during death flash

  // ---------------------------------------------------------------------------
  // INIT
  // Called by levelLoader when a level starts or restarts.
  // Sets starting position and resets all state.
  // ---------------------------------------------------------------------------
  init(startX, startY) {
    const C = window.Game.constants;

    // Dimensions from constants
    this.width  = C.PLAYER_WIDTH;
    this.height = C.PLAYER_HEIGHT;

    // Position
    this.x  = startX;
    this.y  = startY;
    this.vx = 0;
    this.vy = 0;

    // Contact flags
    this.onGround  = false;
    this.onCeiling = false;
    this.onWall    = false;

    // State
    this.animationState  = 'idle';
    this.facingDirection = 1;

    // Jump
    this.jumpsUsed      = 0;
    this.canDoubleJump  = true;
    this.coyoteTimer    = 0;
    this.jumpBufferTimer = 0;

    // Dash
    this.isDashing     = false;
    this.dashTimer     = 0;
    this.dashCooldown  = 0;
    this.dashDirection = 1;

    // Wall
    this.isWallSliding     = false;
    this.wallJumpDirection = 0;

    // Invincibility
    this.isInvincible    = false;
    this.invincibleTimer = 0;

    // Death
    this.isDead     = false;
    this.deathTimer = 0;
    this.flashTimer = 0;
    this.visible    = true;

    console.log(`player.js: Initialized at (${startX}, ${startY}).`);
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // Master update called every frame by game.js during GAMEPLAY.
  // Coordinates all sub-systems in the correct order.
  // deltaTime in seconds.
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    const C       = window.Game.constants;
    const physics = window.Game.physics;
    const level   = window.Game.level;

    // --- Don't update during death animation ---
    if (this.isDead) {
      this._updateDeathAnimation(deltaTime);
      return;
    }

    // --- Count down timers ---
    this._updateTimers(deltaTime);

    // --- Apply gravity (modifies vy) ---
    physics.applyGravity(this, deltaTime);

    // --- Apply wall slide (clamps vy if on wall) ---
    if (this.isWallSliding && !this.onGround) {
      physics.applyWallSlide(this);
    }

    // --- Handle player input → movement ---
    // movement.js functions are called here
    window.Game.movement.handleWalk(this, window.Game.controls.input, deltaTime);
    window.Game.movement.handleJump(this, window.Game.controls.input);
    window.Game.movement.handleDash(this, window.Game.controls.input, deltaTime);
    window.Game.movement.handleWallJump(this, window.Game.controls.input);

    // --- Move and collide against level platforms ---
    const platforms = level ? level.getAllSolidPlatforms() : [];
    const collision = physics.moveAndCollide(this, platforms, deltaTime);

    // --- Process collision results ---
    this._processCollision(collision);

    // --- Check if fell into death pit ---
    if (physics.isInDeathPit(this)) {
      this.takeDamage();
      return;
    }

    // --- Check if fell off left edge ---
    if (physics.isOffLeftEdge(this)) {
      // Push player back to left boundary instead of killing
      this.x  = 0;
      this.vx = 0;
    }

    // --- Update animation state ---
    this._updateAnimationState();
  },

  // ---------------------------------------------------------------------------
  // _updateTimers (private)
  // Counts down all timer-based mechanics.
  // deltaTime in seconds — convert to ms by multiplying by 1000.
  // ---------------------------------------------------------------------------
  _updateTimers(deltaTime) {
    const C   = window.Game.constants;
    const ms  = deltaTime * 1000;   // convert seconds → ms for timer comparisons

    // Dash duration — how long the boost lasts
    if (this.isDashing) {
      this.dashTimer -= ms;
      if (this.dashTimer <= 0) {
        this.isDashing  = false;
        this.dashTimer  = 0;
        // vx is NOT zeroed here — player keeps some momentum after dash ends
      }
    }

    // Dash cooldown — how long until dash can be used again
    if (this.dashCooldown > 0) {
      this.dashCooldown -= ms;
      if (this.dashCooldown < 0) this.dashCooldown = 0;
    }

    // Invincibility window (dash + post-respawn)
    if (this.isInvincible) {
      this.invincibleTimer -= ms;
      if (this.invincibleTimer <= 0) {
        this.isInvincible    = false;
        this.invincibleTimer = 0;
      }
    }

    // Coyote time — forgiveness window after walking off a ledge
    if (this.coyoteTimer > 0) {
      this.coyoteTimer -= ms;
      if (this.coyoteTimer < 0) this.coyoteTimer = 0;
    }

    // Jump buffer — forgiveness window for pressing jump just before landing
    if (this.jumpBufferTimer > 0) {
      this.jumpBufferTimer -= ms;
      if (this.jumpBufferTimer < 0) this.jumpBufferTimer = 0;
    }
  },

  // ---------------------------------------------------------------------------
  // _processCollision (private)
  // Reacts to the collision report from physics.moveAndCollide().
  // ---------------------------------------------------------------------------
  _processCollision(collision) {
    const C = window.Game.constants;

    if (collision.hitGround) {
      // Landed — reset jump counters
      this.jumpsUsed     = 0;
      this.canDoubleJump = true;
      this.coyoteTimer   = 0;
      this.isWallSliding = false;

      // If jump was buffered (pressed just before landing) — execute it now
      if (this.jumpBufferTimer > 0) {
        this.jumpBufferTimer = 0;
        window.Game.movement.executeJump(this);
      }
    }

    if (!collision.hitGround && this.onGround === false) {
      // Player just walked off a ledge (not jumped)
      // Start coyote time so they can still jump briefly
      if (this.jumpsUsed === 0 && this.coyoteTimer <= 0) {
        this.coyoteTimer = C.COYOTE_TIME_MS;
      }
    }

    if (collision.hitWallLeft || collision.hitWallRight) {
      // Touching a wall while airborne = wall slide
      if (!this.onGround) {
        this.isWallSliding     = true;
        // Wall is on the right if hitWallRight → player should jump LEFT (-1)
        this.wallJumpDirection = collision.hitWallRight ? -1 : 1;
      }
    } else {
      this.isWallSliding     = false;
      this.wallJumpDirection = 0;
    }

    if (collision.hitCeiling) {
      // Bonked ceiling — cancel upward velocity
      this.vy = 0;
    }
  },

  // ---------------------------------------------------------------------------
  // _updateAnimationState (private)
  // Sets animationState based on current physics state.
  // movement.js can also set animationState directly for immediate reactions
  // (e.g. setting 'jump' the exact frame the jump button is pressed).
  // This function sets the fallback/continuous states.
  // ---------------------------------------------------------------------------
  _updateAnimationState() {
    // Don't override death or spawn states
    if (this.isDead) return;

    // Dash overrides everything while active
    if (this.isDashing) {
      this.animationState = 'dash';
      return;
    }

    // Wall slide
    if (this.isWallSliding && !this.onGround) {
      this.animationState = 'wall_slide';
      return;
    }

    // Airborne (jump/fall) — only override if movement.js hasn't set jump/double_jump
    if (!this.onGround) {
      if (this.animationState !== 'jump' && this.animationState !== 'double_jump') {
        this.animationState = 'jump';   // falling without jumping = still 'jump' pose
      }
      return;
    }

    // On ground — run or idle based on horizontal velocity
    if (Math.abs(this.vx) > 10) {
      this.animationState = 'run';
    } else {
      this.animationState = 'idle';
    }
  },

  // ---------------------------------------------------------------------------
  // _updateDeathAnimation (private)
  // Runs the red flash animation while isDead is true.
  // stateManager handles the respawn/game-over logic via setTimeout.
  // ---------------------------------------------------------------------------
  _updateDeathAnimation(deltaTime) {
    const C  = window.Game.constants;
    const ms = deltaTime * 1000;

    this.deathTimer -= ms;
    this.flashTimer -= ms;

    // Toggle visibility on each flash interval
    if (this.flashTimer <= 0) {
      this.visible    = !this.visible;
      this.flashTimer = C.DEATH_FLASH_INTERVAL;
    }

    // When death timer expires, stay visible for the final frame
    if (this.deathTimer <= 0) {
      this.visible = true;
      // stateManager's setTimeout has already queued the next state transition
      // player.isDead stays true until respawn() is called
    }
  },

  // ---------------------------------------------------------------------------
  // TAKE DAMAGE
  // Triggers the death sequence.
  // Called by obstacleManager on collision, or by physics on pit fall.
  // Does nothing if player is currently invincible.
  // ---------------------------------------------------------------------------
  takeDamage() {
    if (this.isInvincible) return;   // dash/spawn protection
    if (this.isDead)       return;   // already dying — don't double-trigger

    const C = window.Game.constants;

    this.isDead         = true;
    this.deathTimer     = C.DEATH_FLASH_MS;
    this.flashTimer     = C.DEATH_FLASH_INTERVAL;
    this.animationState = 'death';
    this.vx             = 0;
    this.vy             = 0;

    // Transition to DEATH_ANIMATION state — stateManager handles the rest
    // (decrements lives, queues respawn or game over)
    if (window.Game.state) {
      window.Game.state.transition('DEATH_ANIMATION');
    }
  },

  // ---------------------------------------------------------------------------
  // RESPAWN
  // Called by stateManager after death animation completes.
  // Resets player to checkpoint (or level start) position.
  // ---------------------------------------------------------------------------
  respawn(x, y) {
    const C = window.Game.constants;

    this.x  = x;
    this.y  = y;
    this.vx = 0;
    this.vy = 0;

    // Reset all movement state
    this.jumpsUsed       = 0;
    this.canDoubleJump   = true;
    this.coyoteTimer     = 0;
    this.jumpBufferTimer = 0;
    this.isDashing       = false;
    this.dashTimer       = 0;
    this.dashCooldown    = 0;
    this.isWallSliding   = false;

    // Reset death state
    this.isDead         = false;
    this.deathTimer     = 0;
    this.visible        = true;
    this.animationState = 'idle';

    // Grant invincibility window so player doesn't immediately re-die
    this.isInvincible    = true;
    this.invincibleTimer = C.SPAWN_INVINCIBLE_MS;

    // Clear exhaust particles from previous life
    if (window.Game.particles) {
      window.Game.particles.clear();
    }

    console.log(`player.js: Respawned at (${x}, ${y}).`);
  },

  // ---------------------------------------------------------------------------
  // GET CENTER
  // Returns the center point of the player's collision box.
  // Used by collectible radius checks and particle emission.
  // ---------------------------------------------------------------------------
  getCenter() {
    return {
      x: this.x + this.width  / 2,
      y: this.y + this.height / 2,
    };
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Delegates to animator.js for sprite rendering.
  // Falls back to a colored rectangle if sprites aren't loaded yet.
  // ---------------------------------------------------------------------------
  draw(ctx) {
    if (!this.visible) return;   // skip draw during death flash invisible frames

    if (window.Game.animator) {
      window.Game.animator.draw(ctx, this);
    } else {
      // Fallback: colored rectangle (used before sprites are loaded)
      ctx.fillStyle = this.isInvincible
        ? `rgba(100, 180, 255, ${0.5 + 0.5 * Math.sin(Date.now() / 80)})` // blue pulse
        : '#4af';
      ctx.fillRect(this.x, this.y, this.width, this.height);

      // Draw a direction indicator (small dot on facing side)
      ctx.fillStyle = '#fff';
      const dotX = this.facingDirection === 1
        ? this.x + this.width - 6
        : this.x + 2;
      ctx.fillRect(dotX, this.y + 8, 4, 4);
    }
  },

  // ---------------------------------------------------------------------------
  // GET DASH COOLDOWN RATIO
  // Returns 0.0 (cooldown active) to 1.0 (dash ready).
  // Used by hud.js to draw the cooldown bar.
  // ---------------------------------------------------------------------------
  getDashCooldownRatio() {
    const C = window.Game.constants;
    if (this.dashCooldown <= 0) return 1.0;
    return 1.0 - (this.dashCooldown / C.DASH_COOLDOWN_MS);
  },

};
