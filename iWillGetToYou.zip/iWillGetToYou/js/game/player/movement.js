// =============================================================================
// movement.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// All player movement logic lives here.
// These functions are called by player.update() every frame.
// They read from Game.controls.input and write to the player object.
// They also trigger audio and particles at the correct moments.
//
// FUNCTION CALL ORDER IN player.update():
//   1. handleWalk     — horizontal movement from left/right input
//   2. handleJump     — jump and double jump
//   3. handleDash     — rocket boost
//   4. handleWallJump — jump off walls
//   (then physics.moveAndCollide runs to resolve position)
// =============================================================================

window.Game = window.Game || {};

window.Game.movement = {

  // ---------------------------------------------------------------------------
  // HANDLE WALK
  // Applies horizontal velocity based on left/right input.
  // Uses acceleration rather than instant velocity for a responsive but
  // smooth feel. Low gravity means slightly looser air control.
  // ---------------------------------------------------------------------------
  handleWalk(player, input, deltaTime) {
    const C = window.Game.constants;

    // During an active dash — don't allow directional input to override vx
    // The dash force controls horizontal movement completely during the burst
    if (player.isDashing) return;

    if (input.left) {
      // Accelerate left
      player.vx -= C.WALK_ACCELERATION * deltaTime;
      // Clamp to max walk speed
      if (player.vx < -C.WALK_SPEED) player.vx = -C.WALK_SPEED;
      player.facingDirection = -1;

    } else if (input.right) {
      // Accelerate right
      player.vx += C.WALK_ACCELERATION * deltaTime;
      if (player.vx > C.WALK_SPEED) player.vx = C.WALK_SPEED;
      player.facingDirection = 1;

    } else {
      // No directional input — apply friction to slow down
      if (player.onGround) {
        window.Game.physics.applyGroundFriction(player);
      } else {
        window.Game.physics.applyAirFriction(player);
      }
    }

    // Wall jump gives horizontal momentum that should not be immediately
    // cancelled by the player holding the opposite direction key.
    // This is handled by the acceleration approach — vx will resist the
    // wall jump direction change for a brief moment naturally.
  },

  // ---------------------------------------------------------------------------
  // HANDLE JUMP
  // Checks for jump input and executes first or second jump.
  // Uses coyote time and jump buffer for a forgiving, fair feel.
  // ---------------------------------------------------------------------------
  handleJump(player, input) {
    const C = window.Game.constants;

    // --- Jump button pressed this frame ---
    if (input.jump) {

      // Can we do a first jump?
      // Conditions: on ground OR within coyote time window, AND haven't jumped yet
      const canFirstJump = (player.onGround || player.coyoteTimer > 0)
                           && player.jumpsUsed === 0;

      // Can we do a wall jump?
      // Conditions: touching a wall, airborne, wall is tagged wallJumpable
      const canWallJump = player.isWallSliding
                          && !player.onGround;

      // Can we do a double jump?
      // Conditions: already used first jump, haven't used second, not wall sliding
      const canDoubleJump = player.jumpsUsed === 1
                            && player.canDoubleJump
                            && !player.isWallSliding;

      if (canWallJump) {
        this.executeWallJump(player);
      } else if (canFirstJump) {
        this.executeJump(player);
      } else if (canDoubleJump) {
        this.executeDoubleJump(player);
      } else {
        // Can't jump right now — store in jump buffer
        // If player lands within JUMP_BUFFER_MS, the jump will execute
        player.jumpBufferTimer = C.JUMP_BUFFER_MS;
      }
    }
  },

  // ---------------------------------------------------------------------------
  // EXECUTE JUMP (first jump)
  // Called by handleJump and by player._processCollision (for jump buffer).
  // ---------------------------------------------------------------------------
  executeJump(player) {
    const C = window.Game.constants;

    player.vy            = C.JUMP_VELOCITY;   // negative = upward
    player.jumpsUsed     = 1;
    player.coyoteTimer   = 0;                 // used the jump — cancel coyote
    player.animationState = 'jump';

    // Audio and particles
    if (window.Game.audio)     window.Game.audio.play('jump');
    if (window.Game.particles) {
      const center = player.getCenter();
      window.Game.particles.emit('exhaust', center.x, player.y + player.height, 3);
    }
  },

  // ---------------------------------------------------------------------------
  // EXECUTE DOUBLE JUMP (second jump in the air)
  // ---------------------------------------------------------------------------
  executeDoubleJump(player) {
    const C = window.Game.constants;

    player.vy             = C.DOUBLE_JUMP_VELOCITY;
    player.jumpsUsed      = 2;
    player.canDoubleJump  = false;
    player.animationState = 'double_jump';

    // Double jump gets a bigger exhaust burst — more dramatic
    if (window.Game.audio)     window.Game.audio.play('double_jump');
    if (window.Game.particles) {
      const center = player.getCenter();
      // Burst both left and right for a rocket-boot feel
      window.Game.particles.emit('exhaust', center.x - 8, player.y + player.height, 4);
      window.Game.particles.emit('exhaust', center.x + 8, player.y + player.height, 4);
    }
  },

  // ---------------------------------------------------------------------------
  // EXECUTE WALL JUMP
  // Pushes player away from wall with upward force.
  // Resets double jump availability so player can use it after wall jumping.
  // ---------------------------------------------------------------------------
  executeWallJump(player) {
    const C = window.Game.constants;

    // wallJumpDirection is set by player._processCollision:
    //   -1 = wall on right → jump left
    //    1 = wall on left  → jump right
    player.vx             = C.WALL_JUMP_FORCE_X * player.wallJumpDirection;
    player.vy             = C.WALL_JUMP_FORCE_Y;
    player.jumpsUsed      = 1;    // counts as first jump — double jump still available
    player.canDoubleJump  = true;
    player.isWallSliding  = false;
    player.facingDirection = player.wallJumpDirection;
    player.animationState = 'jump';

    if (window.Game.audio)     window.Game.audio.play('jump');
    if (window.Game.particles) {
      // Particles emit FROM the wall surface
      const wallX = player.wallJumpDirection === 1
        ? player.x                   // wall on left
        : player.x + player.width;   // wall on right
      window.Game.particles.emit('exhaust', wallX, player.getCenter().y, 5);
    }
  },

  // ---------------------------------------------------------------------------
  // HANDLE DASH
  // Triggers rocket boost on dash input if not on cooldown.
  // During the dash: velocity is set to DASH_FORCE, input is ignored for vx.
  // After dash: player retains some forward momentum (not zeroed).
  // ---------------------------------------------------------------------------
  handleDash(player, input, deltaTime) {
    const C = window.Game.constants;

    // --- Trigger new dash ---
    if (input.dash && player.dashCooldown <= 0 && !player.isDashing) {

      player.isDashing     = true;
      player.dashTimer     = C.DASH_DURATION_MS;
      player.dashCooldown  = C.DASH_COOLDOWN_MS;
      player.dashDirection = player.facingDirection;

      // Set velocity to full dash force in facing direction
      player.vx = C.DASH_FORCE * player.dashDirection;

      // Zero out vertical velocity during dash — horizontal bolt only
      // This makes dash feel powerful and controlled, not chaotic
      player.vy = 0;

      // Grant brief invincibility window
      player.isInvincible    = true;
      player.invincibleTimer = Math.max(
        player.invincibleTimer,
        C.DASH_INVINCIBLE_MS
      );

      player.animationState = 'dash';

      // Audio — rocket burst
      if (window.Game.audio) window.Game.audio.play('dash');

      // Particle exhaust burst — large initial emission
      if (window.Game.particles) {
        const center = player.getCenter();
        window.Game.particles.emit('exhaust', center.x, center.y, C.EXHAUST_COUNT);
      }
    }

    // --- Continuous exhaust trail during active dash ---
    if (player.isDashing && window.Game.particles) {
      // Emit a smaller stream of particles every frame while dashing
      // Throttle to avoid overwhelming the particle pool
      if (Math.random() < 0.6) {   // 60% chance each frame = natural variation
        const center = player.getCenter();
        window.Game.particles.emit('exhaust', center.x, center.y, 2);
      }
    }
  },

  // ---------------------------------------------------------------------------
  // HANDLE WALL JUMP
  // Wall jump input detection is handled inside handleJump above.
  // This function handles the VISUAL of wall sliding each frame.
  // ---------------------------------------------------------------------------
  handleWallJump(player, input) {
    // If player is wall sliding, update facing direction to look away from wall
    if (player.isWallSliding && !player.onGround) {
      // Face away from the wall (toward where they would jump)
      player.facingDirection = player.wallJumpDirection;
      player.animationState  = 'wall_slide';

      // Occasional small particle drip to show wall friction
      if (window.Game.particles && Math.random() < 0.15) {
        const wallX = player.wallJumpDirection === 1
          ? player.x
          : player.x + player.width;
        window.Game.particles.emit('sparkle', wallX, player.y + player.height * 0.6, 1);
      }
    }
  },

};
