// =============================================================================
// animator.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Reads player.animationState and draws the correct sprite frame.
// Handles:
//   - Frame advancement at per-animation FPS rates
//   - Horizontal flipping for left-facing direction
//   - Death flash visibility (tied to player.visible)
//   - Invincibility blue tint pulse
//   - Fallback rectangle if sprites not loaded
//
// SPRITE SHEET FORMAT:
//   Each animation is a single horizontal strip of frames.
//   Frame 0 is at x=0, frame 1 at x=frameWidth, etc.
//   All frames in one sheet are the same width and height.
// =============================================================================

window.Game = window.Game || {};

window.Game.animator = {

  // ---------------------------------------------------------------------------
  // ANIMATION DEFINITIONS
  // Each entry defines one animation state.
  // 'key' matches player.animationState values.
  // 'frames' is the total number of frames in the sprite sheet.
  // 'fps' is how many frames to advance per second.
  // 'loop' — false means stop on the last frame (e.g. death).
  // ---------------------------------------------------------------------------
  animations: {
    idle: {
      key:    'idle',
      frames: 4,
      fps:    6,
      loop:   true,
    },
    run: {
      key:    'run',
      frames: 8,
      fps:    12,
      loop:   true,
    },
    jump: {
      key:    'jump',
      frames: 3,
      fps:    8,
      loop:   false,   // hold last frame while airborne
    },
    double_jump: {
      key:    'double_jump',
      frames: 4,
      fps:    12,
      loop:   false,
    },
    dash: {
      key:    'dash',
      frames: 3,
      fps:    14,
      loop:   false,
    },
    wall_slide: {
      key:    'wall_slide',
      frames: 2,
      fps:    6,
      loop:   true,
    },
    death: {
      key:    'death',
      frames: 6,
      fps:    8,
      loop:   false,   // plays once and holds last frame
    },
    spawn: {
      key:    'idle',   // spawn uses idle sprite, invincibility handled via tint
      frames: 4,
      fps:    6,
      loop:   true,
    },
  },

  // ---------------------------------------------------------------------------
  // CURRENT ANIMATION STATE
  // ---------------------------------------------------------------------------
  currentAnim:  'idle',    // which animation is active
  currentFrame: 0,         // which frame index within that animation
  frameTimer:   0,         // ms accumulated since last frame advance

  // ---------------------------------------------------------------------------
  // SPRITE FRAME DIMENSIONS
  // Read from the loaded image dimensions.
  // Assumes all frames in a sheet are equal width.
  // ---------------------------------------------------------------------------
  frameWidth:  32,   // pixels per frame (matches PLAYER_WIDTH)
  frameHeight: 48,   // pixels per frame (matches PLAYER_HEIGHT)

  // ---------------------------------------------------------------------------
  // UPDATE
  // Advances the animation frame timer.
  // Called every frame by game.js (could also be called by player.update).
  // deltaTime in seconds.
  // ---------------------------------------------------------------------------
  update(deltaTime, player) {
    const animKey  = player.animationState;
    const animDef  = this.animations[animKey] || this.animations['idle'];

    // If animation changed — reset frame counter
    if (animKey !== this.currentAnim) {
      this.currentAnim  = animKey;
      this.currentFrame = 0;
      this.frameTimer   = 0;
    }

    // Accumulate time (convert seconds to ms)
    this.frameTimer += deltaTime * 1000;

    // Frame duration in ms
    const frameDuration = 1000 / animDef.fps;

    if (this.frameTimer >= frameDuration) {
      this.frameTimer -= frameDuration;

      if (animDef.loop) {
        // Loop back to frame 0 after the last frame
        this.currentFrame = (this.currentFrame + 1) % animDef.frames;
      } else {
        // Non-looping — stop at last frame
        this.currentFrame = Math.min(this.currentFrame + 1, animDef.frames - 1);
      }
    }
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Renders the current animation frame at the player's world position.
  // ctx: the canvas 2D context (camera transform already applied by game.js)
  // player: Game.player object
  // ---------------------------------------------------------------------------
  draw(ctx, player) {
    // Respect death flash visibility flag
    if (!player.visible) return;

    const assets   = window.Game.preloader ? window.Game.preloader.assets : null;
    const animKey  = player.animationState === 'spawn' ? 'idle' : player.animationState;
    const animDef  = this.animations[animKey] || this.animations['idle'];

    // Get the sprite image for this animation state
    // Key mapping: animationState → preloader.assets.sprites key
    const spriteKey = this._getSpriteKey(animKey);
    const sprite    = assets && assets.sprites ? assets.sprites[spriteKey] : null;

    ctx.save();

    // --- Invincibility pulse: blue tint overlay ---
    if (player.isInvincible && !player.isDead) {
      // Pulsing alpha gives a clear visual cue without obscuring the sprite
      const pulseAlpha = 0.3 + 0.3 * Math.sin(Date.now() / 60);
      ctx.globalAlpha  = pulseAlpha;
      // We'll draw a blue rect under the sprite first, then restore alpha
      ctx.fillStyle = '#66aaff';
      ctx.fillRect(player.x, player.y, player.width, player.height);
      ctx.globalAlpha = 1.0;
    }

    // --- Horizontal flip for left-facing ---
    // Canvas doesn't have a built-in flip — we translate and scale instead
    if (player.facingDirection === -1) {
      // Move origin to the right edge of the sprite, then scale X by -1
      ctx.translate(player.x + player.width, player.y);
      ctx.scale(-1, 1);
      // After this transform, draw at (0, 0) instead of (player.x, player.y)
    }

    const drawX = player.facingDirection === -1 ? 0        : player.x;
    const drawY = player.facingDirection === -1 ? 0        : player.y;

    if (sprite) {
      // --- Draw sprite sheet frame ---
      // Source rectangle: the specific frame within the sheet
      const srcX = this.currentFrame * this.frameWidth;
      const srcY = 0;

      ctx.drawImage(
        sprite,
        srcX,            srcY,             // source: frame position in sheet
        this.frameWidth, this.frameHeight, // source: frame size
        drawX,           drawY,            // destination: screen position
        player.width,    player.height     // destination: display size
      );

    } else {
      // --- Fallback: colored rectangle with animation state label ---
      // Used when sprites aren't loaded yet (during development)
      const colors = {
        idle:        '#4488ff',
        run:         '#44aaff',
        jump:        '#44ffaa',
        double_jump: '#88ff44',
        dash:        '#ff8844',
        wall_slide:  '#aa44ff',
        death:       '#ff4444',
        spawn:       '#88ccff',
      };

      ctx.fillStyle = colors[animKey] || '#4488ff';
      ctx.fillRect(drawX, drawY, player.width, player.height);

      // Visor — a small dark rectangle on the helmet
      ctx.fillStyle = 'rgba(0,0,0,0.4)';
      ctx.fillRect(drawX + 6, drawY + 8, player.width - 12, 10);

      // Direction dot — shows which way player is facing
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(drawX + player.width - 8, drawY + 10, 4, 4);
    }

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _getSpriteKey (private)
  // Maps animation state names to preloader asset keys.
  // Some states share a sprite (e.g. double_jump uses jump sprite).
  // ---------------------------------------------------------------------------
  _getSpriteKey(animState) {
    const keyMap = {
      idle:        'idle',
      run:         'run',
      jump:        'jump',
      double_jump: 'jump',     // reuses jump sprite (different particle effect differentiates)
      dash:        'dash',
      wall_slide:  'jump',     // reuses jump sprite for wall slide
      death:       'death',
    };
    return keyMap[animState] || 'idle';
  },

};
