// =============================================================================
// physics.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// The collision and movement engine.
// ALL physics calculations multiply by deltaTime (seconds) so the game runs
// at the same speed on every device regardless of frame rate.
//
// Collision uses AABB (Axis-Aligned Bounding Box) — rectangles only.
// This is the correct choice for a 2D platformer: fast, predictable, debuggable.
//
// COLLISION RESOLUTION ORDER (critical for correctness):
//   1. Move entity horizontally by vx * deltaTime
//   2. Resolve horizontal collisions
//   3. Move entity vertically by vy * deltaTime
//   4. Resolve vertical collisions
// Separating axes prevents corner-catching bugs.
// =============================================================================

window.Game = window.Game || {};

window.Game.physics = {

  // ---------------------------------------------------------------------------
  // APPLY GRAVITY
  // Accelerates entity downward each frame.
  // Does NOT move the entity — just changes vy.
  // Call this BEFORE moveAndCollide each frame.
  // entity must have: { vy, onGround }
  // ---------------------------------------------------------------------------
  applyGravity(entity, deltaTime) {
    const C = window.Game.constants;

    // Don't accumulate gravity if standing on the ground
    if (entity.onGround) {
      entity.vy = 0;
      return;
    }

    // Accelerate downward (positive Y = down in canvas coordinates)
    entity.vy += C.GRAVITY * deltaTime;

    // Clamp to terminal velocity
    if (entity.vy > C.MAX_FALL_SPEED) {
      entity.vy = C.MAX_FALL_SPEED;
    }
  },

  // ---------------------------------------------------------------------------
  // MOVE AND COLLIDE
  // The core platformer physics step.
  // Moves entity by its velocity and resolves collisions against platforms.
  //
  // entity: object with { x, y, vx, vy, width, height, onGround, onWall, onCeiling }
  // platforms: array of { x, y, width, height, wallJumpable, type }
  // deltaTime: seconds since last frame
  //
  // Returns a collision report object describing what was hit this frame.
  // entity.onGround / onWall / onCeiling are SET here — read by movement.js.
  // ---------------------------------------------------------------------------
  moveAndCollide(entity, platforms, deltaTime) {

    // Reset contact flags at the start of each frame
    // They will be re-set if collision is detected below
    entity.onGround  = false;
    entity.onCeiling = false;
    entity.onWall    = false;

    const report = {
      hitGround:    false,
      hitCeiling:   false,
      hitWallLeft:  false,
      hitWallRight: false,
      wallJumpable: false,   // true if the wall hit has wallJumpable: true
    };

    // -------------------------------------------------------------------------
    // STEP 1: Horizontal movement
    // -------------------------------------------------------------------------
    entity.x += entity.vx * deltaTime;

    // Check horizontal collisions
    for (let i = 0; i < platforms.length; i++) {
      const plat = platforms[i];

      if (!this._overlaps(entity, plat)) continue;

      // Entity is inside this platform horizontally
      if (entity.vx > 0) {
        // Moving right — push entity to the left edge of the platform
        entity.x        = plat.x - entity.width;
        report.hitWallRight  = true;
        report.wallJumpable  = plat.wallJumpable || false;
        entity.onWall        = true;
        entity.vx            = 0;
      } else if (entity.vx < 0) {
        // Moving left — push entity to the right edge of the platform
        entity.x        = plat.x + plat.width;
        report.hitWallLeft   = true;
        report.wallJumpable  = plat.wallJumpable || false;
        entity.onWall        = true;
        entity.vx            = 0;
      }
    }

    // -------------------------------------------------------------------------
    // STEP 2: Vertical movement
    // -------------------------------------------------------------------------
    entity.y += entity.vy * deltaTime;

    // Check vertical collisions
    for (let i = 0; i < platforms.length; i++) {
      const plat = platforms[i];

      if (!this._overlaps(entity, plat)) continue;

      if (entity.vy > 0) {
        // Falling down — land on top of platform
        entity.y          = plat.y - entity.height;
        entity.vy         = 0;
        entity.onGround   = true;
        report.hitGround  = true;
      } else if (entity.vy < 0) {
        // Moving up — hit ceiling, push down
        entity.y          = plat.y + plat.height;
        entity.vy         = 0;
        entity.onCeiling  = true;
        report.hitCeiling = true;
      }
    }

    return report;
  },

  // ---------------------------------------------------------------------------
  // CHECK OVERLAP (AABB)
  // Returns true if two rectangle entities overlap.
  // Each must have: { x, y, width, height }
  // Used for collectible pickup and entity-vs-entity checks.
  // ---------------------------------------------------------------------------
  checkOverlap(a, b) {
    return this._overlaps(a, b);
  },

  // ---------------------------------------------------------------------------
  // _overlaps (private)
  // Internal AABB test. Returns true if rectangles a and b intersect.
  // ---------------------------------------------------------------------------
  _overlaps(a, b) {
    return (
      a.x             < b.x + b.width  &&
      a.x + a.width   > b.x            &&
      a.y             < b.y + b.height &&
      a.y + a.height  > b.y
    );
  },

  // ---------------------------------------------------------------------------
  // CHECK CIRCLE OVERLAP
  // Returns true if a point (cx, cy) with a given radius overlaps a rectangle.
  // Used for explosion radius check — explosions kill in a circle, not a box.
  // cx, cy: center of circle (world coordinates)
  // radius: explosion radius
  // entity: rectangle with { x, y, width, height }
  // ---------------------------------------------------------------------------
  checkCircleOverlap(cx, cy, radius, entity) {
    // Find the closest point on the rectangle to the circle center
    const closestX = Math.max(entity.x, Math.min(cx, entity.x + entity.width));
    const closestY = Math.max(entity.y, Math.min(cy, entity.y + entity.height));

    // Calculate distance from circle center to that closest point
    const distX = cx - closestX;
    const distY = cy - closestY;
    const distSq = (distX * distX) + (distY * distY);

    return distSq <= (radius * radius);
  },

  // ---------------------------------------------------------------------------
  // CHECK COLLECT RADIUS
  // Returns true if player is within collectible pickup range.
  // More forgiving than strict AABB — gives the player the benefit of the doubt.
  // px, py: player center
  // rx, ry: ring center
  // radius: collect radius from constants
  // ---------------------------------------------------------------------------
  checkCollectRadius(px, py, rx, ry, radius) {
    const distX = px - rx;
    const distY = py - ry;
    return (distX * distX + distY * distY) <= (radius * radius);
  },

  // ---------------------------------------------------------------------------
  // IS IN DEATH PIT
  // Returns true if entity has fallen below the bottom of the level.
  // Anything more than 200 pixels below canvas bottom is considered a pit.
  // ---------------------------------------------------------------------------
  isInDeathPit(entity) {
    const C = window.Game.constants;
    return entity.y > C.CANVAS_HEIGHT + 200;
  },

  // ---------------------------------------------------------------------------
  // IS OFF LEFT EDGE
  // Returns true if entity exits the left side of the world.
  // (Player cannot go further left than the start of the level)
  // ---------------------------------------------------------------------------
  isOffLeftEdge(entity) {
    return entity.x + entity.width < -100;
  },

  // ---------------------------------------------------------------------------
  // APPLY WALL SLIDE FRICTION
  // When player is on a wall and falling, clamp their fall speed.
  // Creates the satisfying "sliding down a wall" effect.
  // ---------------------------------------------------------------------------
  applyWallSlide(entity) {
    const C = window.Game.constants;
    if (entity.vy > C.WALL_SLIDE_SPEED) {
      entity.vy = C.WALL_SLIDE_SPEED;
    }
  },

  // ---------------------------------------------------------------------------
  // APPLY GROUND FRICTION
  // Decelerates horizontal movement when on the ground.
  // Called by movement.js when no directional input is pressed.
  // ---------------------------------------------------------------------------
  applyGroundFriction(entity) {
    const C = window.Game.constants;
    entity.vx *= C.FRICTION_GROUND;

    // Snap to zero to prevent infinite slow slide
    if (Math.abs(entity.vx) < 2) {
      entity.vx = 0;
    }
  },

  // ---------------------------------------------------------------------------
  // APPLY AIR FRICTION
  // Lighter deceleration while airborne.
  // ---------------------------------------------------------------------------
  applyAirFriction(entity) {
    const C = window.Game.constants;
    entity.vx *= C.FRICTION_AIR;
  },

};
