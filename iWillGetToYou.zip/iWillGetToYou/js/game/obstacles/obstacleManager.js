// =============================================================================
// obstacleManager.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Central manager for ALL obstacles in the current level.
// Responsibilities:
//   - Initializing obstacle objects from level data
//   - Updating all obstacles each frame (crushers, platforms, explosions)
//   - Providing the solid platform list to physics.moveAndCollide()
//   - Detecting collisions between obstacles and the player
//   - Carrying the player when standing on a moving platform
//   - Drawing all obstacles in the correct order
//   - Resetting obstacles on death/restart
//
// COLLISION PRIORITY:
//   1. Moving platforms  — solid surfaces, player lands on them
//   2. Crushers          — lethal when in 'crushing' or 'holding' phase
//   3. Explosions        — lethal in radius during 'exploding' phase
//
// Dash invincibility protects against crushers but NOT explosions.
// (Explosions require timing, not reflexes — this is a design decision.)
// =============================================================================

window.Game = window.Game || {};

window.Game.obstacles = {

  // ---------------------------------------------------------------------------
  // STORAGE
  // ---------------------------------------------------------------------------
  crushers:        [],   // all Crusher objects in the current level
  movingPlatforms: [],   // all MovingPlatform objects
  explosions:      [],   // all Explosion objects

  // ---------------------------------------------------------------------------
  // INIT
  // Called by levelLoader when a level loads.
  // Creates all obstacle objects from the level's raw data arrays.
  //
  // obstaclesData shape:
  // {
  //   crushers:        [ { ...crusher data } ],
  //   movingPlatforms: [ { ...platform data } ],
  //   explosions:      [ { ...explosion data } ],
  // }
  // ---------------------------------------------------------------------------
  init(obstaclesData) {
    this.crushers        = [];
    this.movingPlatforms = [];
    this.explosions      = [];

    // Create crushers
    if (obstaclesData.crushers) {
      obstaclesData.crushers.forEach(data => {
        this.crushers.push(window.Game.Crusher.create(data));
      });
    }

    // Create moving platforms
    if (obstaclesData.movingPlatforms) {
      obstaclesData.movingPlatforms.forEach(data => {
        this.movingPlatforms.push(window.Game.MovingPlatform.create(data));
      });
    }

    // Create explosion zones
    if (obstaclesData.explosions) {
      obstaclesData.explosions.forEach(data => {
        this.explosions.push(window.Game.Explosion.create(data));
      });
    }

    console.log(
      `obstacleManager.js: Loaded — ` +
      `${this.crushers.length} crushers, ` +
      `${this.movingPlatforms.length} moving platforms, ` +
      `${this.explosions.length} explosions.`
    );
  },

  // ---------------------------------------------------------------------------
  // GET ALL SOLID PLATFORMS
  // Returns an array of all solid rectangular surfaces the physics engine
  // should treat as ground/walls/ceilings.
  // Called by player.update() to pass into physics.moveAndCollide().
  //
  // Includes:
  //   - Static platforms from level.data.platforms (passed in)
  //   - Moving platforms (current position each frame)
  //   - Crushers in ALL phases (they are always solid, even when retracting)
  //
  // Does NOT include explosion zones — they kill via radius, not collision box.
  // ---------------------------------------------------------------------------
  getAllSolidPlatforms(staticPlatforms) {
    const solids = [];

    // Add static level platforms
    if (staticPlatforms) {
      staticPlatforms.forEach(p => solids.push(p));
    }

    // Add moving platforms at their current position
    this.movingPlatforms.forEach(mp => {
      solids.push({
        x:            mp.x,
        y:            mp.y,
        width:        mp.width,
        height:       mp.height,
        wallJumpable: mp.wallJumpable,
        type:         'moving_platform',
        _ref:         mp,   // reference back to moving platform for carry logic
      });
    });

    // Add crushers — solid in all phases
    this.crushers.forEach(c => {
      solids.push({
        x:            c.x,
        y:            c.y,
        width:        c.width,
        height:       c.height,
        wallJumpable: false,   // never wall-jumpable
        type:         'crusher',
        _ref:         c,
      });
    });

    return solids;
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // Called every frame by game.js during GAMEPLAY.
  // Updates all obstacle positions and checks player collisions.
  // deltaTime in seconds.
  // ---------------------------------------------------------------------------
  update(deltaTime, player) {
    if (!player) return;

    // Reset moving platform carry flag each frame
    this.movingPlatforms.forEach(mp => {
      mp.hasPlayer = false;
    });

    // --- Update crushers ---
    this.crushers.forEach(crusher => {
      window.Game.Crusher.update(crusher, deltaTime);
    });

    // --- Update moving platforms ---
    this.movingPlatforms.forEach(mp => {
      window.Game.MovingPlatform.update(mp, deltaTime);
    });

    // --- Update explosions ---
    this.explosions.forEach(explosion => {
      window.Game.Explosion.update(explosion, deltaTime);

      // Emit particles on the exact frame an explosion fires
      if (explosion.justExploded && window.Game.particles) {
        window.Game.particles.emit('explosion', explosion.x, explosion.y, 20);
      }
    });

    // --- Collision detection ---
    // Only check if player is alive and not already dying
    if (!player.isDead) {
      this._checkCrusherCollisions(player);
      this._checkExplosionCollisions(player);
      this._carryPlayerOnPlatform(player, deltaTime);
    }
  },

  // ---------------------------------------------------------------------------
  // _checkCrusherCollisions (private)
  // Crushers kill on contact when lethal (crushing or holding phase).
  // Dash invincibility protects the player from crushers.
  // ---------------------------------------------------------------------------
  _checkCrusherCollisions(player) {
    if (player.isInvincible) return;   // dash protection — pass through crushers

    const physics = window.Game.physics;

    this.crushers.forEach(crusher => {
      if (!crusher.isLethal) return;   // not lethal during idle/warning/retract

      // AABB overlap check between player and crusher
      if (physics.checkOverlap(player, crusher)) {
        player.takeDamage();
      }
    });
  },

  // ---------------------------------------------------------------------------
  // _checkExplosionCollisions (private)
  // Explosions kill within a radius during the 'exploding' phase.
  // Dash invincibility does NOT protect against explosions.
  // The player must TIME their movement through explosion zones.
  // ---------------------------------------------------------------------------
  _checkExplosionCollisions(player) {
    const physics = window.Game.physics;

    this.explosions.forEach(explosion => {
      if (!explosion.isLethal) return;   // only lethal during 'exploding' phase

      // Circle-vs-rectangle check — explosion is a circle, player is a rect
      if (physics.checkCircleOverlap(
        explosion.x, explosion.y, explosion.radius, player
      )) {
        player.takeDamage();
      }
    });
  },

  // ---------------------------------------------------------------------------
  // _carryPlayerOnPlatform (private)
  // When the player stands on a moving platform, they should move with it.
  // This runs AFTER physics.moveAndCollide() has resolved the player's
  // position, so the platform carry is additive on top of that.
  //
  // HOW IT WORKS:
  //   1. physics.moveAndCollide() already resolved player standing on the platform
  //      (player.y is flush with platform top, player.onGround is true)
  //   2. We detect which platform the player is standing on
  //   3. We add the platform's velocity to the player's position this frame
  //   4. This moves player WITH the platform seamlessly
  // ---------------------------------------------------------------------------
  _carryPlayerOnPlatform(player, deltaTime) {
    if (!player.onGround) return;   // only carry when standing, not when airborne

    this.movingPlatforms.forEach(mp => {
      // Check if player's feet are touching the top of this platform
      // Player feet = player.y + player.height
      // Platform top = mp.y
      // Allow a small tolerance for floating point imprecision
      const tolerance = 4;
      const playerFeet    = player.y + player.height;
      const platformTop   = mp.y;
      const feetOnPlatform = Math.abs(playerFeet - platformTop) <= tolerance;

      // Also check horizontal overlap — player must be above the platform
      const horizontalOverlap = (
        player.x + player.width  > mp.x &&
        player.x                 < mp.x + mp.width
      );

      if (feetOnPlatform && horizontalOverlap) {
        // Carry player with the platform's velocity
        player.x      += mp.vx * deltaTime;
        player.y      += mp.vy * deltaTime;
        mp.hasPlayer   = true;
      }
    });
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Renders all obstacles in the correct painter's order.
  // Called by game.js after camera.apply() — all coordinates are world space.
  //
  // Draw order:
  //   1. Moving platform path guides (faint — behind everything)
  //   2. Explosion zones (behind platforms so platform obscures zone edge)
  //   3. Moving platforms
  //   4. Crushers (on top — most visible hazard)
  // ---------------------------------------------------------------------------
  draw(ctx) {

    // --- Moving platform path guides ---
    this.movingPlatforms.forEach(mp => {
      window.Game.MovingPlatform.drawPathGuide(mp, ctx);
    });

    // --- Explosion zones ---
    this.explosions.forEach(explosion => {
      window.Game.Explosion.draw(explosion, ctx);
    });

    // --- Moving platforms ---
    this.movingPlatforms.forEach(mp => {
      window.Game.MovingPlatform.draw(mp, ctx);
    });

    // --- Crushers ---
    this.crushers.forEach(crusher => {
      window.Game.Crusher.draw(crusher, ctx);
    });
  },

  // ---------------------------------------------------------------------------
  // RESET
  // Resets all obstacles to their initial state.
  // Called on death respawn and full level restart.
  // Obstacles always fully reset — they don't have persistent state like rings.
  // ---------------------------------------------------------------------------
  reset() {
    // Reset crushers to idle phase
    this.crushers.forEach(crusher => {
      crusher.phase      = 'idle';
      crusher.phaseTimer = 0;
      crusher.x          = crusher.startX;
      crusher.y          = crusher.startY;
      crusher.isLethal   = false;
    });

    // Reset moving platforms to start position
    this.movingPlatforms.forEach(mp => {
      mp.progress       = 0;
      mp.movingForward  = true;
      mp.x              = mp.pathStart.x;
      mp.y              = mp.pathStart.y;
      mp.vx             = 0;
      mp.vy             = 0;
      mp.delayTimer     = 0;
      mp.hasPlayer      = false;
    });

    // Reset explosion zones — stagger them slightly so they don't all sync
    this.explosions.forEach((explosion, index) => {
      explosion.phase        = 'cooling';
      // Offset each explosion's start time so they fire at different moments
      // This prevents the entire level becoming safe/deadly simultaneously
      explosion.phaseTimer   = (index * 400) % explosion.coolingMs;
      explosion.isLethal     = false;
      explosion.glowIntensity = 0;
      explosion.shockwaveRadius = 0;
      explosion.shockwaveAlpha  = 0;
    });

    console.log('obstacleManager.js: All obstacles reset.');
  },

};
