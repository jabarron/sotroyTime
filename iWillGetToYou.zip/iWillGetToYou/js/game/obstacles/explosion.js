// =============================================================================
// explosion.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Defines a single explosion hazard zone for the male (space ship) path.
// These are areas of the ship where explosive decompression or fuel ignition
// creates timed, lethal bursts. The player must time their movement through.
//
// EXPLOSION CYCLE:
//   'cooling'   — safe, dark — no danger, player can pass freely
//   'warning'   — orange glow builds up — GET OUT NOW
//   'exploding' — bright lethal burst — instant death on contact
//
// The warning phase is the entire fairness model.
// If the warning is visible, the player has time to react.
// The explosion radius (circle) is checked, not a box — feels more natural.
//
// Dash invincibility does NOT protect against explosions intentionally —
// the design requires the player to time movement, not dash through hazards.
// (Can be reconsidered during playtesting.)
// =============================================================================

window.Game = window.Game || {};
window.Game.Explosion = window.Game.Explosion || {};

// ---------------------------------------------------------------------------
// CREATE EXPLOSION
// Factory function. Called by obstacleManager.init().
//
// data shape:
// {
//   x, y,          — world center position of the explosion zone
//   radius,        — lethal radius in pixels
//   coolingMs,     — ms of safe cool-down between explosions
//   warningMs,     — ms of warning glow (from constants if not provided)
//   explodingMs,   — ms the explosion stays active and lethal
//   startPhase,    — optional: 'cooling' | 'warning' | 'exploding' (default: 'cooling')
//   startTimer,    — optional ms offset so not all explosions sync up
// }
// ---------------------------------------------------------------------------
window.Game.Explosion.create = function(data) {
  const C = window.Game.constants;

  return {
    // --- Position (center of explosion zone) ---
    x:      data.x,
    y:      data.y,

    // --- Lethal radius ---
    radius: data.radius || C.EXPLOSION_RADIUS || 60,

    // --- Timing ---
    coolingMs:   data.coolingMs   || C.EXPLOSION_COOL_MS    || 1200,
    warningMs:   data.warningMs   || C.EXPLOSION_WARNING_MS || 900,
    explodingMs: data.explodingMs || C.EXPLOSION_ACTIVE_MS  || 300,

    // --- State machine ---
    phase:      data.startPhase || 'cooling',
    phaseTimer: data.startTimer || 0,   // offset prevents synchronized explosions

    // --- Visual state ---
    glowIntensity: 0,     // 0-1, drives glow size and brightness
    shockwaveRadius: 0,   // expanding ring after explosion
    shockwaveAlpha:  0,   // fades out

    // --- Lethal flag ---
    // True only during 'exploding' phase
    isLethal: false,

    // --- Particle burst flag ---
    // True for one frame only — when explosion first fires
    // Lets obstacleManager emit particles without double-firing
    justExploded: false,
  };
};

// ---------------------------------------------------------------------------
// UPDATE EXPLOSION
// Advances the explosion through its cycle each frame.
// deltaTime in seconds.
// ---------------------------------------------------------------------------
window.Game.Explosion.update = function(explosion, deltaTime) {
  const ms = deltaTime * 1000;

  explosion.phaseTimer  += ms;
  explosion.justExploded = false;   // reset single-frame flag

  // Decay shockwave
  if (explosion.shockwaveRadius > 0) {
    explosion.shockwaveRadius += 80 * deltaTime;   // expand outward
    explosion.shockwaveAlpha  -= 2.5 * deltaTime;  // fade out
    if (explosion.shockwaveAlpha <= 0) {
      explosion.shockwaveRadius = 0;
      explosion.shockwaveAlpha  = 0;
    }
  }

  switch (explosion.phase) {

    case 'cooling': {
      explosion.isLethal     = false;
      explosion.glowIntensity = 0;

      if (explosion.phaseTimer >= explosion.coolingMs) {
        explosion.phase      = 'warning';
        explosion.phaseTimer = 0;
      }
      break;
    }

    case 'warning': {
      explosion.isLethal = false;

      // Glow ramps from 0 to 1 over the warning duration
      // Accelerates toward the end to create urgency
      const t = explosion.phaseTimer / explosion.warningMs;

      // Ease-in curve: slow start, fast finish
      explosion.glowIntensity = t * t;

      // Rapid pulsing in the final 30% of warning time
      if (t > 0.7) {
        const pulseRate     = 12 + (t - 0.7) * 40;   // speeds up as it approaches
        explosion.glowIntensity = 0.7 + 0.3 * Math.abs(Math.sin(t * pulseRate));
      }

      if (explosion.phaseTimer >= explosion.warningMs) {
        explosion.phase        = 'exploding';
        explosion.phaseTimer   = 0;
        explosion.justExploded = true;

        // Trigger shockwave ring
        explosion.shockwaveRadius = explosion.radius * 0.5;
        explosion.shockwaveAlpha  = 1.0;
      }
      break;
    }

    case 'exploding': {
      explosion.isLethal      = true;
      explosion.glowIntensity = 1.0;

      if (explosion.phaseTimer >= explosion.explodingMs) {
        explosion.phase        = 'cooling';
        explosion.phaseTimer   = 0;
        explosion.isLethal     = false;
        explosion.glowIntensity = 0;
      }
      break;
    }
  }
};

// ---------------------------------------------------------------------------
// DRAW EXPLOSION
// Renders the explosion zone with phase-appropriate visuals.
// ctx: canvas 2D context (camera transform already applied)
// ---------------------------------------------------------------------------
window.Game.Explosion.draw = function(explosion, ctx) {
  // Cull: skip if zone center is far off screen
  const visRadius = explosion.radius * 3;
  if (window.Game.camera &&
      !window.Game.camera.isVisible(
        explosion.x - visRadius, explosion.y - visRadius,
        visRadius * 2, visRadius * 2
      )) {
    return;
  }

  ctx.save();

  const cx = explosion.x;
  const cy = explosion.y;
  const r  = explosion.radius;

  switch (explosion.phase) {

    case 'cooling': {
      // Subtle dark scorch mark on the floor/wall — visual scar
      ctx.fillStyle = 'rgba(40, 20, 10, 0.4)';
      ctx.beginPath();
      ctx.ellipse(cx, cy, r * 0.7, r * 0.3, 0, 0, Math.PI * 2);
      ctx.fill();
      break;
    }

    case 'warning': {
      const g = explosion.glowIntensity;

      // Ground scorch mark (always visible)
      ctx.fillStyle = `rgba(80, 30, 10, ${0.3 + g * 0.3})`;
      ctx.beginPath();
      ctx.ellipse(cx, cy, r * 0.7, r * 0.25, 0, 0, Math.PI * 2);
      ctx.fill();

      // Danger zone circle — orange radial gradient
      const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      grad.addColorStop(0,   `rgba(255, 140, 0, ${g * 0.5})`);
      grad.addColorStop(0.6, `rgba(255, 80,  0, ${g * 0.3})`);
      grad.addColorStop(1,   `rgba(255, 40,  0, 0)`);
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();

      // Warning ring — solid orange circle outline
      ctx.strokeStyle = `rgba(255, 120, 0, ${g * 0.9})`;
      ctx.lineWidth   = 2;
      ctx.shadowColor = '#ff6600';
      ctx.shadowBlur  = 10 * g;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();

      // Warning symbol — exclamation mark in center
      if (g > 0.3) {
        ctx.fillStyle    = `rgba(255, 200, 0, ${g * 0.9})`;
        ctx.font         = `bold ${Math.round(r * 0.5)}px "Roboto", sans-serif`;
        ctx.textAlign    = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowBlur   = 8 * g;
        ctx.fillText('!', cx, cy);
      }

      ctx.shadowBlur = 0;
      break;
    }

    case 'exploding': {
      // Core — bright white hot center
      const coreGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r * 0.6);
      coreGrad.addColorStop(0,   'rgba(255, 255, 255, 1.0)');
      coreGrad.addColorStop(0.3, 'rgba(255, 220,  80, 0.95)');
      coreGrad.addColorStop(0.7, 'rgba(255, 80,   0,  0.8)');
      coreGrad.addColorStop(1,   'rgba(255, 0,    0,  0)');
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();

      // Outer fire fringe — jagged feeling via multiple arcs
      ctx.shadowColor = '#ff4400';
      ctx.shadowBlur  = 30;
      ctx.strokeStyle = 'rgba(255, 100, 0, 0.7)';
      ctx.lineWidth   = 4;
      ctx.beginPath();
      ctx.arc(cx, cy, r * 1.1, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;

      break;
    }
  }

  // --- Shockwave ring (persists briefly after explosion) ---
  if (explosion.shockwaveRadius > 0 && explosion.shockwaveAlpha > 0) {
    ctx.strokeStyle = `rgba(255, 180, 0, ${explosion.shockwaveAlpha})`;
    ctx.lineWidth   = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, explosion.shockwaveRadius, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();
};
