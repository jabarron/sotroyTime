// =============================================================================
// crusher.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Defines a single crusher obstacle.
// A crusher is a block that periodically slams in one direction then retracts.
// It kills the player on contact (unless player is invincible via dash).
//
// CRUSHER CYCLE:
//   'idle'      — waiting at start position, showing a warning glow
//   'warning'   — brief visual warning before it moves (telegraphs the attack)
//   'crushing'  — moving fast toward the end position
//   'holding'   — held at end position briefly
//   'retracting'— moving back to start position slowly
//
// The warning phase is critical for fairness — the player must always have
// time to react before the crusher moves.
// =============================================================================

window.Game = window.Game || {};
window.Game.Crusher = window.Game.Crusher || {};

// ---------------------------------------------------------------------------
// CREATE CRUSHER
// Factory function. Called by obstacleManager.init() for each crusher
// defined in the level data.
//
// data shape:
// {
//   x, y,             — world position (top-left of crusher block)
//   width, height,    — size of the crusher block
//   direction,        — 'down' | 'up' | 'left' | 'right'
//   travelDistance,   — pixels it travels before stopping
//   idleMs,           — ms spent at rest before warning
//   warningMs,        — ms of warning glow before moving
//   crushMs,          — ms it takes to travel the full distance (fast)
//   holdMs,           — ms held at end position before retracting
//   retractMs,        — ms it takes to return (slower than crush)
// }
// ---------------------------------------------------------------------------
window.Game.Crusher.create = function(data) {
  return {
    // --- Geometry ---
    x:              data.x,
    y:              data.y,
    width:          data.width,
    height:         data.height,

    // --- Start position (always returns here) ---
    startX:         data.x,
    startY:         data.y,

    // --- End position (calculated from direction + travelDistance) ---
    endX:           data.x + (data.direction === 'right' ?  data.travelDistance
                            : data.direction === 'left'  ? -data.travelDistance : 0),
    endY:           data.y + (data.direction === 'down'  ?  data.travelDistance
                            : data.direction === 'up'    ? -data.travelDistance : 0),

    // --- Motion config ---
    direction:      data.direction      || 'down',
    travelDistance: data.travelDistance || 120,

    // --- Timing (ms) ---
    idleMs:         data.idleMs         || 1800,
    warningMs:      data.warningMs      || 600,
    crushMs:        data.crushMs        || 120,    // fast — snappy and dangerous
    holdMs:         data.holdMs         || 400,
    retractMs:      data.retractMs      || 700,    // slower retract — less dangerous

    // --- State machine ---
    phase:          'idle',    // current phase (see cycle above)
    phaseTimer:     0,         // ms elapsed in current phase

    // --- Visual ---
    warningAlpha:   0,         // 0-1 glow intensity during warning phase
    wallJumpable:   false,     // crushers cannot be wall-jumped off

    // --- Lethal flag ---
    // True only when in 'crushing' or 'holding' phases
    isLethal:       false,
  };
};

// ---------------------------------------------------------------------------
// UPDATE CRUSHER
// Advances the crusher through its cycle each frame.
// deltaTime in seconds.
// ---------------------------------------------------------------------------
window.Game.Crusher.update = function(crusher, deltaTime) {
  const ms = deltaTime * 1000;   // convert to milliseconds for timer comparisons
  crusher.phaseTimer += ms;

  switch (crusher.phase) {

    case 'idle': {
      crusher.isLethal     = false;
      crusher.warningAlpha = 0;

      // Reset position to start
      crusher.x = crusher.startX;
      crusher.y = crusher.startY;

      if (crusher.phaseTimer >= crusher.idleMs) {
        crusher.phase      = 'warning';
        crusher.phaseTimer = 0;
      }
      break;
    }

    case 'warning': {
      crusher.isLethal = false;

      // Pulse the warning glow — increases from 0 to 1 over the warning duration
      const progress       = crusher.phaseTimer / crusher.warningMs;
      // Rapid pulsing at end of warning to signal imminent movement
      crusher.warningAlpha = progress > 0.6
        ? 0.5 + 0.5 * Math.sin(progress * Math.PI * 8)   // fast pulse
        : progress;                                         // slow ramp up

      if (crusher.phaseTimer >= crusher.warningMs) {
        crusher.phase      = 'crushing';
        crusher.phaseTimer = 0;
      }
      break;
    }

    case 'crushing': {
      crusher.isLethal     = true;
      crusher.warningAlpha = 1;

      // Linear interpolation from start to end over crushMs
      const progress = Math.min(crusher.phaseTimer / crusher.crushMs, 1);
      crusher.x = crusher.startX + (crusher.endX - crusher.startX) * progress;
      crusher.y = crusher.startY + (crusher.endY - crusher.startY) * progress;

      if (crusher.phaseTimer >= crusher.crushMs) {
        // Snap exactly to end position
        crusher.x          = crusher.endX;
        crusher.y          = crusher.endY;
        crusher.phase      = 'holding';
        crusher.phaseTimer = 0;
      }
      break;
    }

    case 'holding': {
      crusher.isLethal     = true;
      crusher.warningAlpha = 0.7;

      if (crusher.phaseTimer >= crusher.holdMs) {
        crusher.phase      = 'retracting';
        crusher.phaseTimer = 0;
      }
      break;
    }

    case 'retracting': {
      crusher.isLethal     = false;   // safe to touch during retraction
      crusher.warningAlpha = 0;

      // Linear interpolation from end back to start over retractMs
      const progress = Math.min(crusher.phaseTimer / crusher.retractMs, 1);
      crusher.x = crusher.endX + (crusher.startX - crusher.endX) * progress;
      crusher.y = crusher.endY + (crusher.startY - crusher.endY) * progress;

      if (crusher.phaseTimer >= crusher.retractMs) {
        crusher.x          = crusher.startX;
        crusher.y          = crusher.startY;
        crusher.phase      = 'idle';
        crusher.phaseTimer = 0;
      }
      break;
    }
  }
};

// ---------------------------------------------------------------------------
// DRAW CRUSHER
// Renders the crusher block with phase-appropriate visuals.
// ctx: canvas 2D context (camera transform already applied)
// ---------------------------------------------------------------------------
window.Game.Crusher.draw = function(crusher, ctx) {
  // Cull if off-screen
  if (window.Game.camera &&
      !window.Game.camera.isVisible(crusher.x, crusher.y, crusher.width, crusher.height)) {
    return;
  }

  ctx.save();

  // --- Base block color based on phase ---
  const isActive = crusher.phase === 'crushing' || crusher.phase === 'holding';

  // Main body — dark metal with red tint when active
  ctx.fillStyle = isActive ? '#5a1a1a' : '#2a2a3a';
  ctx.fillRect(crusher.x, crusher.y, crusher.width, crusher.height);

  // Edge highlight (top and left edges lighter — 3D bevel effect)
  ctx.fillStyle = isActive ? '#8a3a3a' : '#4a4a5a';
  ctx.fillRect(crusher.x, crusher.y, crusher.width, 3);         // top edge
  ctx.fillRect(crusher.x, crusher.y, 3, crusher.height);        // left edge

  // Shadow edge (bottom and right edges darker)
  ctx.fillStyle = isActive ? '#3a0a0a' : '#1a1a2a';
  ctx.fillRect(crusher.x, crusher.y + crusher.height - 3, crusher.width, 3);   // bottom
  ctx.fillRect(crusher.x + crusher.width - 3, crusher.y, 3, crusher.height);   // right

  // Hazard stripes on the crushing face
  // Face direction depends on crusher.direction
  const stripeColor1 = '#ffcc00';
  const stripeColor2 = '#1a1a1a';
  const stripeW = 8;
  ctx.save();

  // Clip stripes to the leading face only
  let faceX, faceY, faceW, faceH;
  switch (crusher.direction) {
    case 'down':  faceX = crusher.x; faceY = crusher.y + crusher.height - 10; faceW = crusher.width;  faceH = 10; break;
    case 'up':    faceX = crusher.x; faceY = crusher.y;                        faceW = crusher.width;  faceH = 10; break;
    case 'right': faceX = crusher.x + crusher.width - 10; faceY = crusher.y;  faceW = 10; faceH = crusher.height; break;
    case 'left':  faceX = crusher.x; faceY = crusher.y;                        faceW = 10; faceH = crusher.height; break;
    default:      faceX = crusher.x; faceY = crusher.y + crusher.height - 10; faceW = crusher.width;  faceH = 10;
  }

  ctx.beginPath();
  ctx.rect(faceX, faceY, faceW, faceH);
  ctx.clip();

  // Draw diagonal stripes across the clipped face
  for (let s = -crusher.width; s < crusher.width * 2; s += stripeW * 2) {
    ctx.fillStyle = stripeColor1;
    ctx.beginPath();
    ctx.moveTo(faceX + s,           faceY);
    ctx.lineTo(faceX + s + stripeW, faceY);
    ctx.lineTo(faceX + s + stripeW + faceH, faceY + faceH);
    ctx.lineTo(faceX + s + faceH,   faceY + faceH);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  // --- Warning glow overlay ---
  if (crusher.warningAlpha > 0) {
    ctx.fillStyle = `rgba(255, 80, 0, ${crusher.warningAlpha * 0.35})`;
    ctx.fillRect(crusher.x, crusher.y, crusher.width, crusher.height);

    // Outer glow
    ctx.shadowColor = '#ff4400';
    ctx.shadowBlur  = 20 * crusher.warningAlpha;
    ctx.strokeStyle = `rgba(255, 100, 0, ${crusher.warningAlpha * 0.8})`;
    ctx.lineWidth   = 2;
    ctx.strokeRect(crusher.x + 1, crusher.y + 1, crusher.width - 2, crusher.height - 2);
    ctx.shadowBlur  = 0;
  }

  ctx.restore();
};
