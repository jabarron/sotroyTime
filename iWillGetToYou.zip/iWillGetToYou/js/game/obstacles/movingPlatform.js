// =============================================================================
// movingPlatform.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Defines a single moving platform.
// Moves back and forth between two defined points (pathStart and pathEnd).
// Carries the player when they stand on top — player moves with the platform.
//
// CRITICAL PHYSICS NOTE:
//   When the player stands on a moving platform, the platform's velocity
//   is added to the player's position each frame. This is handled in
//   obstacleManager.update() after physics.moveAndCollide() runs.
//   The platform is also added to the solid platforms list that
//   physics.moveAndCollide() checks — so landing on it works automatically.
// =============================================================================

window.Game = window.Game || {};
window.Game.MovingPlatform = window.Game.MovingPlatform || {};

// ---------------------------------------------------------------------------
// CREATE MOVING PLATFORM
// Factory function. Called by obstacleManager.init().
//
// data shape:
// {
//   x, y,                     — starting world position
//   width, height,            — platform size
//   pathStart: { x, y },      — one end of the travel path
//   pathEnd:   { x, y },      — other end of the travel path
//   speed,                    — pixels per second travel speed
//   wallJumpable,             — can the player wall jump off its sides?
//   startDelay,               — optional ms delay before platform starts moving
// }
// ---------------------------------------------------------------------------
window.Game.MovingPlatform.create = function(data) {
  // Calculate total path length for progress tracking
  const dx     = data.pathEnd.x - data.pathStart.x;
  const dy     = data.pathEnd.y - data.pathStart.y;
  const length = Math.sqrt(dx * dx + dy * dy);

  return {
    // --- Current position (top-left of platform) ---
    x:      data.pathStart.x,
    y:      data.pathStart.y,

    // --- Dimensions ---
    width:  data.width  || 120,
    height: data.height || 16,

    // --- Path ---
    pathStart:    { x: data.pathStart.x, y: data.pathStart.y },
    pathEnd:      { x: data.pathEnd.x,   y: data.pathEnd.y   },
    pathLength:   length,

    // --- Motion ---
    speed:        data.speed || 80,     // pixels per second
    progress:     0,                    // 0.0 = at pathStart, 1.0 = at pathEnd
    movingForward: true,                // true = toward pathEnd, false = toward pathStart

    // --- Velocity (calculated each frame, used to carry player) ---
    vx: 0,
    vy: 0,

    // --- Optional start delay ---
    startDelay:   data.startDelay || 0,    // ms before platform begins moving
    delayTimer:   0,

    // --- Properties ---
    wallJumpable: data.wallJumpable !== undefined ? data.wallJumpable : false,
    type:         'platform',    // used by physics to identify solid surfaces

    // --- Player carrying ---
    // True if the player is currently standing on this platform
    // Set each frame by obstacleManager after collision detection
    hasPlayer:    false,
  };
};

// ---------------------------------------------------------------------------
// UPDATE MOVING PLATFORM
// Advances position along the path each frame.
// deltaTime in seconds.
// ---------------------------------------------------------------------------
window.Game.MovingPlatform.update = function(platform, deltaTime) {
  const ms = deltaTime * 1000;

  // Handle start delay
  if (platform.delayTimer < platform.startDelay) {
    platform.delayTimer += ms;
    platform.vx = 0;
    platform.vy = 0;
    return;
  }

  // Store previous position to calculate velocity this frame
  const prevX = platform.x;
  const prevY = platform.y;

  // Advance progress along the path
  const distanceThisFrame = platform.speed * deltaTime;
  const progressDelta     = platform.pathLength > 0
    ? distanceThisFrame / platform.pathLength
    : 0;

  if (platform.movingForward) {
    platform.progress += progressDelta;
    if (platform.progress >= 1) {
      platform.progress      = 1;
      platform.movingForward = false;   // reverse direction at end
    }
  } else {
    platform.progress -= progressDelta;
    if (platform.progress <= 0) {
      platform.progress      = 0;
      platform.movingForward = true;    // reverse direction at start
    }
  }

  // Interpolate position along path using progress (0.0 → 1.0)
  platform.x = platform.pathStart.x + (platform.pathEnd.x - platform.pathStart.x) * platform.progress;
  platform.y = platform.pathStart.y + (platform.pathEnd.y - platform.pathStart.y) * platform.progress;

  // Calculate velocity this frame (used to carry player)
  platform.vx = (platform.x - prevX) / deltaTime;
  platform.vy = (platform.y - prevY) / deltaTime;
};

// ---------------------------------------------------------------------------
// DRAW MOVING PLATFORM
// Renders the platform with a space-ship-interior aesthetic.
// ctx: canvas 2D context (camera transform already applied)
// ---------------------------------------------------------------------------
window.Game.MovingPlatform.draw = function(platform, ctx) {
  // Cull if off screen
  if (window.Game.camera &&
      !window.Game.camera.isVisible(platform.x, platform.y, platform.width, platform.height)) {
    return;
  }

  ctx.save();

  const x = platform.x;
  const y = platform.y;
  const w = platform.width;
  const h = platform.height;

  // --- Platform body ---
  // Slightly glowing teal-grey metal panel look
  ctx.fillStyle = '#1e3a4a';
  ctx.fillRect(x, y, w, h);

  // --- Top surface — bright line (where player stands) ---
  ctx.fillStyle = '#4af0c0';
  ctx.fillRect(x, y, w, 3);

  // --- Panel rivets / detail lines ---
  ctx.fillStyle = '#2a5060';
  // Vertical dividers
  const divCount = Math.floor(w / 30);
  for (let i = 1; i < divCount; i++) {
    ctx.fillRect(x + i * (w / divCount), y + 3, 1, h - 3);
  }

  // --- Subtle glow on top edge ---
  ctx.shadowColor = '#4af0c0';
  ctx.shadowBlur  = 6;
  ctx.strokeStyle = '#4af0c0';
  ctx.lineWidth   = 1;
  ctx.beginPath();
  ctx.moveTo(x, y + 1.5);
  ctx.lineTo(x + w, y + 1.5);
  ctx.stroke();
  ctx.shadowBlur = 0;

  // --- Path guide dots (subtle — show where platform travels) ---
  // Draw small dots at pathStart and pathEnd so player can predict motion
  this._drawPathGuide(platform, ctx);

  ctx.restore();
};

// ---------------------------------------------------------------------------
// _drawPathGuide (private)
// Draws subtle guide markers at path endpoints so the player understands
// where the platform will travel. Helps with level readability.
// ---------------------------------------------------------------------------
window.Game.MovingPlatform.drawPathGuide = function(platform, ctx) {
  // Only draw if camera is initialized
  if (!window.Game.camera) return;

  const alpha = 0.25;   // very subtle — environmental clue, not UI

  // Draw a faint line between start and end
  ctx.save();
  ctx.setLineDash([4, 8]);
  ctx.strokeStyle = `rgba(74, 240, 192, ${alpha})`;
  ctx.lineWidth   = 1;

  // Center of platform at start and end positions
  const sw = platform.width  / 2;
  const sh = platform.height / 2;

  ctx.beginPath();
  ctx.moveTo(platform.pathStart.x + sw, platform.pathStart.y + sh);
  ctx.lineTo(platform.pathEnd.x   + sw, platform.pathEnd.y   + sh);
  ctx.stroke();
  ctx.setLineDash([]);

  // Small circle at each endpoint
  [platform.pathStart, platform.pathEnd].forEach(pt => {
    ctx.beginPath();
    ctx.arc(pt.x + sw, pt.y + sh, 4, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(74, 240, 192, ${alpha * 1.5})`;
    ctx.fill();
  });

  ctx.restore();
};
