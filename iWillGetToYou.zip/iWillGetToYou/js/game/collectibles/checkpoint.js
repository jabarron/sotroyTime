// =============================================================================
// checkpoint.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Handles checkpoint activation logic.
// A checkpoint is a special large ring placed at roughly the midpoint of
// each level. When the player touches it:
//   1. It activates (changes color to green, plays sound, emits particles)
//   2. The respawn position is saved to Game.state
//   3. The ring count at that moment is saved (kept after death)
//   4. The timer resets to 3 minutes (approved in design doc)
//   5. A contextual callout fires: "Checkpoint. Keep going."
//
// The checkpoint ring is created and drawn by ring.js / collectibleManager.js.
// This file handles ONLY the activation logic and side effects.
// =============================================================================

window.Game = window.Game || {};

window.Game.checkpoint = {

  // ---------------------------------------------------------------------------
  // ACTIVATE
  // Called by collectibleManager.update() when the player overlaps
  // a checkpoint ring that has not yet been activated.
  //
  // ring:   the checkpoint ring object (from ring.js)
  // player: Game.player
  // ---------------------------------------------------------------------------
  activate(ring, player) {
    if (ring.activated) return;   // only activate once

    const C     = window.Game.constants;
    const state = window.Game.state;
    const audio = window.Game.audio;
    const parts = window.Game.particles;

    // --- Mark the ring as activated ---
    ring.activated = true;

    // --- Save respawn position to state ---
    // Respawn at the left edge of the checkpoint ring (safe landing spot)
    state.checkpointReached        = true;
    state.checkpointX              = ring.x;
    state.checkpointY              = ring.y;                // player will land near it
    state.checkpointRingsCollected = state.ringsCollected;  // snapshot ring count

    // --- Reset timer to full 3 minutes ---
    state.timerSeconds = C.LEVEL_TIME_SECONDS;

    // --- Audio feedback ---
    if (audio) {
      audio.play('checkpoint');
    }

    // --- Particle burst ---
    if (parts) {
      const cx = ring.x + ring.width  / 2;
      const cy = ring.y + ring.height / 2;
      parts.emit('checkpoint_burst', cx, cy, C.CHECKPOINT_BURST);
    }

    // --- Contextual callout ---
    if (window.Game.hud) {
      window.Game.hud.showCallout('Checkpoint. Keep going.');
    }

    console.log(
      `checkpoint.js: Activated at (${ring.x}, ${ring.y}). ` +
      `Rings saved: ${state.checkpointRingsCollected}. Timer reset.`
    );
  },

};
