// =============================================================================
// collectibleManager.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Manages all collectible rings in the current level.
// Responsibilities:
//   - Initializing rings from level data
//   - Updating float/glow animations each frame
//   - Detecting player overlap and handling pickup
//   - Tracking collection count and checking the 80% threshold
//   - Triggering door unlock when threshold is crossed
//   - Drawing all uncollected rings
//   - Resetting ring state on death/restart
//
// Ring types handled:
//   common     — small gold ring, counts toward 80% threshold
//   checkpoint — large ring, saves respawn point, does NOT count toward 80%
// =============================================================================

window.Game = window.Game || {};

window.Game.collectibles = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  rings:          [],    // all ring objects in the current level
  totalRings:     0,     // count of COMMON rings only (not checkpoints)
  collectedCount: 0,     // how many common rings have been collected

  // Tracks whether we've already triggered the door-unlock event this run
  // so it only fires once even if the player hovers at exactly 80%
  _doorUnlockFired: false,

  // ---------------------------------------------------------------------------
  // INIT
  // Called by levelLoader when a level loads.
  // Creates ring objects from raw level data arrays.
  // ringsData: array of { x, y, isCheckpoint, floatPhase, glowPhase }
  // ---------------------------------------------------------------------------
  init(ringsData) {
    this.rings          = [];
    this.collectedCount = 0;
    this._doorUnlockFired = false;

    // Build ring objects from level data
    ringsData.forEach(data => {
      const ring = window.Game.Ring.create(data);
      this.rings.push(ring);
    });

    // Count only common rings for the 80% threshold
    // Checkpoints are excluded — they are progression markers, not score items
    this.totalRings = this.rings.filter(r => !r.isCheckpoint).length;

    // Sync to game state so HUD can read it
    if (window.Game.state) {
      window.Game.state.ringsTotal     = this.totalRings;
      window.Game.state.ringsCollected = 0;
    }

    console.log(
      `collectibleManager.js: ${this.rings.length} rings loaded ` +
      `(${this.totalRings} common, ` +
      `${this.rings.length - this.totalRings} checkpoints).`
    );
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // Called every frame by game.js during GAMEPLAY.
  // Animates rings and checks for player pickup.
  // deltaTime in seconds.
  // ---------------------------------------------------------------------------
  update(deltaTime, player) {
    if (!player) return;

    const C       = window.Game.constants;
    const physics = window.Game.physics;

    // Get player center for radius-based collect check
    const pCenter = player.getCenter();

    for (let i = 0; i < this.rings.length; i++) {
      const ring = this.rings[i];
      if (ring.collected) continue;   // skip already-collected rings

      // --- Animate ---
      window.Game.Ring.update(ring, deltaTime);

      // --- Pickup detection ---
      const ringCenterX = ring.x + ring.width  / 2;
      const ringCenterY = ring.y + ring.height / 2;
      const collectRadius = ring.isCheckpoint
        ? C.CHECKPOINT_COLLECT_RADIUS
        : C.RING_COLLECT_RADIUS;

      const inRange = physics.checkCollectRadius(
        pCenter.x, pCenter.y,
        ringCenterX, ringCenterY,
        collectRadius
      );

      if (inRange) {
        if (ring.isCheckpoint) {
          // --- Checkpoint pickup ---
          this._collectCheckpoint(ring, player);
        } else {
          // --- Common ring pickup ---
          this._collectRing(ring, player);
        }
      }
    }
  },

  // ---------------------------------------------------------------------------
  // _collectRing (private)
  // Handles pickup of a common collectible ring.
  // ---------------------------------------------------------------------------
  _collectRing(ring, player) {
    ring.collected = true;
    this.collectedCount++;

    const state = window.Game.state;
    const audio = window.Game.audio;
    const parts = window.Game.particles;
    const C     = window.Game.constants;

    // Update session state
    if (state) {
      state.ringsCollected = this.collectedCount;
    }

    // Audio
    if (audio) {
      audio.play('collect');
    }

    // Sparkle burst at ring position
    if (parts) {
      const cx = ring.x + ring.width  / 2;
      const cy = ring.y + ring.height / 2;
      parts.emit('sparkle', cx, cy, C.SPARKLE_COUNT);
    }

    // Check 80% threshold — fire door unlock if just crossed
    this._checkThreshold();
  },

  // ---------------------------------------------------------------------------
  // _collectCheckpoint (private)
  // Handles pickup of a checkpoint ring.
  // Delegates side-effect logic to checkpoint.js.
  // ---------------------------------------------------------------------------
  _collectCheckpoint(ring, player) {
    // checkpoint.js handles activation (saves state, resets timer, plays audio)
    window.Game.checkpoint.activate(ring, player);
    // Note: checkpoint rings are NOT marked collected — they stay visible
    // but change color to green after activation (handled in ring.js draw)
  },

  // ---------------------------------------------------------------------------
  // _checkThreshold (private)
  // Checks if collection count has crossed the 80% threshold.
  // Fires door unlock side effects ONCE — first time threshold is crossed.
  // ---------------------------------------------------------------------------
  _checkThreshold() {
    if (this._doorUnlockFired) return;   // already fired — don't repeat
    if (this.totalRings === 0)  return;  // no rings in level — skip

    const C     = window.Game.constants;
    const state = window.Game.state;
    const ratio = this.collectedCount / this.totalRings;

    if (ratio >= C.COMPLETION_THRESHOLD) {
      // Threshold crossed — unlock the exit door
      this._doorUnlockFired = true;

      if (state) {
        state.doorUnlocked = true;
      }

      // Play door unlock sound
      if (window.Game.audio) {
        window.Game.audio.play('door_unlock');
      }

      // Show callout
      if (window.Game.hud) {
        window.Game.hud.showCallout('Hangar unlocked!');
      }

      console.log(
        `collectibleManager.js: 80% threshold reached ` +
        `(${this.collectedCount}/${this.totalRings}). Door unlocked.`
      );
    }
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Renders all uncollected rings.
  // Called every frame by game.js AFTER camera.apply() — world space coords.
  // ---------------------------------------------------------------------------
  draw(ctx) {
    for (let i = 0; i < this.rings.length; i++) {
      const ring = this.rings[i];

      // Common rings: skip if collected
      if (!ring.isCheckpoint && ring.collected) continue;

      window.Game.Ring.draw(ring, ctx);
    }
  },

  // ---------------------------------------------------------------------------
  // GET PROGRESS
  // Returns collection stats for the HUD ring counter.
  // { collected: Number, total: Number, percent: Number, thresholdMet: Boolean }
  // ---------------------------------------------------------------------------
  getProgress() {
    const C       = window.Game.constants;
    const percent = this.totalRings > 0
      ? this.collectedCount / this.totalRings
      : 0;

    return {
      collected:     this.collectedCount,
      total:         this.totalRings,
      percent:       percent,
      thresholdMet:  percent >= C.COMPLETION_THRESHOLD,
    };
  },

  // ---------------------------------------------------------------------------
  // RESET
  // Resets collection state.
  // keepCollected: true  = rings already grabbed stay collected (death respawn)
  //               false = all rings restored (full level restart)
  //
  // On death:    keepCollected = true
  //              BUT rings collected AFTER the checkpoint are restored
  //              (player respawns with the ring count from checkpoint time)
  //
  // On restart:  keepCollected = false (all rings fresh)
  // ---------------------------------------------------------------------------
  reset(keepCollected, ringCountAtCheckpoint) {
    this._doorUnlockFired = false;

    if (!keepCollected) {
      // Full restart — restore all rings
      this.rings.forEach(ring => {
        ring.collected = false;
        if (ring.isCheckpoint) {
          ring.activated = false;   // also reset checkpoint activation
        }
      });
      this.collectedCount = 0;

    } else {
      // Death respawn — restore only rings collected AFTER checkpoint
      // Ring count at checkpoint = ringCountAtCheckpoint
      // Any ring collected above that count needs to be restored
      let restoredCount = 0;

      // Sort rings by X position so we restore the rightmost ones first
      // (those are the ones collected after the checkpoint)
      const collectedRings = this.rings
        .filter(r => !r.isCheckpoint && r.collected)
        .sort((a, b) => b.x - a.x);  // rightmost first

      const toRestore = this.collectedCount - ringCountAtCheckpoint;

      for (let i = 0; i < toRestore && i < collectedRings.length; i++) {
        collectedRings[i].collected = false;
        restoredCount++;
      }

      this.collectedCount = ringCountAtCheckpoint;
    }

    // Re-check threshold with restored count
    // If player was above 80% and now isn't (rare edge case), lock the door
    if (window.Game.state) {
      window.Game.state.ringsCollected = this.collectedCount;
      const C     = window.Game.constants;
      const ratio = this.totalRings > 0
        ? this.collectedCount / this.totalRings
        : 0;
      window.Game.state.doorUnlocked = ratio >= C.COMPLETION_THRESHOLD;

      // If door was locked again, re-arm the threshold trigger
      if (!window.Game.state.doorUnlocked) {
        this._doorUnlockFired = false;
      }
    }

    console.log(
      `collectibleManager.js: Reset. ` +
      `keepCollected=${keepCollected}, count=${this.collectedCount}`
    );
  },

};
