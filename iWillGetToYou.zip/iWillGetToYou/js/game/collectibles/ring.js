// =============================================================================
// ring.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Defines a single collectible ring for the male path.
// Rings float up and down with a glow pulse animation.
// They are managed by collectibleManager.js — this file just defines
// the data shape and draw behavior for one ring.
//
// RING TYPES (set by level data):
//   common     — small gold ring, counts toward the 80% threshold
//   checkpoint — larger ring, saves respawn point (does not count toward 80%)
//
// collectibleManager.js creates these objects from level data.
// =============================================================================

window.Game = window.Game || {};
window.Game.Ring = window.Game.Ring || {};

// ---------------------------------------------------------------------------
// CREATE RING
// Factory function — returns a new ring object from level data.
// Called by collectibleManager.init() for each ring in the level.
// ---------------------------------------------------------------------------
window.Game.Ring.create = function(data) {
  const C = window.Game.constants;

  const isCheckpoint = data.isCheckpoint || false;

  return {
    // --- Position (world coordinates, top-left of bounding box) ---
    x:      data.x,
    y:      data.y,

    // --- Dimensions ---
    width:  isCheckpoint ? C.CHECKPOINT_WIDTH  : C.RING_WIDTH,
    height: isCheckpoint ? C.CHECKPOINT_HEIGHT : C.RING_HEIGHT,

    // --- Type ---
    isCheckpoint: isCheckpoint,

    // --- State ---
    collected: false,   // true once player picks it up

    // --- Float animation ---
    // Each ring gets a random phase offset so they don't all bob in sync
    floatPhase:  data.floatPhase  || (Math.random() * Math.PI * 2),
    floatOffset: 0,     // current Y offset from base position (calculated each frame)

    // --- Glow animation ---
    glowPhase:   data.glowPhase   || (Math.random() * Math.PI * 2),
    glowAlpha:   1.0,   // current glow opacity (oscillates)

    // --- Base Y position (float oscillates around this) ---
    baseY: data.y,

    // --- Checkpoint activation state ---
    // Only relevant for checkpoint rings
    activated: false,   // true once player has touched this checkpoint

  };
};

// ---------------------------------------------------------------------------
// UPDATE RING
// Advances float and glow animations each frame.
// Called by collectibleManager.update() for each uncollected ring.
// deltaTime in seconds.
// ---------------------------------------------------------------------------
window.Game.Ring.update = function(ring, deltaTime) {
  if (ring.collected) return;   // don't animate after pickup

  const C = window.Game.constants;

  // Advance float phase
  ring.floatPhase += C.RING_FLOAT_SPEED * deltaTime;

  // Calculate current Y offset from base position
  ring.floatOffset = Math.sin(ring.floatPhase) * C.RING_FLOAT_AMOUNT;

  // Update actual Y position
  ring.y = ring.baseY + ring.floatOffset;

  // Advance glow phase
  ring.glowPhase += C.RING_GLOW_SPEED * deltaTime;

  // Glow oscillates between 0.5 and 1.0 opacity
  ring.glowAlpha = 0.5 + 0.5 * Math.abs(Math.sin(ring.glowPhase));
};

// ---------------------------------------------------------------------------
// DRAW RING
// Renders a single ring to the canvas.
// Called by collectibleManager.draw() for each uncollected ring.
// ctx: canvas 2D context (camera transform already applied)
// ---------------------------------------------------------------------------
window.Game.Ring.draw = function(ring, ctx) {
  if (ring.collected) return;

  // Cull: skip drawing if outside camera view
  if (window.Game.camera && !window.Game.camera.isVisible(ring.x, ring.y, ring.width, ring.height)) {
    return;
  }

  const cx = ring.x + ring.width  / 2;   // center X
  const cy = ring.y + ring.height / 2;   // center Y
  const r  = ring.width / 2;             // outer radius

  ctx.save();

  if (ring.isCheckpoint) {
    // -------------------------------------------------------------------
    // CHECKPOINT RING — larger, brighter, with an inner cross marker
    // Color: bright gold with white inner glow
    // -------------------------------------------------------------------
    const activated = ring.activated;

    // Outer glow halo
    const haloGrad = ctx.createRadialGradient(cx, cy, r * 0.5, cx, cy, r * 2.0);
    haloGrad.addColorStop(0, activated
      ? `rgba(0, 255, 120, ${ring.glowAlpha * 0.4})`   // green when activated
      : `rgba(255, 220, 50, ${ring.glowAlpha * 0.35})`);
    haloGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = haloGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, r * 2.0, 0, Math.PI * 2);
    ctx.fill();

    // Ring body
    ctx.strokeStyle = activated ? '#00ff88' : '#ffd700';
    ctx.lineWidth   = 4;
    ctx.shadowColor = activated ? '#00ff88' : '#ffd700';
    ctx.shadowBlur  = 12 * ring.glowAlpha;
    ctx.beginPath();
    ctx.arc(cx, cy, r - 2, 0, Math.PI * 2);
    ctx.stroke();

    // Inner fill
    ctx.fillStyle = activated
      ? `rgba(0, 255, 120, ${0.15 * ring.glowAlpha})`
      : `rgba(255, 215, 0, ${0.15 * ring.glowAlpha})`;
    ctx.beginPath();
    ctx.arc(cx, cy, r - 4, 0, Math.PI * 2);
    ctx.fill();

    // Cross marker inside — signals this is special
    ctx.strokeStyle = activated ? '#00ff88' : '#ffe566';
    ctx.lineWidth   = 2;
    ctx.shadowBlur  = 6;
    const crossSize = r * 0.45;
    ctx.beginPath();
    ctx.moveTo(cx - crossSize, cy);
    ctx.lineTo(cx + crossSize, cy);
    ctx.moveTo(cx, cy - crossSize);
    ctx.lineTo(cx, cy + crossSize);
    ctx.stroke();

    // "CHECKPOINT" label above — only before activation
    if (!activated) {
      ctx.shadowBlur   = 0;
      ctx.fillStyle    = 'rgba(255, 220, 80, 0.85)';
      ctx.font         = '9px "Roboto", sans-serif';
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'bottom';
      ctx.fillText('CHECKPOINT', cx, ring.y - 4);
    }

  } else {
    // -------------------------------------------------------------------
    // COMMON RING — small gold ring with outer glow
    // -------------------------------------------------------------------

    // Outer glow halo (soft, radial)
    const haloGrad = ctx.createRadialGradient(cx, cy, r * 0.3, cx, cy, r * 1.8);
    haloGrad.addColorStop(0, `rgba(255, 200, 0, ${ring.glowAlpha * 0.3})`);
    haloGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = haloGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, r * 1.8, 0, Math.PI * 2);
    ctx.fill();

    // Ring stroke (the actual ring shape — hollow circle)
    ctx.strokeStyle = '#ffd700';
    ctx.lineWidth   = 3;
    ctx.shadowColor = '#ffcc00';
    ctx.shadowBlur  = 8 * ring.glowAlpha;
    ctx.beginPath();
    ctx.arc(cx, cy, r - 1.5, 0, Math.PI * 2);
    ctx.stroke();

    // Subtle inner highlight (top-left specular reflection)
    ctx.strokeStyle = `rgba(255, 255, 200, ${0.6 * ring.glowAlpha})`;
    ctx.lineWidth   = 1.5;
    ctx.shadowBlur  = 0;
    ctx.beginPath();
    ctx.arc(cx - r * 0.15, cy - r * 0.15, r * 0.5, Math.PI * 1.1, Math.PI * 1.7);
    ctx.stroke();
  }

  ctx.restore();
};
