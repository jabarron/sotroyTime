// =============================================================================
// hud.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Draws all in-game HUD elements on top of the game world.
// The HUD is ALWAYS drawn in screen space — camera transform is reset first.
//
// HUD LAYOUT (landscape 1280×720):
//   Top-left:  ❤️❤️❤️ lives  +  💍 14/20 ring counter
//   Top-right: 2:14 timer  +  ⏸ pause button
//   Bottom-right: dash cooldown bar (near right thumb)
//   Center:    contextual callout text (fades in/out)
//
// The timer changes color:
//   Green  → above TIMER_YELLOW_SECONDS (60s)
//   Yellow → between 30s and 60s
//   Red    → below TIMER_WARNING_SECONDS (30s), pulses
//
// Ring counter turns green when 80% threshold is met.
// =============================================================================

window.Game = window.Game || {};

window.Game.hud = {

  // ---------------------------------------------------------------------------
  // CALLOUT STATE
  // ---------------------------------------------------------------------------
  activeCallout:  null,    // string currently displayed, or null
  calloutTimer:   0,       // ms remaining to display
  calloutAlpha:   0,       // current opacity (0-1), for fade in/out
  _calloutFading: false,   // true when fading out

  // Timer warning sound — only play once per level
  _timerWarnFired: false,

  // ---------------------------------------------------------------------------
  // UPDATE
  // Called every frame by game.js during GAMEPLAY.
  // Ticks the game timer and manages callout fade lifecycle.
  // deltaTime in seconds.
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    const C     = window.Game.constants;
    const state = window.Game.state;

    // --- Tick the game timer ---
    if (state.timerActive && state.timerSeconds > 0) {
      state.timerSeconds -= deltaTime;

      if (state.timerSeconds < 0) state.timerSeconds = 0;

      // Fire timer warning sound + callout once when crossing 30s threshold
      if (state.timerSeconds <= C.TIMER_WARNING_SECONDS && !this._timerWarnFired) {
        this._timerWarnFired = true;

        if (window.Game.audio) {
          window.Game.audio.play('timer_warning');
        }
        this.showCallout("The ship won't last much longer.");
      }

      // Timer hit zero — ship explodes — game over
      if (state.timerSeconds <= 0 && state.current === 'GAMEPLAY') {
        state.timerSeconds = 0;
        // Trigger game over directly (no lives decrement — timer death is final)
        if (window.Game.audio) {
          window.Game.audio.stopAll();
          window.Game.audio.play('game_over');
        }
        state.transition('GAME_OVER');
        return;
      }
    }

    // --- Manage callout fade lifecycle ---
    if (this.activeCallout) {
      const fadeMs = C.CALLOUT_FADE_MS;
      const totalMs = C.CALLOUT_DISPLAY_MS;

      this.calloutTimer -= deltaTime * 1000;

      if (this.calloutTimer > totalMs - fadeMs) {
        // Fading IN
        this.calloutAlpha = 1 - (this.calloutTimer - (totalMs - fadeMs)) / fadeMs;
      } else if (this.calloutTimer < fadeMs) {
        // Fading OUT
        this.calloutAlpha = Math.max(0, this.calloutTimer / fadeMs);
      } else {
        // Fully visible
        this.calloutAlpha = 1;
      }

      // Callout expired
      if (this.calloutTimer <= 0) {
        this.activeCallout = null;
        this.calloutAlpha  = 0;
      }
    }
  },

  // ---------------------------------------------------------------------------
  // SHOW CALLOUT
  // Displays a contextual text callout in the center of the screen.
  // New callouts override the current one immediately.
  // Called by levelLoader.checkCallouts() and game events.
  // ---------------------------------------------------------------------------
  showCallout(text) {
    const C = window.Game.constants;
    this.activeCallout = text;
    this.calloutTimer  = C.CALLOUT_DISPLAY_MS;
    this.calloutAlpha  = 0;   // start transparent, fade in
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Renders all HUD elements in screen space.
  // Called every frame by game.js AFTER camera.reset() so the HUD is
  // always fixed to the screen regardless of camera position.
  // ctx: canvas 2D context (NO camera transform active when this runs)
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C     = window.Game.constants;
    const state = window.Game.state;

    ctx.save();

    // Draw all HUD sections
    this._drawLives(ctx, state, C);
    this._drawRingCounter(ctx, state, C);
    this._drawTimer(ctx, state, C);
    this._drawPauseButton(ctx, C);
    this._drawDashCooldown(ctx, C);
    this._drawCallout(ctx, C);

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawLives (private)
  // Draws heart icons top-left.
  // Full hearts = remaining lives. Empty hearts = lost lives.
  // ---------------------------------------------------------------------------
  _drawLives(ctx, state, C) {
    const pad  = C.HUD_PADDING;
    const size = C.HEART_SIZE;
    const gap  = C.HEART_GAP;

    for (let i = 0; i < C.MAX_LIVES; i++) {
      const x = pad + i * (size + gap);
      const y = pad;
      const full = i < state.lives;

      this._drawHeart(ctx, x, y, size, full);
    }
  },

  // ---------------------------------------------------------------------------
  // _drawHeart (private)
  // Draws a single heart icon using canvas paths.
  // full: true = red filled heart, false = dark empty heart
  // ---------------------------------------------------------------------------
  _drawHeart(ctx, x, y, size, full) {
    const cx = x + size / 2;
    const cy = y + size / 2;
    const r  = size * 0.28;

    ctx.save();
    ctx.beginPath();

    // Heart shape: two circles on top, triangle on bottom
    // Left circle
    ctx.arc(cx - r, cy - r * 0.4, r, Math.PI, 0);
    // Right circle
    ctx.arc(cx + r, cy - r * 0.4, r, Math.PI, 0);
    // Bottom point
    ctx.lineTo(cx + r * 2, cy - r * 0.4);
    ctx.quadraticCurveTo(cx + r * 2, cy + r * 0.8, cx, cy + r * 2.2);
    ctx.quadraticCurveTo(cx - r * 2, cy + r * 0.8, cx - r * 2, cy - r * 0.4);
    ctx.closePath();

    if (full) {
      ctx.fillStyle   = '#ff3355';
      ctx.shadowColor = '#ff0033';
      ctx.shadowBlur  = 6;
      ctx.fill();
      // Inner highlight
      ctx.fillStyle = 'rgba(255,180,180,0.4)';
      ctx.beginPath();
      ctx.ellipse(cx - r * 0.3, cy - r * 0.1, r * 0.5, r * 0.35, -0.4, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = 'rgba(80,40,50,0.6)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(150,80,90,0.5)';
      ctx.lineWidth   = 1.5;
      ctx.stroke();
    }

    ctx.shadowBlur = 0;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawRingCounter (private)
  // Draws ring icon + "14/20" count below the hearts.
  // Turns green when 80% threshold is met.
  // ---------------------------------------------------------------------------
  _drawRingCounter(ctx, state, C) {
    const pad      = C.HUD_PADDING;
    const progress = window.Game.collectibles
      ? window.Game.collectibles.getProgress()
      : { collected: 0, total: 0, thresholdMet: false };

    const thresholdMet = progress.thresholdMet || state.doorUnlocked;
    const color        = thresholdMet ? '#44ff88' : '#ffd700';
    const text         = `${progress.collected} / ${progress.total}`;

    // Ring icon (small circle with inner ring)
    const iconX = pad + 4;
    const iconY = pad + C.HEART_SIZE + 10;
    const iconR = 8;

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth   = 2.5;
    ctx.shadowColor = color;
    ctx.shadowBlur  = thresholdMet ? 8 : 4;
    ctx.beginPath();
    ctx.arc(iconX + iconR, iconY + iconR, iconR, 0, Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Counter text
    ctx.fillStyle    = color;
    ctx.font         = `bold 16px "Roboto", sans-serif`;
    ctx.textAlign    = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, iconX + iconR * 2 + 8, iconY + iconR);

    // "RINGS" label
    ctx.fillStyle    = 'rgba(255,255,255,0.4)';
    ctx.font         = '10px "Roboto", sans-serif';
    ctx.fillText('RINGS', iconX + iconR * 2 + 8, iconY + iconR + 14);

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawTimer (private)
  // Draws countdown timer top-right.
  // Color transitions: green → yellow → red (pulsing).
  // ---------------------------------------------------------------------------
  _drawTimer(ctx, state, C) {
    const seconds  = Math.max(0, state.timerSeconds);
    const mins     = Math.floor(seconds / 60);
    const secs     = Math.floor(seconds % 60);
    const timeStr  = `${mins}:${secs.toString().padStart(2, '0')}`;

    // Determine color based on remaining time
    let color;
    let pulse = 1;

    if (seconds <= C.TIMER_WARNING_SECONDS) {
      // Red — pulsing
      const t = Date.now() / 1000;
      pulse   = 0.7 + 0.3 * Math.sin(t * C.TIMER_PULSE_SPEED);
      color   = `rgba(255, ${Math.round(40 * pulse)}, ${Math.round(40 * pulse)}, ${pulse})`;
    } else if (seconds <= C.TIMER_YELLOW_SECONDS) {
      // Yellow
      color = '#ffcc00';
    } else {
      // Green
      color = '#44ff88';
    }

    const padRight = C.HUD_PADDING;
    const x        = C.CANVAS_WIDTH - padRight;
    const y        = C.HUD_PADDING + 20;

    ctx.save();
    ctx.textAlign    = 'right';
    ctx.textBaseline = 'middle';

    // Shadow/glow
    ctx.shadowColor = color;
    ctx.shadowBlur  = seconds <= C.TIMER_WARNING_SECONDS ? 12 * pulse : 4;

    // Timer label
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.font      = '11px "Roboto", sans-serif';
    ctx.fillText('TIME', x, y - 16);

    // Timer value
    ctx.fillStyle = color;
    ctx.font      = `bold 28px "Roboto", sans-serif`;
    ctx.fillText(timeStr, x, y + 4);

    ctx.shadowBlur = 0;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawPauseButton (private)
  // Draws a ⏸ pause icon top-right, left of timer.
  // The actual DOM button handles touch — this is just the visual indicator.
  // ---------------------------------------------------------------------------
  _drawPauseButton(ctx, C) {
    const x = C.CANVAS_WIDTH - C.HUD_PADDING - 140;
    const y = C.HUD_PADDING + 4;
    const w = 28;
    const h = 28;

    ctx.save();
    ctx.fillStyle   = 'rgba(255,255,255,0.12)';
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth   = 1.5;

    // Background circle
    ctx.beginPath();
    ctx.arc(x + w / 2, y + h / 2, w / 2 + 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Pause bars
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.fillRect(x + 8,  y + 7, 5, 14);
    ctx.fillRect(x + 16, y + 7, 5, 14);

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawDashCooldown (private)
  // Draws a small bar near the bottom-right showing dash cooldown.
  // Full = dash ready (glowing). Filling up = on cooldown.
  // Position: above the jump/dash buttons (bottom-right thumb area).
  // ---------------------------------------------------------------------------
  _drawDashCooldown(ctx, C) {
    const player = window.Game.player;
    if (!player) return;

    const ratio = player.getDashCooldownRatio();   // 0.0 → 1.0
    const barW  = C.COOLDOWN_BAR_WIDTH;
    const barH  = C.COOLDOWN_BAR_HEIGHT;
    const x     = C.CANVAS_WIDTH  - C.HUD_PADDING - barW;
    const y     = C.CANVAS_HEIGHT - C.HUD_PADDING - 120;   // above touch buttons

    ctx.save();

    // Background track
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    ctx.beginPath();
    ctx.roundRect(x, y, barW, barH, 3);
    ctx.fill();

    // Fill
    if (ratio > 0) {
      const fillW   = barW * ratio;
      const ready   = ratio >= 1.0;
      ctx.fillStyle = ready ? '#4af0c0' : '#2266aa';

      if (ready) {
        ctx.shadowColor = '#4af0c0';
        ctx.shadowBlur  = 6;
      }

      ctx.beginPath();
      ctx.roundRect(x, y, fillW, barH, 3);
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // "DASH" label above bar
    ctx.fillStyle    = 'rgba(255,255,255,0.35)';
    ctx.font         = '9px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'bottom';
    ctx.fillText('DASH', x + barW / 2, y - 2);

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawCallout (private)
  // Draws contextual story text in the center of the screen.
  // Fades in and out smoothly.
  // ---------------------------------------------------------------------------
  _drawCallout(ctx, C) {
    if (!this.activeCallout || this.calloutAlpha <= 0) return;

    const x = C.CANVAS_WIDTH  / 2;
    const y = C.CANVAS_HEIGHT * 0.72;   // lower center — doesn't cover gameplay

    ctx.save();
    ctx.globalAlpha  = this.calloutAlpha;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';

    // Text shadow/glow for readability over any background
    ctx.shadowColor = 'rgba(0,0,0,0.9)';
    ctx.shadowBlur  = 12;

    // Italic for narrative feel
    ctx.font      = 'italic 18px "Roboto", sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(this.activeCallout, x, y);

    // Subtle underline bar
    const metrics = ctx.measureText(this.activeCallout);
    const lineW   = Math.min(metrics.width + 20, 500);
    ctx.shadowBlur  = 0;
    ctx.fillStyle   = `rgba(74, 240, 192, ${this.calloutAlpha * 0.6})`;
    ctx.fillRect(x - lineW / 2, y + 14, lineW, 1.5);

    ctx.globalAlpha = 1;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // RESET
  // Clears callout state and timer warning flag.
  // Called when a new level loads.
  // ---------------------------------------------------------------------------
  reset() {
    this.activeCallout   = null;
    this.calloutTimer    = 0;
    this.calloutAlpha    = 0;
    this._timerWarnFired = false;
  },

};
