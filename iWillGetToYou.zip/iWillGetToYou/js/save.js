// =============================================================================
// save.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Handles ALL reading and writing to localStorage.
// This is the only file that touches localStorage — no other file does this.
// Persistent data survives browser closes. Session data lives in stateManager.
//
// localStorage key: 'iWillGetToYou_save'
// =============================================================================

window.Game = window.Game || {};

window.Game.save = {

  // ---------------------------------------------------------------------------
  // STORAGE KEY
  // One key, one JSON object. Keeps localStorage clean.
  // ---------------------------------------------------------------------------
  STORAGE_KEY: 'iWillGetToYou_save',

  // ---------------------------------------------------------------------------
  // DATA SHAPE
  // This is the exact object stored in localStorage.
  // Initialized to defaults, then overwritten by load().
  // ---------------------------------------------------------------------------
  data: {
    levelsUnlocked:  [1],          // array of unlocked level numbers
                                   // starts with only level 1 unlocked
    bestStars: {                   // best star rating achieved per level
      1: 0,                        // 0 = not yet played
      2: 0
    },
    bestTime: {                    // best completion time in seconds per level
      1: null,                     // null = not yet completed
      2: null
    },
    bestRings: {                   // best ring collection count per level
      1: 0,
      2: 0
    },
    totalRingsEver:   0,           // lifetime ring count across all runs
    selectedGender:   null,        // remembered from last session ('male'|'female')
    hasPlayedBefore:  false,       // false on very first launch
  },

  // ---------------------------------------------------------------------------
  // LOAD
  // Reads localStorage on startup. If no save exists, uses defaults above.
  // Merges saved data with defaults so new fields added later don't break
  // saves from older versions of the game.
  // ---------------------------------------------------------------------------
  load() {
    try {
      const raw = localStorage.getItem(this.STORAGE_KEY);

      if (raw === null) {
        // First time ever — no save exists yet
        console.log('save.js: No save found. Starting fresh.');
        return this.data;   // return defaults
      }

      const parsed = JSON.parse(raw);

      // Merge parsed data INTO defaults (so missing fields use defaults)
      // This protects against old saves missing new fields
      this.data = Object.assign({}, this.data, parsed);

      // Deep-merge nested objects (bestStars, bestTime, bestRings)
      this.data.bestStars  = Object.assign({ 1: 0, 2: 0 },  parsed.bestStars  || {});
      this.data.bestTime   = Object.assign({ 1: null, 2: null }, parsed.bestTime || {});
      this.data.bestRings  = Object.assign({ 1: 0, 2: 0 },  parsed.bestRings  || {});

      console.log('save.js: Save loaded.', this.data);
      return this.data;

    } catch (err) {
      // If JSON is corrupted, wipe and start fresh rather than crashing
      console.warn('save.js: Corrupted save. Resetting.', err);
      this.reset();
      return this.data;
    }
  },

  // ---------------------------------------------------------------------------
  // WRITE
  // Serializes current data to localStorage.
  // Call this after ANY change to this.data.
  // ---------------------------------------------------------------------------
  write() {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.data));
    } catch (err) {
      // localStorage can be full or blocked (private browsing on some browsers)
      console.warn('save.js: Could not write to localStorage.', err);
    }
  },

  // ---------------------------------------------------------------------------
  // UNLOCK LEVEL
  // Adds a level number to the unlocked array if not already there.
  // Called by stateManager after level 1 is complete.
  // ---------------------------------------------------------------------------
  unlockLevel(levelNumber) {
    if (!this.data.levelsUnlocked.includes(levelNumber)) {
      this.data.levelsUnlocked.push(levelNumber);
      this.write();
      console.log(`save.js: Level ${levelNumber} unlocked.`);
    }
  },

  // ---------------------------------------------------------------------------
  // IS LEVEL UNLOCKED
  // Used by levelSelect.js to show lock/unlock icons.
  // ---------------------------------------------------------------------------
  isLevelUnlocked(levelNumber) {
    return this.data.levelsUnlocked.includes(levelNumber);
  },

  // ---------------------------------------------------------------------------
  // RECORD COMPLETION
  // Called by stateManager after a level is completed.
  // Only updates a record if it's better than the previous best.
  // ---------------------------------------------------------------------------
  recordCompletion(levelNumber, stars, timeSeconds, ringsCollected) {

    let changed = false;

    // Update best stars (higher is better)
    if (stars > (this.data.bestStars[levelNumber] || 0)) {
      this.data.bestStars[levelNumber] = stars;
      changed = true;
    }

    // Update best time (lower is better — fastest completion)
    const currentBest = this.data.bestTime[levelNumber];
    if (currentBest === null || timeSeconds < currentBest) {
      this.data.bestTime[levelNumber] = timeSeconds;
      changed = true;
    }

    // Update best ring count (higher is better)
    if (ringsCollected > (this.data.bestRings[levelNumber] || 0)) {
      this.data.bestRings[levelNumber] = ringsCollected;
      changed = true;
    }

    // Add to lifetime ring total
    this.data.totalRingsEver += ringsCollected;
    changed = true;

    // Mark that the player has played before (hides tutorial hints)
    this.data.hasPlayedBefore = true;

    if (changed) {
      this.write();
      console.log(`save.js: Level ${levelNumber} recorded — ${stars}★ in ${timeSeconds}s with ${ringsCollected} rings.`);
    }
  },

  // ---------------------------------------------------------------------------
  // SAVE GENDER SELECTION
  // Remembers which path the player chose so it can be pre-selected next time.
  // ---------------------------------------------------------------------------
  saveGender(gender) {
    this.data.selectedGender = gender;   // 'male' | 'female'
    this.write();
  },

  // ---------------------------------------------------------------------------
  // GET BEST STARS FOR LEVEL
  // Returns 0 if never played, 1-3 if completed.
  // ---------------------------------------------------------------------------
  getBestStars(levelNumber) {
    return this.data.bestStars[levelNumber] || 0;
  },

  // ---------------------------------------------------------------------------
  // RESET
  // Wipes all saved data. Used for debug or a "reset all progress" settings option.
  // ---------------------------------------------------------------------------
  reset() {
    this.data = {
      levelsUnlocked:  [1],
      bestStars:       { 1: 0, 2: 0 },
      bestTime:        { 1: null, 2: null },
      bestRings:       { 1: 0, 2: 0 },
      totalRingsEver:  0,
      selectedGender:  null,
      hasPlayedBefore: false,
    };
    this.write();
    console.log('save.js: All progress reset.');
  },

};
