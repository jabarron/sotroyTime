// =============================================================================
// particles.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Manages all visual particle effects:
//   - 'exhaust'  — rocket boost trail during dash
//   - 'sparkle'  — ring collection burst
//   - 'checkpoint_burst' — larger burst when checkpoint is touched
//   - 'explosion' — debris when an explosion zone fires
//
// All particles are drawn in WORLD SPACE (camera transform already applied).
// Uses an object pool to avoid garbage collection spikes on mobile.
// =============================================================================

window.Game = window.Game || {};

window.Game.particles = {

  // ---------------------------------------------------------------------------
  // POOL
  // A flat array of particle objects.
  // Dead particles (life <= 0) are recycled rather than deleted.
  // This avoids creating new objects constantly, which causes GC pauses.
  // ---------------------------------------------------------------------------
  pool: [],

  // Maximum particles alive at once — keeps performance safe on mobile
  MAX_PARTICLES: 200,

  // ---------------------------------------------------------------------------
  // PARTICLE TEMPLATE
  // All particles share this shape.
  // ---------------------------------------------------------------------------
  // {
  //   active:   Boolean  — false = dead, available for reuse
  //   x:        Number   — world X position
  //   y:        Number   — world Y position
  //   vx:       Number   — velocity X (pixels/sec)
  //   vy:       Number   — velocity Y (pixels/sec)
  //   life:     Number   — remaining lifetime in ms
  //   maxLife:  Number   — total lifetime in ms (for opacity calculation)
  //   radius:   Number   — drawn size in pixels
  //   color:    String   — CSS color string
  //   gravity:  Number   — per-particle gravity (0 for exhaust, small for sparkle)
  // }

  // ---------------------------------------------------------------------------
  // INIT
  // Pre-allocates the pool. Called once by main.js.
  // ---------------------------------------------------------------------------
  init() {
    this.pool = [];
    for (let i = 0; i < this.MAX_PARTICLES; i++) {
      this.pool.push({
        active:  false,
        x: 0, y: 0, vx: 0, vy: 0,
        life: 0, maxLife: 1,
        radius: 3,
        color: '#ffffff',
        gravity: 0,
      });
    }
    console.log(`particles.js: Pool of ${this.MAX_PARTICLES} particles ready.`);
  },

  // ---------------------------------------------------------------------------
  // _getParticle (private)
  // Returns a dead particle from the pool to be reused.
  // If pool is full, returns null (particle is skipped — no crash).
  // ---------------------------------------------------------------------------
  _getParticle() {
    for (let i = 0; i < this.pool.length; i++) {
      if (!this.pool[i].active) {
        return this.pool[i];
      }
    }
    return null;   // pool exhausted — skip this particle silently
  },

  // ---------------------------------------------------------------------------
  // EMIT
  // Spawns 'count' particles at world position (x, y) of the given type.
  // type: 'exhaust' | 'sparkle' | 'checkpoint_burst' | 'explosion'
  // ---------------------------------------------------------------------------
  emit(type, x, y, count) {
    const C = window.Game.constants;

    for (let i = 0; i < count; i++) {
      const p = this._getParticle();
      if (!p) return;   // pool full — stop emitting

      p.active = true;
      p.x = x;
      p.y = y;

      // Configure each particle based on type
      switch (type) {

        case 'exhaust': {
          // Rocket exhaust — emits BEHIND the player (opposite of facing direction)
          // Orange/white glow, flies backward and slightly random
          const player = window.Game.player;
          const dir    = player ? -player.facingDirection : -1;

          // Spread cone: mostly backward with slight upward/downward variation
          const spreadAngle = (Math.random() - 0.5) * (C.EXHAUST_SPREAD * Math.PI / 180);
          const speed       = 120 + Math.random() * 180;

          p.vx      = Math.cos(spreadAngle) * speed * dir;
          p.vy      = Math.sin(spreadAngle) * speed - 30;  // slight upward bias
          p.life    = C.EXHAUST_LIFE_MS * (0.6 + Math.random() * 0.4);
          p.maxLife = p.life;
          p.radius  = 3 + Math.random() * 4;
          p.gravity = 0;   // exhaust floats in zero-G feel

          // Color cycles from white → orange → dark orange as it ages
          // (handled in draw by lerping based on life ratio)
          p.color   = '#ff8833';
          break;
        }

        case 'sparkle': {
          // Ring collect sparkle — bright gold burst in all directions
          const angle = (Math.PI * 2 * i) / count + Math.random() * 0.5;
          const speed = 80 + Math.random() * 120;

          p.vx      = Math.cos(angle) * speed;
          p.vy      = Math.sin(angle) * speed;
          p.life    = C.SPARKLE_LIFE_MS * (0.7 + Math.random() * 0.3);
          p.maxLife = p.life;
          p.radius  = 2 + Math.random() * 3;
          p.gravity = 60;    // slight gravity so they arc downward
          p.color   = Math.random() < 0.5 ? '#ffe066' : '#ffffff';
          break;
        }

        case 'checkpoint_burst': {
          // Larger, brighter burst for checkpoint ring
          const angle = (Math.PI * 2 * i) / count;
          const speed = 100 + Math.random() * 160;

          p.vx      = Math.cos(angle) * speed;
          p.vy      = Math.sin(angle) * speed;
          p.life    = C.SPARKLE_LIFE_MS * 1.5 * (0.8 + Math.random() * 0.2);
          p.maxLife = p.life;
          p.radius  = 3 + Math.random() * 5;
          p.gravity = 40;
          p.color   = Math.random() < 0.4 ? '#ffe066' : (Math.random() < 0.5 ? '#ffffff' : '#ffaa00');
          break;
        }

        case 'explosion': {
          // Explosion debris — red/orange shards fly outward
          const angle = Math.random() * Math.PI * 2;
          const speed = 60 + Math.random() * 200;

          p.vx      = Math.cos(angle) * speed;
          p.vy      = Math.sin(angle) * speed;
          p.life    = 400 + Math.random() * 400;
          p.maxLife = p.life;
          p.radius  = 2 + Math.random() * 6;
          p.gravity = 120;   // debris falls
          p.color   = Math.random() < 0.5 ? '#ff4400' : '#ff8800';
          break;
        }

        default:
          p.active = false;   // unknown type — return to pool immediately
          break;
      }
    }
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // Moves all active particles and ages them.
  // Called every frame by game.js during GAMEPLAY.
  // deltaTime is in SECONDS.
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    for (let i = 0; i < this.pool.length; i++) {
      const p = this.pool[i];
      if (!p.active) continue;

      // Move by velocity
      p.x += p.vx * deltaTime;
      p.y += p.vy * deltaTime;

      // Apply per-particle gravity
      p.vy += p.gravity * deltaTime;

      // Age the particle (life is in ms, deltaTime is in seconds)
      p.life -= deltaTime * 1000;

      // Kill if lifetime expired
      if (p.life <= 0) {
        p.active = false;
      }
    }
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Renders all active particles to the canvas.
  // Called every frame AFTER camera.apply() so coordinates are in world space.
  // ---------------------------------------------------------------------------
  draw(ctx) {
    ctx.save();

    for (let i = 0; i < this.pool.length; i++) {
      const p = this.pool[i];
      if (!p.active) continue;

      // Fade out as particle ages (opacity = remaining life / total life)
      const lifeRatio = Math.max(0, p.life / p.maxLife);
      ctx.globalAlpha = lifeRatio;

      // For exhaust: color shifts from white (fresh) to dark orange (old)
      if (p.color === '#ff8833') {
        // Interpolate: white → orange → dark based on lifeRatio
        if (lifeRatio > 0.6) {
          ctx.fillStyle = '#ffffff';   // hot white core when fresh
        } else if (lifeRatio > 0.3) {
          ctx.fillStyle = '#ff8833';   // orange middle age
        } else {
          ctx.fillStyle = '#662200';   // dark red ember when dying
        }
      } else {
        ctx.fillStyle = p.color;
      }

      // Draw as a simple circle
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius * lifeRatio, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.globalAlpha = 1;   // always restore alpha after drawing particles
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // CLEAR
  // Kills all active particles instantly.
  // Called on death/respawn to clean up stale exhaust trails.
  // ---------------------------------------------------------------------------
  clear() {
    for (let i = 0; i < this.pool.length; i++) {
      this.pool[i].active = false;
    }
  },

  // ---------------------------------------------------------------------------
  // COUNT (debug utility)
  // Returns the number of currently active particles.
  // ---------------------------------------------------------------------------
  count() {
    return this.pool.filter(p => p.active).length;
  },

};
