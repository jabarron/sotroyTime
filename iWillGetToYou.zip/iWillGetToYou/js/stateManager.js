// =============================================================================
// stateManager.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// THE CENTRAL NERVOUS SYSTEM of the game.
// Only one state can be active at any moment.
// Every system checks Game.state.current before acting.
// Only stateManager.transition() is allowed to change the current state.
// Never write to Game.state.current directly from any other file.
// =============================================================================

window.Game = window.Game || {};

window.Game.state = {

  // ---------------------------------------------------------------------------
  // CURRENT STATE
  // The active screen or mode. Every system reads this before doing anything.
  // ---------------------------------------------------------------------------
  current: 'SPLASH',   // starting state — first thing the player sees

  // ---------------------------------------------------------------------------
  // VALID STATES (all possible values of current)
  // ---------------------------------------------------------------------------
  // 'SPLASH'          — logo fades in, auto-advances after SPLASH_DURATION_MS
  // 'GENDER_SELECT'   — player chooses male or female path
  // 'LOADING'         — assets loading, shows progress bar
  // 'MAIN_MENU'       — play and settings buttons
  // 'LEVEL_SELECT'    — level cards (locked/unlocked)
  // 'CUTSCENE_INTRO'  — animated canvas intro sequence
  // 'GAMEPLAY'        — active play, physics running, timer ticking
  // 'PAUSED'          — game frozen, pause menu visible
  // 'DEATH_ANIMATION' — player death flash, brief pause before respawn
  // 'CUTSCENE_OUTRO'  — animated canvas outro after level clear
  // 'LEVEL_COMPLETE'  — stars, rings, time summary screen
  // 'GAME_OVER'       — all lives lost screen
  // 'VICTORY'         — after final level cleared
  // 'CREDITS'         — rolling credits, dedication

  previous: null,   // last state — used for back-navigation and resume

  // ---------------------------------------------------------------------------
  // SESSION DATA
  // Resets each time the player starts a new run.
  // Persisted bests are in save.js (localStorage), not here.
  // ---------------------------------------------------------------------------

  // --- Player selection ---
  selectedGender: null,    // 'male' | 'female' — set on gender select screen

  // --- Level tracking ---
  currentLevel: 1,         // which level is being played (1 or 2)

  // --- Lives ---
  lives: 3,                // current lives remaining — starts at MAX_LIVES

  // --- Collectibles ---
  ringsCollected: 0,       // rings grabbed this run (resets on level restart)
  ringsTotal:     0,       // total rings in the level (set by levelLoader)

  // --- Timer ---
  timerSeconds:  180,      // counts DOWN from LEVEL_TIME_SECONDS
  timerActive:   false,    // only ticks when state is GAMEPLAY

  // --- Checkpoint ---
  checkpointReached:        false,  // has player touched the checkpoint ring?
  checkpointX:              0,      // world X position of checkpoint
  checkpointY:              0,      // world Y position of checkpoint
  checkpointRingsCollected: 0,      // ring count at moment of checkpoint touch
  // NOTE: on death, timer resets to LEVEL_TIME_SECONDS (not checkpoint time)
  // NOTE: rings collected before checkpoint are KEPT after death

  // --- Exit door ---
  doorUnlocked: false,     // true when ringsCollected / ringsTotal >= 0.80

  // --- Run statistics (for star rating on level complete screen) ---
  deaths:     0,           // increments on each death this level
  perfectRun: true,        // flips to false on first death — needed for 3 stars

  // --- Callouts ---
  // Tracks which position-based callouts have already fired this run
  // so they only show once. Keyed by triggerX value.
  firedCallouts: {},       // e.g. { 200: true, 1500: true }

  // --- Flags ---
  levelComplete: false,    // true when player reaches unlocked exit door

  // ---------------------------------------------------------------------------
  // TRANSITION
  // The ONLY way to change the current state.
  // Logs the change in development, enforces valid state names.
  // ---------------------------------------------------------------------------
  transition(newState) {

    // Guard: reject unknown state names to catch typos early
    const validStates = [
      'SPLASH', 'GENDER_SELECT', 'LOADING', 'MAIN_MENU',
      'LEVEL_SELECT', 'CUTSCENE_INTRO', 'GAMEPLAY', 'PAUSED',
      'DEATH_ANIMATION', 'CUTSCENE_OUTRO', 'LEVEL_COMPLETE',
      'GAME_OVER', 'VICTORY', 'CREDITS'
    ];

    if (!validStates.includes(newState)) {
      console.error(`stateManager: unknown state "${newState}"`);
      return;  // refuse to transition to an invalid state
    }

    // Store the previous state before overwriting
    // (used by pauseMenu to know where to resume, etc.)
    this.previous = this.current;
    this.current  = newState;

    console.log(`State: ${this.previous} → ${this.current}`);

    // Notify any systems that need to react to state changes
    // Each system is responsible for checking state in its own update loop,
    // but we fire these hooks for immediate one-time reactions.
    this._onEnter(newState);
  },

  // ---------------------------------------------------------------------------
  // _onEnter — private hook called immediately when entering a new state
  // Handles one-time setup for each state.
  // ---------------------------------------------------------------------------
  _onEnter(state) {

    if (state === 'GAMEPLAY') {
      // Start the timer when gameplay begins
      this.timerActive = true;
      // Show on-screen touch controls
      document.body.classList.add('is-playing');

      // Stop any music from previous screens
      if (window.Game.audio) {
        // Level music is started by levelLoader, not here
      }
    }

    if (state === 'PAUSED') {
      // Freeze the timer
      this.timerActive = false;
      // Hide touch controls during pause (pause menu replaces them)
      document.body.classList.remove('is-playing');

      // Stop all audio while paused
      if (window.Game.audio) {
        window.Game.audio.stopAll();
      }
    }

    if (state === 'GAMEPLAY' && this.previous === 'PAUSED') {
      // Resuming from pause — restart music
      this.timerActive = true;
      if (window.Game.audio && window.Game.level && window.Game.level.data) {
        window.Game.audio.loop(window.Game.level.data.music);
      }
    }

    if (state === 'DEATH_ANIMATION') {
      // Freeze the timer during death animation
      this.timerActive = false;

      // Play death sound
      if (window.Game.audio) {
        window.Game.audio.play('death');
      }

      // Update run stats
      this.deaths++;
      this.perfectRun = false;   // player died — 3-star run is now impossible
      this.lives--;

      // After the death animation duration, decide what happens next
      const C = window.Game.constants;
      setTimeout(() => {

        if (this.lives <= 0) {
          // No lives left — game over
          this.transition('GAME_OVER');
        } else {
          // Still have lives — respawn at checkpoint
          if (window.Game.player) {
            const spawnX = this.checkpointReached
              ? this.checkpointX
              : window.Game.level.data.playerStart.x;
            const spawnY = this.checkpointReached
              ? this.checkpointY
              : window.Game.level.data.playerStart.y;

            // Restore rings to checkpoint count (rings before checkpoint are kept)
            this.ringsCollected = this.checkpointRingsCollected;

            // Reset timer to full 3 minutes on death (approved in design doc)
            this.timerSeconds = C.LEVEL_TIME_SECONDS;

            // Re-check door status with restored ring count
            this.doorUnlocked =
              (this.ringsCollected / this.ringsTotal) >= C.COMPLETION_THRESHOLD;

            // Respawn the player
            window.Game.player.respawn(spawnX, spawnY);

            // Clear particles from death
            if (window.Game.particles) {
              window.Game.particles.clear();
            }
          }
          this.transition('GAMEPLAY');
        }

      }, C.DEATH_FLASH_MS);
    }

    if (state === 'GAME_OVER') {
      this.timerActive = false;
      document.body.classList.remove('is-playing');
      if (window.Game.audio) {
        window.Game.audio.stopAll();
        window.Game.audio.play('game_over');
      }
    }

    if (state === 'LEVEL_COMPLETE') {
      this.timerActive = false;
      if (window.Game.audio) {
        window.Game.audio.stopAll();
        window.Game.audio.play('level_complete');
      }

      // Save progress to localStorage
      if (window.Game.save) {
        const stars = this._calculateStars();
        window.Game.save.recordCompletion(
          this.currentLevel,
          stars,
          Math.round(window.Game.constants.LEVEL_TIME_SECONDS - this.timerSeconds),
          this.ringsCollected
        );
        // Since level 1 is the only level at launch, unlock credits
        // (no level 2 to unlock yet)
      }
    }

    if (state === 'CUTSCENE_OUTRO') {
      document.body.classList.remove('is-playing');
    }

    if (state === 'CREDITS') {
      if (window.Game.audio) {
        window.Game.audio.stopAll();
        // Credits music could play here if added later
      }
    }
  },

  // ---------------------------------------------------------------------------
  // _calculateStars — determines star rating based on run performance
  // 1 star: reached exit (minimum — just completed the level)
  // 2 stars: reached exit + collected 100% of rings
  // 3 stars: reached exit + 100% rings + zero deaths (perfect run)
  // ---------------------------------------------------------------------------
  _calculateStars() {
    const collectedAll = this.ringsCollected >= this.ringsTotal;

    if (collectedAll && this.perfectRun) return 3;
    if (collectedAll)                    return 2;
    return 1;
  },

  // ---------------------------------------------------------------------------
  // RESET SESSION
  // Called when starting a new level or restarting from the beginning.
  // Does NOT touch save.js data — only session-level state.
  // ---------------------------------------------------------------------------
  reset() {
    const C = window.Game.constants;

    this.lives            = C.MAX_LIVES;
    this.ringsCollected   = 0;
    this.ringsTotal       = 0;
    this.timerSeconds     = C.LEVEL_TIME_SECONDS;
    this.timerActive      = false;
    this.checkpointReached        = false;
    this.checkpointX              = 0;
    this.checkpointY              = 0;
    this.checkpointRingsCollected = 0;
    this.doorUnlocked     = false;
    this.levelComplete    = false;
    this.deaths           = 0;
    this.perfectRun       = true;
    this.firedCallouts    = {};

    console.log('State reset for new run.');
  },

};
