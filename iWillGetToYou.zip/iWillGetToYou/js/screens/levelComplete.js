// =============================================================================
// levelComplete.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Level complete summary screen. Shown after player reaches exit door.
// Displays:
//   - Star rating (1-3 stars) with animated reveal
//   - Rings collected vs total
//   - Time taken
//   - New record indicators
//   - "Continue" button → CREDITS (since level 1 is the only level at launch)
// =============================================================================

window.Game = window.Game || {};
window.Game.screens = window.Game.screens || {};

window.Game.screens.levelComplete = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  alpha:        0,
  timer:        0,
  starsRevealed: 0,      // 0-3, revealed one at a time with animation
  starRevealTimer: 0,

  // Cached run data (captured when screen enters)
  runData: {
    stars:         0,
    ringsCollected: 0,
    ringsTotal:    0,
    timeTaken:     0,     // seconds
    isNewRecord:   false,
  },

  // Button
  continueBtn: { x: 0, y: 0, width: 220, height: 52 },

  // ---------------------------------------------------------------------------
  // ENTER
  // ---------------------------------------------------------------------------
  enter() {
    this.alpha          = 0;
    this.timer          = 0;
    this.starsRevealed  = 0;
    this.starRevealTimer = 0;

    const state  = window.Game.state;
    const save   = window.Game.save;
    const C      = window.Game.constants;

    // Capture run stats
    const stars          = state._calculateStars();
    const ringsCollected = state.ringsCollected;
    const ringsTotal     = state.ringsTotal;
    const timeTaken      = Math.round(C.LEVEL_TIME_SECONDS - state.timerSeconds);
    const prevBest       = save ? save.data.bestTime[state.currentLevel] : null;
    const isNewRecord    = prevBest === null || timeTaken < prevBest;

    this.runData = { stars, ringsCollected, ringsTotal, timeTaken, isNewRecord };

    // Position continue button
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;
    this.continueBtn.x = (cw - this.continueBtn.width) / 2;
    this.continueBtn.y = ch - 100;

    console.log(`levelComplete.js: ${stars}★ — ${ringsCollected}/${ringsTotal} rings — ${timeTaken}s`);
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    this.timer += deltaTime * 1000;
    this.alpha  = Math.min(1, this.timer / 500);

    // Reveal stars one at a time, 400ms apart, starting at 800ms
    if (this.timer > 800) {
      this.starRevealTimer += deltaTime * 1000;
      if (this.starRevealTimer > 400 && this.starsRevealed < this.runData.stars) {
        this.starsRevealed++;
        this.starRevealTimer = 0;
        // Play a small chime for each star reveal
        if (window.Game.audio && this.starsRevealed <= this.runData.stars) {
          window.Game.audio.play('collect');
        }
      }
    }
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;
    const rd = this.runData;

    ctx.save();
    ctx.globalAlpha = this.alpha;

    // Background
    ctx.fillStyle = '#07080f';
    ctx.fillRect(0, 0, cw, ch);

    // Star field
    ctx.fillStyle = 'rgba(255,255,255,0.2)';
    for (let i = 0; i < 50; i++) {
      ctx.beginPath();
      ctx.arc(((i * 199 + 43) % cw), ((i * 127 + 31) % ch), 0.7, 0, Math.PI * 2);
      ctx.fill();
    }

    // Panel
    const panelW = 460;
    const panelH = 360;
    const panelX = (cw - panelW) / 2;
    const panelY = (ch - panelH) / 2 - 30;

    ctx.fillStyle   = '#0a111e';
    ctx.strokeStyle = 'rgba(74,240,192,0.25)';
    ctx.lineWidth   = 1.5;
    ctx.beginPath();
    ctx.roundRect(panelX, panelY, panelW, panelH, 16);
    ctx.fill();
    ctx.stroke();

    // Level complete title
    ctx.shadowColor  = 'rgba(74,240,192,0.5)';
    ctx.shadowBlur   = 20;
    ctx.fillStyle    = '#4af0c0';
    ctx.font         = 'bold 26px "Pacifico", cursive';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Level Complete!', cw / 2, panelY + 44);
    ctx.shadowBlur   = 0;

    // Level name
    ctx.fillStyle    = 'rgba(255,255,255,0.5)';
    ctx.font         = '14px "Roboto", sans-serif';
    ctx.fillText('The Shipwreck', cw / 2, panelY + 72);

    // --- Stars ---
    this._drawStars(ctx, cw, panelY + 120);

    // --- Stats ---
    const statsY = panelY + 200;

    // Rings
    const ringPct  = rd.ringsTotal > 0 ? Math.round((rd.ringsCollected / rd.ringsTotal) * 100) : 0;
    const ringColor = rd.ringsCollected >= rd.ringsTotal ? '#ffd700' : 'rgba(255,255,255,0.7)';
    this._drawStat(ctx, panelX + 60, statsY, '💍 Rings', `${rd.ringsCollected} / ${rd.ringsTotal}  (${ringPct}%)`, ringColor);

    // Time
    const mins    = Math.floor(rd.timeTaken / 60);
    const secs    = rd.timeTaken % 60;
    const timeStr = `${mins}:${secs.toString().padStart(2, '0')}`;
    const timeColor = rd.isNewRecord ? '#4af0c0' : 'rgba(255,255,255,0.7)';
    this._drawStat(ctx, panelX + 60, statsY + 44, '⏱ Time', timeStr + (rd.isNewRecord ? '  ★ Best!' : ''), timeColor);

    // Deaths
    const deathCount = window.Game.state.deaths;
    const deathColor = deathCount === 0 ? '#44ff88' : 'rgba(255,255,255,0.7)';
    this._drawStat(ctx, panelX + 60, statsY + 88, '💀 Deaths', deathCount === 0 ? 'Perfect Run!' : `${deathCount}`, deathColor);

    // --- Continue button ---
    this._drawContinueButton(ctx);

    ctx.globalAlpha = 1;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawStars (private)
  // ---------------------------------------------------------------------------
  _drawStars(ctx, cw, centerY) {
    const starSize = 44;
    const gap      = 12;
    const totalW   = 3 * starSize + 2 * gap;
    const startX   = cw / 2 - totalW / 2;

    for (let i = 0; i < 3; i++) {
      const revealed = i < this.starsRevealed;
      const scale    = revealed
        ? 1 + 0.3 * Math.exp(-((this.starsRevealed - 1 - i) + this.starRevealTimer / 400))
        : 1;

      const sx = startX + i * (starSize + gap) + starSize / 2;
      const sy = centerY;

      ctx.save();
      ctx.translate(sx, sy);
      ctx.scale(scale, scale);
      ctx.translate(-sx, -sy);

      // Draw 5-point star
      ctx.beginPath();
      const outerR = starSize / 2;
      const innerR = outerR * 0.42;
      for (let p = 0; p < 10; p++) {
        const angle = (p * Math.PI / 5) - Math.PI / 2;
        const r     = (p % 2 === 0) ? outerR : innerR;
        if (p === 0) ctx.moveTo(sx + r * Math.cos(angle), sy + r * Math.sin(angle));
        else         ctx.lineTo(sx + r * Math.cos(angle), sy + r * Math.sin(angle));
      }
      ctx.closePath();

      if (revealed) {
        ctx.fillStyle   = '#ffd700';
        ctx.shadowColor = '#ffd700';
        ctx.shadowBlur  = 16;
      } else {
        ctx.fillStyle = 'rgba(255,255,255,0.08)';
      }

      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.restore();
    }
  },

  // ---------------------------------------------------------------------------
  // _drawStat (private)
  // ---------------------------------------------------------------------------
  _drawStat(ctx, x, y, label, value, valueColor) {
    ctx.fillStyle    = 'rgba(255,255,255,0.35)';
    ctx.font         = '12px "Roboto", sans-serif';
    ctx.textAlign    = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, x, y);

    ctx.fillStyle    = valueColor || '#ffffff';
    ctx.font         = 'bold 15px "Roboto", sans-serif';
    ctx.textAlign    = 'right';
    const C = window.Game.constants;
    ctx.fillText(value, x + (C.CANVAS_WIDTH - 120) / 2, y);
  },

  // ---------------------------------------------------------------------------
  // _drawContinueButton (private)
  // ---------------------------------------------------------------------------
  _drawContinueButton(ctx) {
    const btn  = this.continueBtn;
    const time = Date.now() / 1000;
    const pulse = 0.85 + 0.15 * Math.sin(time * 2);

    ctx.save();
    ctx.fillStyle   = `rgba(74,240,192,${0.18 * pulse})`;
    ctx.strokeStyle = `rgba(74,240,192,${0.8 * pulse})`;
    ctx.lineWidth   = 2;
    ctx.shadowColor = '#4af0c0';
    ctx.shadowBlur  = 12 * pulse;
    ctx.beginPath();
    ctx.roundRect(btn.x, btn.y, btn.width, btn.height, 10);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur  = 0;

    ctx.fillStyle    = '#ffffff';
    ctx.font         = 'bold 18px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Continue', btn.x + btn.width / 2, btn.y + btn.height / 2);
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // HANDLE TAP
  // ---------------------------------------------------------------------------
  handleTap(screenX, screenY) {
    // Only allow continue after stars are revealed (min 1.2s)
    if (this.timer < 1200) return;

    const btn = this.continueBtn;
    if (screenX >= btn.x && screenX <= btn.x + btn.width &&
        screenY >= btn.y && screenY <= btn.y + btn.height) {
      // Level 1 is the only level — go to credits
      window.Game.state.transition('CREDITS');
    }
  },

};
