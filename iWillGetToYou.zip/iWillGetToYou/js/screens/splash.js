// =============================================================================
// splash.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// The first thing the player sees. Displays the J&I logo and game title,
// fades in, holds, then fades out and advances to GENDER_SELECT.
//
// SEQUENCE:
//   0ms      → begin fade in (alpha 0 → 1)
//   400ms    → fully visible, hold
//   2400ms   → begin fade out (alpha 1 → 0)
//   2800ms   → transition to GENDER_SELECT
//
// The splash also handles the very first iOS audio unlock attempt —
// any tap during the splash will unlock audio early.
// =============================================================================

window.Game = window.Game || {};

window.Game.screens = window.Game.screens || {};

window.Game.screens.splash = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  timer:    0,       // ms elapsed since splash started
  alpha:    0,       // current screen opacity 0-1
  started:  false,

  // Timing constants (ms)
  FADE_IN_MS:  400,
  HOLD_MS:     2000,
  FADE_OUT_MS: 400,

  // ---------------------------------------------------------------------------
  // ENTER
  // Called by game.js when state transitions TO 'SPLASH'.
  // Resets timer and prepares the screen.
  // ---------------------------------------------------------------------------
  enter() {
    this.timer   = 0;
    this.alpha   = 0;
    this.started = true;
    console.log('splash.js: Entered.');
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // Called every frame while state === 'SPLASH'.
  // deltaTime in seconds.
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    if (!this.started) return;

    this.timer += deltaTime * 1000;   // convert to ms

    const total = this.FADE_IN_MS + this.HOLD_MS + this.FADE_OUT_MS;

    if (this.timer < this.FADE_IN_MS) {
      // Fading in
      this.alpha = this.timer / this.FADE_IN_MS;

    } else if (this.timer < this.FADE_IN_MS + this.HOLD_MS) {
      // Holding at full opacity
      this.alpha = 1;

    } else if (this.timer < total) {
      // Fading out
      const elapsed = this.timer - this.FADE_IN_MS - this.HOLD_MS;
      this.alpha = 1 - (elapsed / this.FADE_OUT_MS);

    } else {
      // Complete — advance to gender select
      this.alpha = 0;
      window.Game.state.transition('GENDER_SELECT');
    }
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Renders the splash screen each frame.
  // ctx: canvas 2D context (no camera transform)
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    ctx.save();

    // --- Background: deep space black ---
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, cw, ch);

    // --- Subtle star field ---
    ctx.globalAlpha = this.alpha * 0.4;
    ctx.fillStyle   = '#ffffff';
    for (let i = 0; i < 80; i++) {
      const sx = ((i * 173 + 7) % cw);
      const sy = ((i * 97  + 13) % (ch - 40));
      const sr = (i % 4 === 0) ? 1.2 : 0.6;
      ctx.beginPath();
      ctx.arc(sx, sy, sr, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.globalAlpha = this.alpha;

    // --- Studio name: "J&I Studios" — small, top ---
    ctx.fillStyle    = 'rgba(255,255,255,0.45)';
    ctx.font         = '13px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('J & I  S T U D I O S', cw / 2, ch / 2 - 100);

    // --- Logo: "J&I" in hand-lettered Pacifico font ---
    ctx.shadowColor = 'rgba(200, 160, 255, 0.6)';
    ctx.shadowBlur  = 40;
    ctx.fillStyle   = '#ffffff';
    ctx.font        = `bold 96px "Pacifico", cursive`;
    ctx.textAlign   = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('J&I', cw / 2, ch / 2 - 10);

    // --- Game title: "iWillGetToYou" ---
    ctx.shadowBlur   = 12;
    ctx.shadowColor  = 'rgba(180, 120, 255, 0.5)';
    ctx.fillStyle    = 'rgba(220, 200, 255, 0.9)';
    ctx.font         = `18px "Pacifico", cursive`;
    ctx.fillText('iWillGetToYou', cw / 2, ch / 2 + 66);

    // --- Dedication line ---
    ctx.shadowBlur   = 0;
    ctx.fillStyle    = 'rgba(255,255,255,0.28)';
    ctx.font         = 'italic 13px "Roboto", sans-serif';
    ctx.fillText('Made with love, for J & I  —  We found us...', cw / 2, ch / 2 + 106);

    // --- "Tap to continue" hint (appears during hold phase) ---
    if (this.timer > this.FADE_IN_MS + 400) {
      const hintAlpha = Math.min(1, (this.timer - this.FADE_IN_MS - 400) / 300);
      const pulse     = 0.5 + 0.5 * Math.sin(Date.now() / 600);
      ctx.globalAlpha = this.alpha * hintAlpha * pulse;
      ctx.fillStyle   = 'rgba(255,255,255,0.5)';
      ctx.font        = '13px "Roboto", sans-serif';
      ctx.fillText('tap anywhere to continue', cw / 2, ch - 40);
    }

    ctx.globalAlpha = 1;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // HANDLE TAP
  // If player taps during splash, skip immediately to gender select.
  // Also serves as iOS audio unlock trigger.
  // ---------------------------------------------------------------------------
  handleTap() {
    if (this.timer > this.FADE_IN_MS) {
      // Only allow skip after fade-in is complete
      window.Game.state.transition('GENDER_SELECT');
    }
  },

};
