// =============================================================================
// genderSelect.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// The gender / path selection screen. Player chooses between:
//   MALE PATH   — Astronaut escaping a dying spaceship
//   FEMALE PATH — Explorer discovering an ancient underground city
//
// Currently only the male path is built. The female card shows
// "Coming Soon" so the screen structure is already in place for future build.
//
// After selection:
//   1. Save gender choice to localStorage (save.js)
//   2. Set Game.state.selectedGender
//   3. Transition to LOADING (preloader loads assets for that path)
//   4. After loading, transition to MAIN_MENU
// =============================================================================

window.Game = window.Game || {};
window.Game.screens = window.Game.screens || {};

window.Game.screens.genderSelect = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  alpha:       0,         // screen fade-in alpha
  timer:       0,         // ms since enter
  hoveredCard: null,      // 'male' | 'female' | null (for hover highlight)

  // Card layout — calculated in enter() based on canvas size
  cards: {
    male: {
      x: 0, y: 0, width: 0, height: 0,
      label:       'His Journey',
      sublabel:    'Escape the dying ship',
      description: 'Follow the rings. Reach the hangar.',
      available:   true,
      color:       '#1a3a5c',
      accentColor: '#4af0c0',
      iconColor:   '#88ccff',
    },
    female: {
      x: 0, y: 0, width: 0, height: 0,
      label:       'Her Journey',
      sublabel:    'Discover the ancient city',
      description: 'Coming Soon',
      available:   false,
      color:       '#3a1a2a',
      accentColor: '#f0a0c0',
      iconColor:   '#ffaacc',
    },
  },

  // ---------------------------------------------------------------------------
  // ENTER
  // Called when state transitions TO 'GENDER_SELECT'.
  // ---------------------------------------------------------------------------
  enter() {
    this.alpha = 0;
    this.timer = 0;

    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    // Card dimensions — side by side, centered vertically
    const cardW = 360;
    const cardH = 340;
    const gap   = 60;
    const totalW = cardW * 2 + gap;
    const startX = (cw - totalW) / 2;
    const cardY  = (ch - cardH) / 2 + 20;

    this.cards.male.x      = startX;
    this.cards.male.y      = cardY;
    this.cards.male.width  = cardW;
    this.cards.male.height = cardH;

    this.cards.female.x      = startX + cardW + gap;
    this.cards.female.y      = cardY;
    this.cards.female.width  = cardW;
    this.cards.female.height = cardH;

    this.hoveredCard = null;

    // Pre-select the last used gender if saved
    const saved = window.Game.save ? window.Game.save.data.selectedGender : null;
    if (saved) this.hoveredCard = saved;

    console.log('genderSelect.js: Entered.');
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    this.timer += deltaTime * 1000;
    this.alpha  = Math.min(1, this.timer / 400);   // 400ms fade in
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    ctx.save();
    ctx.globalAlpha = this.alpha;

    // --- Background ---
    ctx.fillStyle = '#07080f';
    ctx.fillRect(0, 0, cw, ch);

    // Subtle star field
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    for (let i = 0; i < 60; i++) {
      const sx = ((i * 211 + 31) % cw);
      const sy = ((i * 137 + 17) % ch);
      ctx.beginPath();
      ctx.arc(sx, sy, 0.8, 0, Math.PI * 2);
      ctx.fill();
    }

    // --- Title ---
    ctx.fillStyle    = 'rgba(255,255,255,0.85)';
    ctx.font         = `bold 22px "Pacifico", cursive`;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Choose your journey', cw / 2, 80);

    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.font      = '14px "Roboto", sans-serif';
    ctx.fillText('Two paths. One destination.', cw / 2, 112);

    // --- Draw each card ---
    ['male', 'female'].forEach(gender => {
      this._drawCard(ctx, this.cards[gender], gender);
    });

    // --- Bottom hint ---
    ctx.fillStyle    = 'rgba(255,255,255,0.25)';
    ctx.font         = '12px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'bottom';
    ctx.fillText('Tap a card to begin', cw / 2, ch - 24);

    ctx.globalAlpha = 1;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawCard (private)
  // Renders a single path selection card.
  // ---------------------------------------------------------------------------
  _drawCard(ctx, card, gender) {
    const isHovered   = this.hoveredCard === gender;
    const isAvailable = card.available;
    const time        = Date.now() / 1000;

    ctx.save();

    // --- Card background ---
    ctx.fillStyle = card.color;
    ctx.beginPath();
    ctx.roundRect(card.x, card.y, card.width, card.height, 16);
    ctx.fill();

    // --- Hover glow border ---
    if (isHovered && isAvailable) {
      ctx.shadowColor = card.accentColor;
      ctx.shadowBlur  = 24 + 8 * Math.sin(time * 2);
      ctx.strokeStyle = card.accentColor;
      ctx.lineWidth   = 3;
      ctx.beginPath();
      ctx.roundRect(card.x + 1, card.y + 1, card.width - 2, card.height - 2, 16);
      ctx.stroke();
      ctx.shadowBlur = 0;
    } else {
      ctx.strokeStyle = 'rgba(255,255,255,0.1)';
      ctx.lineWidth   = 1.5;
      ctx.beginPath();
      ctx.roundRect(card.x + 1, card.y + 1, card.width - 2, card.height - 2, 16);
      ctx.stroke();
    }

    // --- Character silhouette illustration ---
    this._drawCharacterIcon(ctx, card, gender, isAvailable);

    // --- Card text content ---
    const textX = card.x + card.width / 2;

    // Label
    ctx.fillStyle    = isAvailable ? '#ffffff' : 'rgba(255,255,255,0.3)';
    ctx.font         = `bold 22px "Pacifico", cursive`;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(card.label, textX, card.y + card.height - 120);

    // Sublabel
    ctx.fillStyle = isAvailable
      ? card.accentColor
      : 'rgba(255,255,255,0.2)';
    ctx.font      = '13px "Roboto", sans-serif';
    ctx.fillText(card.sublabel, textX, card.y + card.height - 92);

    // Description / coming soon
    ctx.fillStyle = isAvailable
      ? 'rgba(255,255,255,0.55)'
      : 'rgba(255,255,255,0.2)';
    ctx.font      = 'italic 12px "Roboto", sans-serif';
    ctx.fillText(card.description, textX, card.y + card.height - 68);

    // --- Play button ---
    if (isAvailable) {
      const btnW = 140;
      const btnH = 36;
      const btnX = card.x + (card.width - btnW) / 2;
      const btnY = card.y + card.height - 48;

      ctx.fillStyle = isHovered ? card.accentColor : 'rgba(255,255,255,0.12)';
      ctx.beginPath();
      ctx.roundRect(btnX, btnY, btnW, btnH, 8);
      ctx.fill();

      ctx.fillStyle    = isHovered ? '#000' : 'rgba(255,255,255,0.7)';
      ctx.font         = 'bold 14px "Roboto", sans-serif';
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('Play', btnX + btnW / 2, btnY + btnH / 2);
    } else {
      // Coming soon badge
      const badgeX = card.x + card.width / 2 - 50;
      const badgeY = card.y + card.height - 48;

      ctx.fillStyle = 'rgba(255,255,255,0.06)';
      ctx.beginPath();
      ctx.roundRect(badgeX, badgeY, 100, 34, 8);
      ctx.fill();

      ctx.fillStyle    = 'rgba(255,255,255,0.2)';
      ctx.font         = '12px "Roboto", sans-serif';
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('Coming Soon', badgeX + 50, badgeY + 17);
    }

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawCharacterIcon (private)
  // Draws a simple illustrated character silhouette in each card.
  // These are canvas-drawn — no external assets needed.
  // ---------------------------------------------------------------------------
  _drawCharacterIcon(ctx, card, gender, isAvailable) {
    const cx     = card.x + card.width  / 2;
    const cy     = card.y + 130;
    const alpha  = isAvailable ? 1 : 0.25;

    ctx.save();
    ctx.globalAlpha *= alpha;

    if (gender === 'male') {
      // Astronaut / spacesuit silhouette
      const helmetR = 30;
      const bodyW   = 48;
      const bodyH   = 52;

      // Suit glow
      ctx.shadowColor = '#4af0c0';
      ctx.shadowBlur  = 20;

      // Helmet
      ctx.fillStyle = '#a0c8e8';
      ctx.beginPath();
      ctx.arc(cx, cy - 38, helmetR, 0, Math.PI * 2);
      ctx.fill();

      // Visor (dark reflective oval)
      ctx.fillStyle = '#0a1a2a';
      ctx.beginPath();
      ctx.ellipse(cx, cy - 38, helmetR * 0.65, helmetR * 0.5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Visor reflection
      ctx.fillStyle = 'rgba(180,220,255,0.3)';
      ctx.beginPath();
      ctx.ellipse(cx - 8, cy - 44, 8, 5, -0.4, 0, Math.PI * 2);
      ctx.fill();

      // Body suit
      ctx.fillStyle = '#7aaabb';
      ctx.beginPath();
      ctx.roundRect(cx - bodyW / 2, cy - 8, bodyW, bodyH, 8);
      ctx.fill();

      // Chest panel
      ctx.fillStyle = '#4af0c0';
      ctx.fillRect(cx - 10, cy + 4, 20, 14);

      // Arms
      ctx.fillStyle = '#7aaabb';
      ctx.fillRect(cx - bodyW / 2 - 14, cy - 6, 14, 36);
      ctx.fillRect(cx + bodyW / 2,      cy - 6, 14, 36);

      // Legs
      ctx.fillRect(cx - bodyW / 2 + 4,  cy + bodyH - 10, 18, 28);
      ctx.fillRect(cx + bodyW / 2 - 22, cy + bodyH - 10, 18, 28);

      // Boots
      ctx.fillStyle = '#3a5566';
      ctx.beginPath();
      ctx.roundRect(cx - bodyW / 2 + 2,  cy + bodyH + 16, 22, 10, 4);
      ctx.fill();
      ctx.beginPath();
      ctx.roundRect(cx + bodyW / 2 - 24, cy + bodyH + 16, 22, 10, 4);
      ctx.fill();

      ctx.shadowBlur = 0;

    } else {
      // Explorer / archaeologist silhouette
      ctx.shadowColor = '#f0a0c0';
      ctx.shadowBlur  = 16;

      // Hair (bun)
      ctx.fillStyle = '#8B4513';
      ctx.beginPath();
      ctx.arc(cx, cy - 66, 14, 0, Math.PI * 2);
      ctx.fill();

      // Head
      ctx.fillStyle = '#f0c090';
      ctx.beginPath();
      ctx.ellipse(cx, cy - 46, 18, 22, 0, 0, Math.PI * 2);
      ctx.fill();

      // Explorer hat
      ctx.fillStyle = '#8B6914';
      ctx.beginPath();
      ctx.ellipse(cx, cy - 64, 26, 6, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillRect(cx - 14, cy - 78, 28, 18);
      ctx.beginPath();
      ctx.ellipse(cx, cy - 78, 16, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Body / jacket
      ctx.fillStyle = '#c8944a';
      ctx.beginPath();
      ctx.roundRect(cx - 20, cy - 24, 40, 50, 6);
      ctx.fill();

      // Backpack
      ctx.fillStyle = '#8B5e2a';
      ctx.beginPath();
      ctx.roundRect(cx + 16, cy - 20, 18, 36, 4);
      ctx.fill();

      // Arms
      ctx.fillStyle = '#c8944a';
      ctx.fillRect(cx - 34, cy - 22, 14, 34);
      ctx.fillRect(cx + 20, cy - 22, 14, 34);

      // Legs / pants
      ctx.fillStyle = '#5a7a4a';
      ctx.fillRect(cx - 18, cy + 24, 15, 34);
      ctx.fillRect(cx + 3,  cy + 24, 15, 34);

      // Boots
      ctx.fillStyle = '#3a2a1a';
      ctx.beginPath();
      ctx.roundRect(cx - 20, cy + 56, 18, 10, 3);
      ctx.fill();
      ctx.beginPath();
      ctx.roundRect(cx + 2,  cy + 56, 18, 10, 3);
      ctx.fill();

      ctx.shadowBlur = 0;
    }

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // HANDLE INPUT
  // Called by game.js when a tap/click occurs during GENDER_SELECT.
  // screenX, screenY: tap coordinates in canvas pixels.
  // ---------------------------------------------------------------------------
  handleTap(screenX, screenY) {
    ['male', 'female'].forEach(gender => {
      const card = this.cards[gender];
      if (!card.available) return;

      if (
        screenX >= card.x && screenX <= card.x + card.width &&
        screenY >= card.y && screenY <= card.y + card.height
      ) {
        this._selectGender(gender);
      }
    });
  },

  // ---------------------------------------------------------------------------
  // HANDLE MOVE
  // Called by game.js on mouse/touch move — updates hover state.
  // ---------------------------------------------------------------------------
  handleMove(screenX, screenY) {
    this.hoveredCard = null;
    ['male', 'female'].forEach(gender => {
      const card = this.cards[gender];
      if (!card.available) return;
      if (
        screenX >= card.x && screenX <= card.x + card.width &&
        screenY >= card.y && screenY <= card.y + card.height
      ) {
        this.hoveredCard = gender;
      }
    });
  },

  // ---------------------------------------------------------------------------
  // _selectGender (private)
  // Finalizes the gender selection and transitions to loading.
  // ---------------------------------------------------------------------------
  _selectGender(gender) {
    console.log(`genderSelect.js: Selected "${gender}".`);

    // Save to localStorage
    if (window.Game.save) {
      window.Game.save.saveGender(gender);
    }

    // Set session state
    window.Game.state.selectedGender = gender;

    // Transition to loading screen
    // preloader.js will load assets for this gender path
    window.Game.state.transition('LOADING');
  },

};
