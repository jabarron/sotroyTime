// =============================================================================
// cutscene.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Handles all animated canvas cutscenes — no video files needed.
// Two cutscenes exist for the male path:
//
//   INTRO — "The Shipwreck" opening sequence
//     Scene 1: Stars. A massive ship drifts into frame slowly.
//     Scene 2: A black distortion appears — the black hole. Ship tilts.
//     Scene 3: Inside the ship — lights flicker, alarms flash red.
//     Scene 4: Text: "Escape before the ship is consumed."
//     Scene 5: Text: "Follow the rings. Reach the hangar."
//     → Transitions to GAMEPLAY
//
//   OUTRO — "Escaped" ending sequence
//     Scene 1: Small ship bursts out of the hangar into open space.
//     Scene 2: The large ship collapses into the black hole.
//     Scene 3: Small ship turns toward a distant blue dot — Earth.
//     Scene 4: Text: "iWillGetToYou"
//     → Transitions to LEVEL_COMPLETE
//
// Player can tap to skip any cutscene.
// =============================================================================

window.Game = window.Game || {};
window.Game.screens = window.Game.screens || {};

window.Game.screens.cutscene = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  type:        'intro',   // 'intro' | 'outro'
  sceneIndex:  0,         // which scene is playing (0-based)
  sceneTimer:  0,         // ms elapsed in current scene
  totalTimer:  0,         // ms elapsed in entire cutscene
  alpha:       1,         // for fade in/out transitions between scenes
  skipped:     false,

  // Scene durations in ms
  INTRO_SCENES: [
    { duration: 2800 },   // Ship drifting in
    { duration: 3200 },   // Black hole appears, ship tilts
    { duration: 2600 },   // Interior alarms
    { duration: 2400 },   // Text: Escape warning
    { duration: 2000 },   // Text: Follow the rings
  ],

  OUTRO_SCENES: [
    { duration: 2600 },   // Small ship bursts out
    { duration: 3000 },   // Large ship collapses
    { duration: 2800 },   // Turn toward Earth
    { duration: 3200 },   // iWillGetToYou text
  ],

  // ---------------------------------------------------------------------------
  // ENTER
  // Called when state transitions to CUTSCENE_INTRO or CUTSCENE_OUTRO.
  // type: 'intro' | 'outro'
  // ---------------------------------------------------------------------------
  enter(type) {
    this.type       = type || 'intro';
    this.sceneIndex = 0;
    this.sceneTimer = 0;
    this.totalTimer = 0;
    this.alpha      = 0;   // start black, fade in
    this.skipped    = false;

    console.log(`cutscene.js: Starting ${this.type} cutscene.`);
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // deltaTime in seconds.
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    if (this.skipped) return;

    const ms     = deltaTime * 1000;
    const scenes = this.type === 'intro' ? this.INTRO_SCENES : this.OUTRO_SCENES;

    this.sceneTimer += ms;
    this.totalTimer += ms;

    // Fade alpha in/out within each scene
    const sceneDuration = scenes[this.sceneIndex] ? scenes[this.sceneIndex].duration : 2000;
    const fadeMs        = 400;

    if (this.sceneTimer < fadeMs) {
      this.alpha = this.sceneTimer / fadeMs;
    } else if (this.sceneTimer > sceneDuration - fadeMs) {
      this.alpha = (sceneDuration - this.sceneTimer) / fadeMs;
      this.alpha = Math.max(0, this.alpha);
    } else {
      this.alpha = 1;
    }

    // Advance to next scene
    if (this.sceneTimer >= sceneDuration) {
      this.sceneIndex++;
      this.sceneTimer = 0;

      // All scenes complete — transition out
      if (this.sceneIndex >= scenes.length) {
        this._complete();
      }
    }
  },

  // ---------------------------------------------------------------------------
  // _complete (private)
  // Called when all scenes have played OR player tapped to skip.
  // ---------------------------------------------------------------------------
  _complete() {
    this.skipped = true;

    if (this.type === 'intro') {
      // Load the level then start gameplay
      const gender = window.Game.state.selectedGender || 'male';
      const level  = window.Game.state.currentLevel   || 1;

      if (window.Game.level) {
        window.Game.level.load(gender, level);
      }
      if (window.Game.hud) {
        window.Game.hud.reset();
      }

      window.Game.state.transition('GAMEPLAY');

    } else {
      // Outro complete — go to level complete screen
      window.Game.state.transition('LEVEL_COMPLETE');
    }
  },

  // ---------------------------------------------------------------------------
  // HANDLE TAP — skip cutscene
  // ---------------------------------------------------------------------------
  handleTap() {
    if (!this.skipped) {
      this._complete();
    }
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Routes to the correct scene renderer based on type and sceneIndex.
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    // Black base
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, cw, ch);

    if (this.type === 'intro') {
      this._drawIntroScene(ctx, cw, ch);
    } else {
      this._drawOutroScene(ctx, cw, ch);
    }

    // Skip hint
    ctx.save();
    ctx.globalAlpha  = 0.35;
    ctx.fillStyle    = '#ffffff';
    ctx.font         = '12px "Roboto", sans-serif';
    ctx.textAlign    = 'right';
    ctx.textBaseline = 'bottom';
    ctx.fillText('Tap to skip', cw - 20, ch - 16);
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawIntroScene (private)
  // Draws the correct intro scene based on sceneIndex.
  // ---------------------------------------------------------------------------
  _drawIntroScene(ctx, cw, ch) {
    const t  = this.sceneTimer / 1000;   // seconds in current scene
    const a  = this.alpha;

    ctx.save();
    ctx.globalAlpha = a;

    switch (this.sceneIndex) {

      case 0: {
        // --- Scene 1: Stars. Massive ship drifts slowly into frame ---
        this._drawStarField(ctx, cw, ch, 1.0);

        // Ship — large dark rectangle representing a capital ship
        const shipProgress = Math.min(1, t / 2.5);
        const shipX  = cw * 0.5 - 300 + (1 - shipProgress) * cw * 0.4;
        const shipY  = ch * 0.35;
        const shipW  = 600;
        const shipH  = 140;

        this._drawSpaceship(ctx, shipX, shipY, shipW, shipH, 0, '#ccddee');

        // Subtle engine glow at rear
        const glow = ctx.createRadialGradient(shipX, shipY + shipH / 2, 0, shipX, shipY + shipH / 2, 60);
        glow.addColorStop(0,   'rgba(100,180,255,0.4)');
        glow.addColorStop(1,   'rgba(0,0,0,0)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(shipX, shipY + shipH / 2, 60, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 1: {
        // --- Scene 2: Black hole appears, ship begins to tilt ---
        this._drawStarField(ctx, cw, ch, 0.8);

        // Black hole — grows from center-right
        const bhProgress = Math.min(1, t / 2.5);
        const bhR = 20 + bhProgress * 100;
        const bhX = cw * 0.78;
        const bhY = ch * 0.3;

        // Gravitational distortion halo
        const bhGrad = ctx.createRadialGradient(bhX, bhY, 0, bhX, bhY, bhR * 2.5);
        bhGrad.addColorStop(0,   'rgba(0,0,0,1)');
        bhGrad.addColorStop(0.4, 'rgba(20,0,40,0.9)');
        bhGrad.addColorStop(0.8, 'rgba(100,30,180,0.4)');
        bhGrad.addColorStop(1,   'rgba(0,0,0,0)');
        ctx.fillStyle = bhGrad;
        ctx.beginPath();
        ctx.arc(bhX, bhY, bhR * 2.5, 0, Math.PI * 2);
        ctx.fill();

        // Accretion ring
        ctx.strokeStyle = `rgba(180,80,255,${bhProgress * 0.7})`;
        ctx.lineWidth   = 4;
        ctx.shadowColor = '#aa44ff';
        ctx.shadowBlur  = 20;
        ctx.beginPath();
        ctx.ellipse(bhX, bhY, bhR * 1.8, bhR * 0.45, -0.3, 0, Math.PI * 2);
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Ship — now tilting toward the black hole
        const tiltAngle = bhProgress * 0.25;
        const shipX = cw * 0.38;
        const shipY = ch * 0.4;
        ctx.save();
        ctx.translate(shipX + 300, shipY + 70);
        ctx.rotate(tiltAngle);
        ctx.translate(-(shipX + 300), -(shipY + 70));
        this._drawSpaceship(ctx, shipX, shipY, 600, 140, 0, '#aabbcc');
        ctx.restore();

        // Debris particles being pulled toward BH
        for (let i = 0; i < 8; i++) {
          const angle = (i / 8) * Math.PI * 2 + t * 0.5;
          const dist  = 80 + bhProgress * 60;
          const dx    = bhX + Math.cos(angle) * dist;
          const dy    = bhY + Math.sin(angle) * dist * 0.3;
          ctx.fillStyle = 'rgba(180,200,220,0.6)';
          ctx.beginPath();
          ctx.arc(dx, dy, 2 + Math.random() * 2, 0, Math.PI * 2);
          ctx.fill();
        }
        break;
      }

      case 2: {
        // --- Scene 3: Interior — alarms, flickering lights ---
        // Dark corridor background
        ctx.fillStyle = '#0a0f18';
        ctx.fillRect(0, 0, cw, ch);

        // Floor and ceiling panels
        ctx.fillStyle = '#1a2030';
        ctx.fillRect(0, 0, cw, 80);
        ctx.fillRect(0, ch - 100, cw, 100);

        // Wall panel seams
        ctx.strokeStyle = '#0e1520';
        ctx.lineWidth   = 2;
        for (let px = 0; px < cw; px += 120) {
          ctx.beginPath();
          ctx.moveTo(px, 80);
          ctx.lineTo(px, ch - 100);
          ctx.stroke();
        }

        // Flickering alarm lights
        const alarmFreq = 4 + t * 2;
        const alarmOn   = Math.sin(t * alarmFreq) > 0;

        if (alarmOn) {
          ctx.fillStyle = 'rgba(255,0,0,0.06)';
          ctx.fillRect(0, 0, cw, ch);

          for (let i = 0; i < 5; i++) {
            const lx = (cw / 5) * (i + 0.5);
            const ly = 30;
            const lr = 12 + 5 * Math.sin(t * 8 + i);
            const ag = ctx.createRadialGradient(lx, ly, 0, lx, ly, lr * 3);
            ag.addColorStop(0, 'rgba(255,50,0,0.5)');
            ag.addColorStop(1, 'rgba(255,0,0,0)');
            ctx.fillStyle = ag;
            ctx.beginPath();
            ctx.arc(lx, ly, lr * 3, 0, Math.PI * 2);
            ctx.fill();
          }
        }

        // Sparks flying from panel on right
        for (let i = 0; i < 6; i++) {
          const sparkPhase = (t * 3 + i * 0.7) % 1;
          const sx = cw - 120 + Math.sin(sparkPhase * 10) * 20;
          const sy = ch * 0.4 + sparkPhase * 100;
          ctx.fillStyle = `rgba(255,${180 + Math.random() * 75},0,${1 - sparkPhase})`;
          ctx.beginPath();
          ctx.arc(sx, sy, 2 + Math.random() * 2, 0, Math.PI * 2);
          ctx.fill();
        }

        // Crack in the hull — visible starfield through it
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(cw * 0.6, 80);
        ctx.lineTo(cw * 0.65, 200);
        ctx.lineTo(cw * 0.63, 320);
        ctx.lineWidth   = 6;
        ctx.strokeStyle = '#000000';
        ctx.stroke();
        ctx.lineWidth   = 3;
        ctx.strokeStyle = 'rgba(150,200,255,0.4)';
        ctx.stroke();
        ctx.restore();
        break;
      }

      case 3: {
        // --- Scene 4: Text — "Escape before the ship is consumed." ---
        this._drawStarField(ctx, cw, ch, 0.6);
        this._drawTextScene(
          ctx, cw, ch,
          'Escape before the ship is consumed.',
          null,
          '#ffffff'
        );
        break;
      }

      case 4: {
        // --- Scene 5: Text — "Follow the rings. Reach the hangar." ---
        this._drawStarField(ctx, cw, ch, 0.6);
        this._drawTextScene(
          ctx, cw, ch,
          'Follow the rings.',
          'Reach the hangar.',
          '#4af0c0'
        );
        break;
      }
    }

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawOutroScene (private)
  // ---------------------------------------------------------------------------
  _drawOutroScene(ctx, cw, ch) {
    const t = this.sceneTimer / 1000;
    const a = this.alpha;

    ctx.save();
    ctx.globalAlpha = a;

    switch (this.sceneIndex) {

      case 0: {
        // --- Scene 1: Small ship bursts out of hangar into open space ---
        this._drawStarField(ctx, cw, ch, 1.0);

        const progress = Math.min(1, t / 2.0);
        // Small ship enters from left, accelerating
        const eased = 1 - Math.pow(1 - progress, 3);   // ease-out cubic
        const sx    = -80 + eased * (cw * 0.5);
        const sy    = ch * 0.45;

        this._drawSpaceship(ctx, sx, sy, 120, 36, 0, '#88bbdd');

        // Thruster glow
        const tGrad = ctx.createRadialGradient(sx, sy + 18, 0, sx, sy + 18, 50);
        tGrad.addColorStop(0,   'rgba(100,200,255,0.7)');
        tGrad.addColorStop(1,   'rgba(0,0,0,0)');
        ctx.fillStyle = tGrad;
        ctx.beginPath();
        ctx.arc(sx, sy + 18, 50, 0, Math.PI * 2);
        ctx.fill();

        // Exhaust trail
        for (let i = 0; i < 12; i++) {
          const tx = sx - 20 - i * 18;
          const ty = sy + 18 + (Math.sin(i * 0.9 + t * 5) * 4);
          ctx.fillStyle = `rgba(100,200,255,${(1 - i / 12) * 0.5})`;
          ctx.beginPath();
          ctx.arc(tx, ty, 5 - i * 0.3, 0, Math.PI * 2);
          ctx.fill();
        }
        break;
      }

      case 1: {
        // --- Scene 2: Large ship collapses into black hole ---
        this._drawStarField(ctx, cw, ch, 0.9);

        const progress = Math.min(1, t / 2.5);

        // Black hole — large and dominant
        const bhX = cw * 0.7;
        const bhY = ch * 0.35;
        const bhR = 80 + progress * 60;

        const bhGrad = ctx.createRadialGradient(bhX, bhY, 0, bhX, bhY, bhR * 2.5);
        bhGrad.addColorStop(0,   'rgba(0,0,0,1)');
        bhGrad.addColorStop(0.5, 'rgba(30,0,60,0.9)');
        bhGrad.addColorStop(1,   'rgba(0,0,0,0)');
        ctx.fillStyle = bhGrad;
        ctx.beginPath();
        ctx.arc(bhX, bhY, bhR * 2.5, 0, Math.PI * 2);
        ctx.fill();

        // Accretion ring — brighter now
        ctx.strokeStyle = `rgba(200,100,255,0.8)`;
        ctx.lineWidth   = 5;
        ctx.shadowColor = '#cc44ff';
        ctx.shadowBlur  = 30;
        ctx.beginPath();
        ctx.ellipse(bhX, bhY, bhR * 1.8, bhR * 0.4, -0.3, 0, Math.PI * 2);
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Large ship — shrinking and distorting as it's pulled in
        const shipScale = 1 - progress * 0.7;
        const shipX = cw * 0.3 + progress * (bhX - cw * 0.3 - 50);
        const shipY = ch * 0.4 + progress * (bhY - ch * 0.4);
        ctx.save();
        ctx.translate(shipX + 300 * shipScale, shipY + 70 * shipScale);
        ctx.rotate(progress * 1.2);
        ctx.scale(shipScale, shipScale);
        ctx.translate(-(shipX + 300 * shipScale), -(shipY + 70 * shipScale));
        this._drawSpaceship(ctx, shipX, shipY, 600, 140, 0,
          `rgba(${Math.round(180 - progress * 100)},${Math.round(200 - progress * 150)},${Math.round(220 - progress * 170)},${1 - progress * 0.5})`);
        ctx.restore();
        break;
      }

      case 2: {
        // --- Scene 3: Small ship turns toward Earth ---
        this._drawStarField(ctx, cw, ch, 1.0);

        // Earth — distant blue dot becoming a recognizable sphere
        const earthProgress = Math.min(1, t / 2.0);
        const earthR        = 8 + earthProgress * 32;
        const earthX        = cw * 0.8;
        const earthY        = ch * 0.35;

        const earthGrad = ctx.createRadialGradient(earthX - earthR * 0.3, earthY - earthR * 0.3, 0, earthX, earthY, earthR);
        earthGrad.addColorStop(0,   '#6ab4ff');
        earthGrad.addColorStop(0.4, '#2255cc');
        earthGrad.addColorStop(0.7, '#1a3a8a');
        earthGrad.addColorStop(1,   '#0a1a44');
        ctx.fillStyle = earthGrad;
        ctx.shadowColor = '#4488ff';
        ctx.shadowBlur  = 20;
        ctx.beginPath();
        ctx.arc(earthX, earthY, earthR, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur  = 0;

        // Atmosphere glow
        const atmGrad = ctx.createRadialGradient(earthX, earthY, earthR * 0.9, earthX, earthY, earthR * 1.3);
        atmGrad.addColorStop(0,   'rgba(100,180,255,0.3)');
        atmGrad.addColorStop(1,   'rgba(0,0,0,0)');
        ctx.fillStyle = atmGrad;
        ctx.beginPath();
        ctx.arc(earthX, earthY, earthR * 1.3, 0, Math.PI * 2);
        ctx.fill();

        // Small ship — now pointing toward Earth
        const sx = cw * 0.3;
        const sy = ch * 0.48;
        this._drawSpaceship(ctx, sx, sy, 120, 36, 0, '#88bbdd');
        break;
      }

      case 3: {
        // --- Scene 4: "iWillGetToYou" title card ---
        this._drawStarField(ctx, cw, ch, 0.5);

        const pulse = 0.85 + 0.15 * Math.sin(t * 1.5);

        // Main title
        ctx.shadowColor  = 'rgba(200,160,255,0.6)';
        ctx.shadowBlur   = 40 * pulse;
        ctx.fillStyle    = '#ffffff';
        ctx.font         = `bold 64px "Pacifico", cursive`;
        ctx.textAlign    = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('iWillGetToYou', cw / 2, ch / 2 - 20);

        ctx.shadowBlur   = 10;
        ctx.fillStyle    = 'rgba(180,200,255,0.7)';
        ctx.font         = '18px "Roboto", sans-serif';
        ctx.fillText('You made it.', cw / 2, ch / 2 + 44);

        // Dedication
        ctx.shadowBlur   = 0;
        ctx.fillStyle    = 'rgba(255,255,255,0.35)';
        ctx.font         = 'italic 13px "Roboto", sans-serif';
        ctx.fillText('Made with love, for J & I  —  We found us...', cw / 2, ch / 2 + 80);
        break;
      }
    }

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawStarField (private)
  // Reusable star field background.
  // ---------------------------------------------------------------------------
  _drawStarField(ctx, cw, ch, density) {
    ctx.fillStyle = '#03030a';
    ctx.fillRect(0, 0, cw, ch);

    const count = Math.round(100 * density);
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    for (let i = 0; i < count; i++) {
      const sx = ((i * 197 + 41) % cw);
      const sy = ((i * 113 + 17) % ch);
      const sr = (i % 5 === 0) ? 1.5 : 0.7;
      ctx.beginPath();
      ctx.arc(sx, sy, sr, 0, Math.PI * 2);
      ctx.fill();
    }
  },

  // ---------------------------------------------------------------------------
  // _drawSpaceship (private)
  // Draws a simplified spaceship silhouette.
  // ---------------------------------------------------------------------------
  _drawSpaceship(ctx, x, y, w, h, rotation, color) {
    ctx.save();
    ctx.translate(x + w / 2, y + h / 2);
    ctx.rotate(rotation);

    // Main hull
    ctx.fillStyle = color || '#aabbcc';
    ctx.beginPath();
    ctx.moveTo(-w / 2,       -h * 0.25);
    ctx.lineTo( w * 0.35,    -h * 0.5);
    ctx.lineTo( w / 2,       -h * 0.1);
    ctx.lineTo( w / 2,        h * 0.1);
    ctx.lineTo( w * 0.35,     h * 0.5);
    ctx.lineTo(-w / 2,        h * 0.25);
    ctx.closePath();
    ctx.fill();

    // Bridge / cockpit
    ctx.fillStyle = 'rgba(150,220,255,0.7)';
    ctx.beginPath();
    ctx.ellipse(w * 0.25, 0, w * 0.1, h * 0.2, 0, 0, Math.PI * 2);
    ctx.fill();

    // Panel lines
    ctx.strokeStyle = 'rgba(0,0,0,0.3)';
    ctx.lineWidth   = 1;
    ctx.beginPath();
    ctx.moveTo(-w * 0.1, -h * 0.35);
    ctx.lineTo(-w * 0.1,  h * 0.35);
    ctx.stroke();

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawTextScene (private)
  // Draws a centered text card over a star field.
  // ---------------------------------------------------------------------------
  _drawTextScene(ctx, cw, ch, line1, line2, accentColor) {
    ctx.shadowColor  = accentColor || '#ffffff';
    ctx.shadowBlur   = 20;
    ctx.fillStyle    = '#ffffff';
    ctx.font         = 'italic 26px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(line1, cw / 2, line2 ? ch / 2 - 22 : ch / 2);

    if (line2) {
      ctx.shadowBlur  = 12;
      ctx.fillStyle   = accentColor || '#ffffff';
      ctx.font        = 'bold italic 26px "Roboto", sans-serif';
      ctx.fillText(line2, cw / 2, ch / 2 + 22);
    }

    ctx.shadowBlur = 0;
  },

};
