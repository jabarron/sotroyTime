// =============================================================================
// levelSelect.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Level selection screen. Shows level cards with:
//   - Level name and number
//   - Star rating from best run (0-3 stars)
//   - Lock icon if not yet unlocked
//   - Best time and ring count
//
// Currently: Level 1 always unlocked. Level 2 shown as locked placeholder.
// Tapping an unlocked card → CUTSCENE_INTRO for that level.
// =============================================================================

window.Game = window.Game || {};
window.Game.screens = window.Game.screens || {};

window.Game.screens.levelSelect = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  alpha: 0,
  timer: 0,

  // Level card definitions
  levelCards: [
    {
      level:       1,
      name:        'The Shipwreck',
      description: 'Escape the dying ship',
      x: 0, y: 0, width: 320, height: 260,
    },
    {
      level:       2,
      name:        'The Void Walk',
      description: 'Cross the hull of space',
      x: 0, y: 0, width: 320, height: 260,
    },
  ],

  // ---------------------------------------------------------------------------
  // ENTER
  // ---------------------------------------------------------------------------
  enter() {
    this.alpha = 0;
    this.timer = 0;

    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    const cardW   = 320;
    const cardH   = 260;
    const gap     = 60;
    const totalW  = cardW * 2 + gap;
    const startX  = (cw - totalW) / 2;
    const cardY   = (ch - cardH) / 2 + 30;

    this.levelCards[0].x = startX;
    this.levelCards[0].y = cardY;
    this.levelCards[1].x = startX + cardW + gap;
    this.levelCards[1].y = cardY;
    this.levelCards[0].width  = cardW;
    this.levelCards[0].height = cardH;
    this.levelCards[1].width  = cardW;
    this.levelCards[1].height = cardH;

    console.log('levelSelect.js: Entered.');
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    this.timer += deltaTime * 1000;
    this.alpha  = Math.min(1, this.timer / 400);
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    ctx.save();
    ctx.globalAlpha = this.alpha;

    // Background
    ctx.fillStyle = '#07080f';
    ctx.fillRect(0, 0, cw, ch);

    // Star field
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    for (let i = 0; i < 55; i++) {
      ctx.beginPath();
      ctx.arc(((i * 193 + 37) % cw), ((i * 107 + 29) % ch), 0.7, 0, Math.PI * 2);
      ctx.fill();
    }

    // Title
    ctx.fillStyle    = 'rgba(255,255,255,0.85)';
    ctx.font         = 'bold 20px "Pacifico", cursive';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Select Level', cw / 2, 70);

    // Back button
    ctx.fillStyle    = 'rgba(255,255,255,0.3)';
    ctx.font         = '13px "Roboto", sans-serif';
    ctx.textAlign    = 'left';
    ctx.fillText('← Back', 24, 70);

    // Level cards
    this.levelCards.forEach(card => {
      this._drawLevelCard(ctx, card);
    });

    ctx.globalAlpha = 1;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawLevelCard (private)
  // ---------------------------------------------------------------------------
  _drawLevelCard(ctx, card) {
    const save       = window.Game.save;
    const unlocked   = save ? save.isLevelUnlocked(card.level) : card.level === 1;
    const bestStars  = save ? save.getBestStars(card.level) : 0;
    const bestTime   = save ? save.data.bestTime[card.level]  : null;
    const bestRings  = save ? save.data.bestRings[card.level] : 0;

    ctx.save();

    // Card body
    ctx.fillStyle = unlocked ? '#0e1e30' : '#0a0a0a';
    ctx.beginPath();
    ctx.roundRect(card.x, card.y, card.width, card.height, 14);
    ctx.fill();

    // Border
    ctx.strokeStyle = unlocked ? 'rgba(74,240,192,0.3)' : 'rgba(255,255,255,0.06)';
    ctx.lineWidth   = 1.5;
    ctx.beginPath();
    ctx.roundRect(card.x + 1, card.y + 1, card.width - 2, card.height - 2, 14);
    ctx.stroke();

    if (!unlocked) {
      // --- LOCKED card ---
      // Lock icon
      ctx.fillStyle    = 'rgba(255,255,255,0.1)';
      ctx.font         = '42px "Roboto", sans-serif';
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🔒', card.x + card.width / 2, card.y + card.height / 2 - 20);

      ctx.fillStyle    = 'rgba(255,255,255,0.2)';
      ctx.font         = '14px "Roboto", sans-serif';
      ctx.fillText(card.name, card.x + card.width / 2, card.y + card.height / 2 + 26);

      ctx.fillStyle    = 'rgba(255,255,255,0.12)';
      ctx.font         = '12px "Roboto", sans-serif';
      ctx.fillText('Complete Level 1 to unlock', card.x + card.width / 2, card.y + card.height / 2 + 50);

    } else {
      // --- UNLOCKED card ---

      // Level number badge
      ctx.fillStyle    = 'rgba(74,240,192,0.15)';
      ctx.font         = 'bold 11px "Roboto", sans-serif';
      ctx.textAlign    = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(`LEVEL ${card.level}`, card.x + 18, card.y + 18);

      // Level name
      ctx.fillStyle    = '#ffffff';
      ctx.font         = 'bold 20px "Pacifico", cursive';
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(card.name, card.x + card.width / 2, card.y + 68);

      // Description
      ctx.fillStyle    = 'rgba(255,255,255,0.45)';
      ctx.font         = 'italic 13px "Roboto", sans-serif';
      ctx.fillText(card.description, card.x + card.width / 2, card.y + 94);

      // Stars
      this._drawStars(ctx, card, bestStars);

      // Best stats (only if played before)
      if (bestStars > 0) {
        const statsY = card.y + card.height - 68;

        ctx.fillStyle    = 'rgba(255,255,255,0.3)';
        ctx.font         = '11px "Roboto", sans-serif';
        ctx.textAlign    = 'center';

        const timeStr = bestTime
          ? `${Math.floor(bestTime / 60)}:${(bestTime % 60).toString().padStart(2, '0')}`
          : '--:--';

        ctx.fillText(`Best Time: ${timeStr}   Rings: ${bestRings}`, card.x + card.width / 2, statsY);
      }

      // Play button
      const btnY = card.y + card.height - 48;
      const btnW = 160;
      const btnX = card.x + (card.width - btnW) / 2;

      ctx.fillStyle = 'rgba(74,240,192,0.18)';
      ctx.strokeStyle = 'rgba(74,240,192,0.7)';
      ctx.lineWidth   = 1.5;
      ctx.shadowColor = '#4af0c0';
      ctx.shadowBlur  = 8;
      ctx.beginPath();
      ctx.roundRect(btnX, btnY, btnW, 34, 8);
      ctx.fill();
      ctx.stroke();
      ctx.shadowBlur  = 0;

      ctx.fillStyle    = '#ffffff';
      ctx.font         = 'bold 15px "Roboto", sans-serif';
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(bestStars > 0 ? 'Play Again' : 'Play', btnX + btnW / 2, btnY + 17);
    }

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawStars (private)
  // Draws 3 star icons — filled or empty based on bestStars count.
  // ---------------------------------------------------------------------------
  _drawStars(ctx, card, count) {
    const starSize = 22;
    const gap      = 6;
    const totalW   = 3 * starSize + 2 * gap;
    const startX   = card.x + (card.width - totalW) / 2;
    const starY    = card.y + 128;

    for (let i = 0; i < 3; i++) {
      const sx   = startX + i * (starSize + gap);
      const sy   = starY;
      const full = i < count;

      ctx.save();
      ctx.beginPath();

      // 5-point star path
      const cx  = sx + starSize / 2;
      const cy  = sy + starSize / 2;
      const outerR = starSize / 2;
      const innerR = outerR * 0.42;

      for (let p = 0; p < 10; p++) {
        const angle = (p * Math.PI / 5) - Math.PI / 2;
        const r     = (p % 2 === 0) ? outerR : innerR;
        if (p === 0) ctx.moveTo(cx + r * Math.cos(angle), cy + r * Math.sin(angle));
        else         ctx.lineTo(cx + r * Math.cos(angle), cy + r * Math.sin(angle));
      }
      ctx.closePath();

      if (full) {
        ctx.fillStyle   = '#ffd700';
        ctx.shadowColor = '#ffd700';
        ctx.shadowBlur  = 8;
      } else {
        ctx.fillStyle = 'rgba(255,255,255,0.1)';
      }

      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.restore();
    }
  },

  // ---------------------------------------------------------------------------
  // HANDLE TAP
  // ---------------------------------------------------------------------------
  handleTap(screenX, screenY) {
    // Back button (top-left area)
    if (screenX < 100 && screenY < 100) {
      window.Game.state.transition('MAIN_MENU');
      return;
    }

    this.levelCards.forEach(card => {
      const save     = window.Game.save;
      const unlocked = save ? save.isLevelUnlocked(card.level) : card.level === 1;
      if (!unlocked) return;

      if (screenX >= card.x && screenX <= card.x + card.width &&
          screenY >= card.y && screenY <= card.y + card.height) {

        // Set which level we're playing
        window.Game.state.currentLevel = card.level;
        // Transition to the intro cutscene
        window.Game.state.transition('CUTSCENE_INTRO');
      }
    });
  },

};
