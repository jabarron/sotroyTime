// =============================================================================
// victory.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// The final screen. Shown after level complete → continue is tapped.
// Displays rolling credits with the personal dedication.
//
// SEQUENCE:
//   1. Black screen fades in
//   2. "iWillGetToYou" title pulses
//   3. Credits roll upward slowly
//   4. Dedication line lingers at the end
//   5. "Play Again" button appears
//
// Player can tap at any time to skip to the button.
// =============================================================================

window.Game = window.Game || {};
window.Game.screens = window.Game.screens || {};

window.Game.screens.victory = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  alpha:        0,
  timer:        0,
  scrollY:      0,        // current Y offset of credits scroll
  scrollSpeed:  28,       // pixels per second
  skipped:      false,
  showButton:   false,

  // Button
  playAgainBtn: { x: 0, y: 0, width: 220, height: 52 },

  // Credits content — drawn as scrolling text lines
  // Each line: { text, size, color, gap (extra space after) }
  CREDITS: [
    { text: '',                                     size: 14, color: 'transparent', gap: 60  },
    { text: 'iWillGetToYou',                        size: 52, color: '#ffffff',     gap: 8,  font: 'Pacifico' },
    { text: 'A J & I Studios Game',                 size: 14, color: 'rgba(255,255,255,0.4)', gap: 60 },

    { text: 'GAME DESIGN & DEVELOPMENT',            size: 10, color: 'rgba(74,240,192,0.6)', gap: 8, spacing: true },
    { text: 'J & I Studios',                        size: 18, color: '#ffffff',     gap: 40 },

    { text: 'STORY & CONCEPT',                      size: 10, color: 'rgba(74,240,192,0.6)', gap: 8, spacing: true },
    { text: 'J & I Studios',                        size: 18, color: '#ffffff',     gap: 40 },

    { text: 'MUSIC & SOUND',                        size: 10, color: 'rgba(74,240,192,0.6)', gap: 8, spacing: true },
    { text: 'freemusicarchive.org',                 size: 14, color: 'rgba(255,255,255,0.6)', gap: 4 },
    { text: 'freesound.org',                        size: 14, color: 'rgba(255,255,255,0.6)', gap: 40 },

    { text: 'BUILT WITH',                           size: 10, color: 'rgba(74,240,192,0.6)', gap: 8, spacing: true },
    { text: 'HTML5 Canvas  ·  Vanilla JavaScript',  size: 14, color: 'rgba(255,255,255,0.6)', gap: 4 },
    { text: 'Pacifico  ·  Roboto  (Google Fonts)',  size: 14, color: 'rgba(255,255,255,0.6)', gap: 60 },

    { text: '— — —',                                size: 16, color: 'rgba(255,255,255,0.2)', gap: 40 },

    { text: 'SPECIAL THANKS',                       size: 10, color: 'rgba(74,240,192,0.6)', gap: 8, spacing: true },
    { text: 'Thanks to J & I',                      size: 22, color: '#ffffff',     gap: 60 },

    { text: '— — —',                                size: 16, color: 'rgba(255,255,255,0.2)', gap: 60 },

    // Dedication — the heart of the game
    { text: 'Made with love,',                      size: 20, color: 'rgba(220,200,255,0.9)', gap: 8,  font: 'Pacifico' },
    { text: 'for J & I',                            size: 36, color: '#ffffff',     gap: 12, font: 'Pacifico' },
    { text: 'We found us...',                       size: 22, color: 'rgba(180,160,255,0.85)', gap: 80, font: 'Pacifico' },

    { text: '2026',                                 size: 13, color: 'rgba(255,255,255,0.2)', gap: 120 },
  ],

  // Total height of credits content (calculated in enter)
  _totalCreditsHeight: 0,

  // ---------------------------------------------------------------------------
  // ENTER
  // ---------------------------------------------------------------------------
  enter() {
    this.alpha      = 0;
    this.timer      = 0;
    this.skipped    = false;
    this.showButton = false;

    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    // Start credits off-screen bottom, scroll up
    this.scrollY = ch;

    // Calculate total credits height
    let totalH = 0;
    this.CREDITS.forEach(line => {
      totalH += (line.size * 1.4) + (line.gap || 0);
    });
    this._totalCreditsHeight = totalH;

    // Position play again button
    this.playAgainBtn.x = (cw - this.playAgainBtn.width) / 2;
    this.playAgainBtn.y = ch - 90;

    console.log('victory.js: Entered.');
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    this.timer += deltaTime * 1000;
    this.alpha  = Math.min(1, this.timer / 800);

    if (this.skipped) return;

    // Scroll credits upward
    this.scrollY -= this.scrollSpeed * deltaTime;

    const C  = window.Game.constants;
    const ch = C.CANVAS_HEIGHT;

    // When credits have scrolled fully past the top, show the button
    if (this.scrollY < -this._totalCreditsHeight) {
      this.skipped    = true;
      this.showButton = true;
    }
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    ctx.save();
    ctx.globalAlpha = this.alpha;

    // --- Background: deep space black with soft nebula glow ---
    ctx.fillStyle = '#030308';
    ctx.fillRect(0, 0, cw, ch);

    // Nebula — soft purple/blue cloud center
    const nebula = ctx.createRadialGradient(cw / 2, ch / 2, 0, cw / 2, ch / 2, ch * 0.6);
    nebula.addColorStop(0,   'rgba(60, 20, 100, 0.25)');
    nebula.addColorStop(0.5, 'rgba(20, 10, 60,  0.15)');
    nebula.addColorStop(1,   'rgba(0,  0,  0,   0)');
    ctx.fillStyle = nebula;
    ctx.fillRect(0, 0, cw, ch);

    // Stars — more than usual for the ending
    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    for (let i = 0; i < 120; i++) {
      const twinkle = 0.4 + 0.6 * Math.abs(Math.sin(Date.now() / 1000 + i * 0.7));
      ctx.globalAlpha = this.alpha * twinkle * 0.7;
      const sr = (i % 6 === 0) ? 1.8 : 0.8;
      ctx.beginPath();
      ctx.arc(((i * 197 + 47) % cw), ((i * 113 + 29) % ch), sr, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = this.alpha;

    if (!this.showButton) {
      // --- Scrolling credits ---
      this._drawCredits(ctx, cw, ch);

      // Fade mask — top and bottom edges so text fades in/out cleanly
      const maskTop = ctx.createLinearGradient(0, 0, 0, 100);
      maskTop.addColorStop(0, 'rgba(3,3,8,1)');
      maskTop.addColorStop(1, 'rgba(3,3,8,0)');
      ctx.fillStyle = maskTop;
      ctx.fillRect(0, 0, cw, 100);

      const maskBot = ctx.createLinearGradient(0, ch - 100, 0, ch);
      maskBot.addColorStop(0, 'rgba(3,3,8,0)');
      maskBot.addColorStop(1, 'rgba(3,3,8,1)');
      ctx.fillStyle = maskBot;
      ctx.fillRect(0, ch - 100, cw, 100);

      // Skip hint
      ctx.fillStyle    = 'rgba(255,255,255,0.2)';
      ctx.font         = '11px "Roboto", sans-serif';
      ctx.textAlign    = 'right';
      ctx.textBaseline = 'bottom';
      ctx.fillText('Tap to skip', cw - 20, ch - 16);

    } else {
      // --- Credits done — show dedication and play again ---
      this._drawEndCard(ctx, cw, ch);
    }

    ctx.globalAlpha = 1;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawCredits (private)
  // ---------------------------------------------------------------------------
  _drawCredits(ctx, cw, ch) {
    let currentY = this.scrollY;

    this.CREDITS.forEach(line => {
      const lineH = line.size * 1.4;

      // Only draw if visible on screen
      if (currentY + lineH > 0 && currentY < ch) {

        // Opacity: fade in as it enters top, fade out as it leaves
        let lineAlpha = 1;
        if (currentY < 120) {
          lineAlpha = Math.max(0, currentY / 120);
        } else if (currentY > ch - 120) {
          lineAlpha = Math.max(0, (ch - currentY) / 120);
        }

        ctx.save();
        ctx.globalAlpha *= lineAlpha;

        const fontFamily = line.font === 'Pacifico'
          ? '"Pacifico", cursive'
          : '"Roboto", sans-serif';

        const weight = line.spacing ? '' : 'bold ';
        ctx.font         = `${weight}${line.size}px ${fontFamily}`;
        ctx.fillStyle    = line.color || '#ffffff';
        ctx.textAlign    = 'center';
        ctx.textBaseline = 'top';

        if (line.text && line.color !== 'transparent') {
          // Letter spacing for section headers
          if (line.spacing) {
            ctx.letterSpacing = '3px';
          }
          ctx.fillText(line.text, cw / 2, currentY);
          ctx.letterSpacing = '0px';
        }

        ctx.restore();
      }

      currentY += lineH + (line.gap || 0);
    });
  },

  // ---------------------------------------------------------------------------
  // _drawEndCard (private)
  // Final static card shown after credits finish scrolling.
  // ---------------------------------------------------------------------------
  _drawEndCard(ctx, cw, ch) {
    const time  = Date.now() / 1000;
    const pulse = 0.85 + 0.15 * Math.sin(time * 1.2);

    // J&I logo — large, glowing
    ctx.shadowColor  = `rgba(200,160,255,${pulse * 0.7})`;
    ctx.shadowBlur   = 50 * pulse;
    ctx.fillStyle    = '#ffffff';
    ctx.font         = `bold 80px "Pacifico", cursive`;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('J&I', cw / 2, ch / 2 - 80);

    ctx.shadowBlur   = 15;
    ctx.fillStyle    = 'rgba(220,200,255,0.85)';
    ctx.font         = `20px "Pacifico", cursive`;
    ctx.fillText('iWillGetToYou', cw / 2, ch / 2 - 20);

    ctx.shadowBlur   = 0;

    // Dedication
    ctx.fillStyle    = 'rgba(255,255,255,0.55)';
    ctx.font         = 'italic 15px "Roboto", sans-serif';
    ctx.fillText('Made with love, for J & I  —  We found us...', cw / 2, ch / 2 + 22);

    // Play again button
    const btn   = this.playAgainBtn;
    const bPulse = 0.85 + 0.15 * Math.sin(time * 2);

    ctx.fillStyle   = `rgba(74,240,192,${0.15 * bPulse})`;
    ctx.strokeStyle = `rgba(74,240,192,${0.75 * bPulse})`;
    ctx.lineWidth   = 2;
    ctx.shadowColor = '#4af0c0';
    ctx.shadowBlur  = 10 * bPulse;
    ctx.beginPath();
    ctx.roundRect(btn.x, btn.y, btn.width, btn.height, 10);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur  = 0;

    ctx.fillStyle    = '#ffffff';
    ctx.font         = 'bold 17px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Play Again', btn.x + btn.width / 2, btn.y + btn.height / 2);

    // Year
    ctx.fillStyle    = 'rgba(255,255,255,0.15)';
    ctx.font         = '12px "Roboto", sans-serif';
    ctx.textBaseline = 'bottom';
    ctx.fillText('© 2026 J & I Studios', cw / 2, ch - 16);
  },

  // ---------------------------------------------------------------------------
  // HANDLE TAP
  // ---------------------------------------------------------------------------
  handleTap(screenX, screenY) {
    if (!this.showButton) {
      // Skip credits — jump to end card
      this.skipped    = true;
      this.showButton = true;
      return;
    }

    // Play again button
    const btn = this.playAgainBtn;
    if (screenX >= btn.x && screenX <= btn.x + btn.width &&
        screenY >= btn.y && screenY <= btn.y + btn.height) {

      // Reset everything and go back to main menu
      if (window.Game.state) {
        window.Game.state.reset();
      }
      if (window.Game.audio) {
        window.Game.audio.stopAll();
      }
      if (window.Game.particles) {
        window.Game.particles.clear();
      }

      window.Game.state.transition('MAIN_MENU');
    }
  },

};
