// =============================================================================
// gameOver.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Game over screen. Shown when:
//   - Player loses all 3 lives
//   - Timer hits zero (ship explodes)
//
// Shows the cause of death, rings collected so far, and two options:
//   - Try Again → restarts the level from the beginning
//   - Main Menu → returns to main menu
// =============================================================================

window.Game = window.Game || {};
window.Game.screens = window.Game.screens || {};

window.Game.screens.gameOver = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  alpha: 0,
  timer: 0,

  // Cause — determined by how the game ended
  cause: 'lives',   // 'lives' | 'timer'

  // Buttons
  buttons: {
    retry:    { x: 0, y: 0, width: 200, height: 50, label: 'Try Again'  },
    mainMenu: { x: 0, y: 0, width: 200, height: 50, label: 'Main Menu'  },
  },

  // ---------------------------------------------------------------------------
  // ENTER
  // ---------------------------------------------------------------------------
  enter() {
    this.alpha = 0;
    this.timer = 0;

    const state = window.Game.state;
    this.cause  = state.timerSeconds <= 0 ? 'timer' : 'lives';

    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;
    const cx = cw / 2;

    const btnW = 200;
    const btnH = 50;
    const gap  = 20;

    this.buttons.retry.x    = cx - btnW - gap / 2;
    this.buttons.retry.y    = ch / 2 + 80;
    this.buttons.retry.width = btnW;
    this.buttons.retry.height = btnH;

    this.buttons.mainMenu.x    = cx + gap / 2;
    this.buttons.mainMenu.y    = ch / 2 + 80;
    this.buttons.mainMenu.width = btnW;
    this.buttons.mainMenu.height = btnH;

    console.log(`gameOver.js: Entered. Cause: ${this.cause}`);
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    this.timer += deltaTime * 1000;
    this.alpha  = Math.min(1, this.timer / 600);
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C     = window.Game.constants;
    const cw    = C.CANVAS_WIDTH;
    const ch    = C.CANVAS_HEIGHT;
    const state = window.Game.state;

    ctx.save();
    ctx.globalAlpha = this.alpha;

    // Dark red-tinted background
    ctx.fillStyle = '#080508';
    ctx.fillRect(0, 0, cw, ch);

    // Subtle red vignette
    const vign = ctx.createRadialGradient(cw / 2, ch / 2, ch * 0.2, cw / 2, ch / 2, ch * 0.8);
    vign.addColorStop(0,   'rgba(0,0,0,0)');
    vign.addColorStop(1,   'rgba(100,0,0,0.4)');
    ctx.fillStyle = vign;
    ctx.fillRect(0, 0, cw, ch);

    // Dim star field
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    for (let i = 0; i < 40; i++) {
      ctx.beginPath();
      ctx.arc(((i * 211 + 53) % cw), ((i * 131 + 23) % ch), 0.6, 0, Math.PI * 2);
      ctx.fill();
    }

    // --- "GAME OVER" title ---
    const pulse = 0.8 + 0.2 * Math.sin(Date.now() / 400);
    ctx.shadowColor  = `rgba(255,40,40,${pulse * 0.7})`;
    ctx.shadowBlur   = 30 * pulse;
    ctx.fillStyle    = '#ff3333';
    ctx.font         = `bold 52px "Pacifico", cursive`;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Game Over', cw / 2, ch / 2 - 80);
    ctx.shadowBlur   = 0;

    // --- Cause of death ---
    const causeText = this.cause === 'timer'
      ? 'The ship was consumed by the black hole.'
      : 'You did not survive the shipwreck.';

    ctx.fillStyle    = 'rgba(255,180,180,0.7)';
    ctx.font         = 'italic 16px "Roboto", sans-serif';
    ctx.fillText(causeText, cw / 2, ch / 2 - 36);

    // --- Stats ---
    const progress = window.Game.collectibles
      ? window.Game.collectibles.getProgress()
      : { collected: 0, total: 0 };

    ctx.fillStyle    = 'rgba(255,255,255,0.3)';
    ctx.font         = '14px "Roboto", sans-serif';
    ctx.fillText(
      `Rings collected: ${progress.collected} / ${progress.total}`,
      cw / 2,
      ch / 2 + 10
    );

    ctx.fillText(
      `Reached level ${state.currentLevel}`,
      cw / 2,
      ch / 2 + 36
    );

    // --- Buttons ---
    this._drawButton(ctx, this.buttons.retry,    true);
    this._drawButton(ctx, this.buttons.mainMenu, false);

    ctx.globalAlpha = 1;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawButton (private)
  // ---------------------------------------------------------------------------
  _drawButton(ctx, btn, isPrimary) {
    ctx.save();

    ctx.fillStyle   = isPrimary ? 'rgba(255,60,60,0.2)'  : 'rgba(255,255,255,0.07)';
    ctx.strokeStyle = isPrimary ? 'rgba(255,80,80,0.7)'  : 'rgba(255,255,255,0.2)';
    ctx.lineWidth   = isPrimary ? 2 : 1;

    if (isPrimary) {
      ctx.shadowColor = '#ff4444';
      ctx.shadowBlur  = 10;
    }

    ctx.beginPath();
    ctx.roundRect(btn.x, btn.y, btn.width, btn.height, 10);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur  = 0;

    ctx.fillStyle    = isPrimary ? '#ffffff' : 'rgba(255,255,255,0.55)';
    ctx.font         = isPrimary
      ? 'bold 17px "Roboto", sans-serif'
      : '15px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(btn.label, btn.x + btn.width / 2, btn.y + btn.height / 2);

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // HANDLE TAP
  // ---------------------------------------------------------------------------
  handleTap(screenX, screenY) {
    // Ignore taps in the first 800ms (prevents accidental double-tap)
    if (this.timer < 800) return;

    const hit = (btn) =>
      screenX >= btn.x && screenX <= btn.x + btn.width &&
      screenY >= btn.y && screenY <= btn.y + btn.height;

    if (hit(this.buttons.retry)) {
      this._retryLevel();
      return;
    }

    if (hit(this.buttons.mainMenu)) {
      if (window.Game.audio) window.Game.audio.stopAll();
      window.Game.state.transition('MAIN_MENU');
      return;
    }
  },

  // ---------------------------------------------------------------------------
  // _retryLevel (private)
  // Full level restart from beginning.
  // ---------------------------------------------------------------------------
  _retryLevel() {
    const state  = window.Game.state;
    const gender = state.selectedGender || 'male';
    const level  = state.currentLevel   || 1;

    state.reset();

    if (window.Game.level) {
      window.Game.level.load(gender, level);
    }
    if (window.Game.hud) {
      window.Game.hud.reset();
    }
    if (window.Game.particles) {
      window.Game.particles.clear();
    }

    // Go back to cutscene intro or straight to gameplay
    // We go straight to gameplay on retry — no need to watch cutscene again
    window.Game.state.transition('GAMEPLAY');
  },

};
