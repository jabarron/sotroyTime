// =============================================================================
// mainMenu.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// The main menu screen. Shown after assets finish loading.
// Buttons: Play → LEVEL_SELECT | Settings → toggles mute
//
// Background is plain (approved in design doc — not animated).
// Logo is shown at top.
// =============================================================================

window.Game = window.Game || {};
window.Game.screens = window.Game.screens || {};

window.Game.screens.mainMenu = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  alpha: 0,
  timer: 0,

  // Button hit areas (calculated in enter)
  buttons: {
    play:     { x: 0, y: 0, width: 220, height: 54 },
    settings: { x: 0, y: 0, width: 220, height: 54 },
  },

  // Settings panel toggle
  settingsOpen: false,

  // ---------------------------------------------------------------------------
  // ENTER
  // ---------------------------------------------------------------------------
  enter() {
    this.alpha        = 0;
    this.timer        = 0;
    this.settingsOpen = false;

    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;
    const cx = cw / 2;

    const btnW = 220;
    const btnH = 54;

    this.buttons.play.x     = cx - btnW / 2;
    this.buttons.play.y     = ch / 2 + 20;
    this.buttons.play.width = btnW;
    this.buttons.play.height = btnH;

    this.buttons.settings.x      = cx - btnW / 2;
    this.buttons.settings.y      = ch / 2 + 90;
    this.buttons.settings.width  = btnW;
    this.buttons.settings.height = btnH;

    console.log('mainMenu.js: Entered.');
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    this.timer += deltaTime * 1000;
    this.alpha  = Math.min(1, this.timer / 400);
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;

    ctx.save();
    ctx.globalAlpha = this.alpha;

    // --- Background ---
    ctx.fillStyle = '#07080f';
    ctx.fillRect(0, 0, cw, ch);

    // Faint star field
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    for (let i = 0; i < 60; i++) {
      const sx = ((i * 179 + 23) % cw);
      const sy = ((i * 113 + 11) % ch);
      ctx.beginPath();
      ctx.arc(sx, sy, 0.7, 0, Math.PI * 2);
      ctx.fill();
    }

    // --- Logo ---
    ctx.shadowColor  = 'rgba(200,160,255,0.5)';
    ctx.shadowBlur   = 30;
    ctx.fillStyle    = '#ffffff';
    ctx.font         = `bold 72px "Pacifico", cursive`;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('J&I', cw / 2, ch / 2 - 120);

    ctx.shadowBlur   = 10;
    ctx.fillStyle    = 'rgba(220,200,255,0.85)';
    ctx.font         = `16px "Pacifico", cursive`;
    ctx.fillText('iWillGetToYou', cw / 2, ch / 2 - 60);
    ctx.shadowBlur   = 0;

    // --- Buttons ---
    this._drawButton(ctx, this.buttons.play,     'Play',      true);
    this._drawButton(ctx, this.buttons.settings, 'Settings',  false);

    // --- Settings panel ---
    if (this.settingsOpen) {
      this._drawSettingsPanel(ctx, C, cw, ch);
    }

    // --- Gender selection reminder ---
    const gender = window.Game.state.selectedGender;
    if (gender) {
      ctx.fillStyle    = 'rgba(255,255,255,0.3)';
      ctx.font         = '12px "Roboto", sans-serif';
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'bottom';
      ctx.fillText(
        `Playing as: ${gender === 'male' ? 'Astronaut ◆ His Journey' : 'Explorer ◆ Her Journey'}`,
        cw / 2,
        ch - 20
      );
    }

    ctx.globalAlpha = 1;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawButton (private)
  // ---------------------------------------------------------------------------
  _drawButton(ctx, btn, label, isPrimary) {
    const time  = Date.now() / 1000;
    const pulse = isPrimary ? 0.85 + 0.15 * Math.sin(time * 1.8) : 1;

    // Background
    ctx.fillStyle = isPrimary
      ? `rgba(74, 240, 192, ${pulse * 0.18})`
      : 'rgba(255,255,255,0.07)';
    ctx.beginPath();
    ctx.roundRect(btn.x, btn.y, btn.width, btn.height, 10);
    ctx.fill();

    // Border
    ctx.strokeStyle = isPrimary
      ? `rgba(74, 240, 192, ${pulse * 0.8})`
      : 'rgba(255,255,255,0.2)';
    ctx.lineWidth = isPrimary ? 2 : 1;

    if (isPrimary) {
      ctx.shadowColor = '#4af0c0';
      ctx.shadowBlur  = 12 * pulse;
    }

    ctx.beginPath();
    ctx.roundRect(btn.x + 1, btn.y + 1, btn.width - 2, btn.height - 2, 10);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Label
    ctx.fillStyle    = isPrimary ? '#ffffff' : 'rgba(255,255,255,0.6)';
    ctx.font         = isPrimary
      ? 'bold 20px "Roboto", sans-serif'
      : '16px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, btn.x + btn.width / 2, btn.y + btn.height / 2);
  },

  // ---------------------------------------------------------------------------
  // _drawSettingsPanel (private)
  // ---------------------------------------------------------------------------
  _drawSettingsPanel(ctx, C, cw, ch) {
    const panelW = 320;
    const panelH = 200;
    const panelX = (cw - panelW) / 2;
    const panelY = ch / 2 - 140;

    // Panel background
    ctx.fillStyle = '#0e1520';
    ctx.strokeStyle = 'rgba(255,255,255,0.15)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(panelX, panelY, panelW, panelH, 12);
    ctx.fill();
    ctx.stroke();

    // Title
    ctx.fillStyle    = 'rgba(255,255,255,0.8)';
    ctx.font         = 'bold 16px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Settings', cw / 2, panelY + 30);

    // Mute toggle
    const muted       = window.Game.audio ? window.Game.audio.muted : false;
    const toggleLabel = muted ? '🔇  Sound: OFF' : '🔊  Sound: ON';
    const toggleY     = panelY + 80;

    ctx.fillStyle = muted ? 'rgba(255,80,80,0.15)' : 'rgba(74,240,192,0.12)';
    ctx.beginPath();
    ctx.roundRect(panelX + 60, toggleY - 18, panelW - 120, 36, 8);
    ctx.fill();

    ctx.strokeStyle = muted ? 'rgba(255,80,80,0.5)' : 'rgba(74,240,192,0.5)';
    ctx.lineWidth   = 1.5;
    ctx.beginPath();
    ctx.roundRect(panelX + 61, toggleY - 17, panelW - 122, 34, 8);
    ctx.stroke();

    ctx.fillStyle    = 'rgba(255,255,255,0.75)';
    ctx.font         = '15px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(toggleLabel, cw / 2, toggleY);

    // Switch path button
    const switchY = panelY + 140;
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    ctx.beginPath();
    ctx.roundRect(panelX + 60, switchY - 16, panelW - 120, 32, 8);
    ctx.fill();

    ctx.fillStyle    = 'rgba(255,255,255,0.4)';
    ctx.font         = '13px "Roboto", sans-serif';
    ctx.fillText('Switch Path', cw / 2, switchY);

    // Store toggle button bounds for tap detection
    this._muteBtn   = { x: panelX + 60, y: toggleY - 18, w: panelW - 120, h: 36 };
    this._switchBtn = { x: panelX + 60, y: switchY - 16, w: panelW - 120, h: 32 };
    this._closePanel = { x: panelX, y: panelY, w: panelW, h: panelH };
  },

  // ---------------------------------------------------------------------------
  // HANDLE TAP
  // ---------------------------------------------------------------------------
  handleTap(screenX, screenY) {

    if (this.settingsOpen) {
      // Check mute toggle
      if (this._muteBtn &&
          screenX >= this._muteBtn.x && screenX <= this._muteBtn.x + this._muteBtn.w &&
          screenY >= this._muteBtn.y && screenY <= this._muteBtn.y + this._muteBtn.h) {
        if (window.Game.audio) window.Game.audio.toggleMute();
        return;
      }
      // Check switch path
      if (this._switchBtn &&
          screenX >= this._switchBtn.x && screenX <= this._switchBtn.x + this._switchBtn.w &&
          screenY >= this._switchBtn.y && screenY <= this._switchBtn.y + this._switchBtn.h) {
        window.Game.state.transition('GENDER_SELECT');
        return;
      }
      // Tap outside panel closes it
      this.settingsOpen = false;
      return;
    }

    // Play button
    const play = this.buttons.play;
    if (screenX >= play.x && screenX <= play.x + play.width &&
        screenY >= play.y && screenY <= play.y + play.height) {
      window.Game.state.transition('LEVEL_SELECT');
      return;
    }

    // Settings button
    const settings = this.buttons.settings;
    if (screenX >= settings.x && screenX <= settings.x + settings.width &&
        screenY >= settings.y && screenY <= settings.y + settings.height) {
      this.settingsOpen = true;
      return;
    }
  },

};
