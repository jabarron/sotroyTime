// =============================================================================
// pauseMenu.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// In-game pause overlay. Drawn on top of the frozen game world.
// Options: Resume | Restart Level | Main Menu
// Also shows: current ring count, lives remaining, time remaining.
// Mute toggle accessible here too.
// =============================================================================

window.Game = window.Game || {};
window.Game.screens = window.Game.screens || {};

window.Game.screens.pauseMenu = {

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------
  alpha: 0,
  timer: 0,

  // Button definitions — calculated in enter()
  buttons: {
    resume:    { x: 0, y: 0, width: 240, height: 50, label: 'Resume'       },
    restart:   { x: 0, y: 0, width: 240, height: 50, label: 'Restart Level'},
    mainMenu:  { x: 0, y: 0, width: 240, height: 50, label: 'Main Menu'    },
    mute:      { x: 0, y: 0, width: 240, height: 44, label: ''             },
  },

  // ---------------------------------------------------------------------------
  // ENTER
  // ---------------------------------------------------------------------------
  enter() {
    this.alpha = 0;
    this.timer = 0;

    const C  = window.Game.constants;
    const cw = C.CANVAS_WIDTH;
    const ch = C.CANVAS_HEIGHT;
    const cx = cw / 2;

    const btnW   = 240;
    const btnH   = 50;
    const btnGap = 16;
    const startY = ch / 2 - 60;

    ['resume', 'restart', 'mainMenu'].forEach((key, i) => {
      this.buttons[key].x      = cx - btnW / 2;
      this.buttons[key].y      = startY + i * (btnH + btnGap);
      this.buttons[key].width  = btnW;
      this.buttons[key].height = btnH;
    });

    // Mute button — below the main buttons
    this.buttons.mute.x      = cx - btnW / 2;
    this.buttons.mute.y      = startY + 3 * (btnH + btnGap) + 8;
    this.buttons.mute.width  = btnW;
    this.buttons.mute.height = 44;

    console.log('pauseMenu.js: Entered.');
  },

  // ---------------------------------------------------------------------------
  // UPDATE
  // ---------------------------------------------------------------------------
  update(deltaTime) {
    this.timer += deltaTime * 1000;
    this.alpha  = Math.min(1, this.timer / 250);
  },

  // ---------------------------------------------------------------------------
  // DRAW
  // Draws over the frozen game world — game world was already drawn this frame.
  // ---------------------------------------------------------------------------
  draw(ctx) {
    const C     = window.Game.constants;
    const cw    = C.CANVAS_WIDTH;
    const ch    = C.CANVAS_HEIGHT;
    const state = window.Game.state;

    ctx.save();

    // --- Dimmed overlay ---
    ctx.globalAlpha = this.alpha * 0.72;
    ctx.fillStyle   = '#000000';
    ctx.fillRect(0, 0, cw, ch);
    ctx.globalAlpha = this.alpha;

    // --- Panel ---
    const panelW = 320;
    const panelH = 380;
    const panelX = (cw - panelW) / 2;
    const panelY = (ch - panelH) / 2 - 10;

    ctx.fillStyle   = '#0a111e';
    ctx.strokeStyle = 'rgba(74,240,192,0.3)';
    ctx.lineWidth   = 1.5;
    ctx.beginPath();
    ctx.roundRect(panelX, panelY, panelW, panelH, 16);
    ctx.fill();
    ctx.stroke();

    // --- "PAUSED" title ---
    ctx.fillStyle    = 'rgba(255,255,255,0.9)';
    ctx.font         = 'bold 24px "Pacifico", cursive';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Paused', cw / 2, panelY + 36);

    // --- Quick stats bar ---
    const statsY = panelY + 72;
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    ctx.beginPath();
    ctx.roundRect(panelX + 16, statsY, panelW - 32, 36, 8);
    ctx.fill();

    // Lives
    ctx.fillStyle    = '#ff3355';
    ctx.font         = '13px "Roboto", sans-serif';
    ctx.textAlign    = 'left';
    ctx.textBaseline = 'middle';
    const heartsStr  = '❤'.repeat(state.lives) + '♡'.repeat(C.MAX_LIVES - state.lives);
    ctx.fillText(heartsStr, panelX + 28, statsY + 18);

    // Ring count
    const progress  = window.Game.collectibles
      ? window.Game.collectibles.getProgress()
      : { collected: 0, total: 0 };
    ctx.fillStyle   = '#ffd700';
    ctx.textAlign   = 'center';
    ctx.fillText(`💍 ${progress.collected} / ${progress.total}`, cw / 2, statsY + 18);

    // Timer
    const secs    = Math.max(0, Math.ceil(state.timerSeconds));
    const mins    = Math.floor(secs / 60);
    const secsStr = `${mins}:${(secs % 60).toString().padStart(2, '0')}`;
    ctx.fillStyle   = secs <= C.TIMER_WARNING_SECONDS ? '#ff4444' : '#44ff88';
    ctx.textAlign   = 'right';
    ctx.fillText(`⏱ ${secsStr}`, panelX + panelW - 28, statsY + 18);

    // --- Buttons ---
    ['resume', 'restart', 'mainMenu'].forEach((key, i) => {
      this._drawButton(ctx, this.buttons[key], i === 0);
    });

    // --- Mute button ---
    const muted = window.Game.audio ? window.Game.audio.muted : false;
    this.buttons.mute.label = muted ? '🔇  Sound: OFF' : '🔊  Sound: ON';
    this._drawMuteButton(ctx, this.buttons.mute, muted);

    ctx.globalAlpha = 1;
    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawButton (private)
  // ---------------------------------------------------------------------------
  _drawButton(ctx, btn, isPrimary) {
    ctx.save();

    ctx.fillStyle   = isPrimary ? 'rgba(74,240,192,0.15)' : 'rgba(255,255,255,0.07)';
    ctx.strokeStyle = isPrimary ? 'rgba(74,240,192,0.6)'  : 'rgba(255,255,255,0.15)';
    ctx.lineWidth   = isPrimary ? 1.5 : 1;

    if (isPrimary) {
      ctx.shadowColor = '#4af0c0';
      ctx.shadowBlur  = 10;
    }

    ctx.beginPath();
    ctx.roundRect(btn.x, btn.y, btn.width, btn.height, 10);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur = 0;

    ctx.fillStyle    = isPrimary ? '#ffffff' : 'rgba(255,255,255,0.65)';
    ctx.font         = isPrimary
      ? 'bold 17px "Roboto", sans-serif'
      : '15px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(btn.label, btn.x + btn.width / 2, btn.y + btn.height / 2);

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // _drawMuteButton (private)
  // ---------------------------------------------------------------------------
  _drawMuteButton(ctx, btn, muted) {
    ctx.save();

    ctx.fillStyle   = muted ? 'rgba(255,80,80,0.1)' : 'rgba(255,255,255,0.05)';
    ctx.strokeStyle = muted ? 'rgba(255,80,80,0.3)' : 'rgba(255,255,255,0.1)';
    ctx.lineWidth   = 1;
    ctx.beginPath();
    ctx.roundRect(btn.x, btn.y, btn.width, btn.height, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle    = 'rgba(255,255,255,0.45)';
    ctx.font         = '13px "Roboto", sans-serif';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(btn.label, btn.x + btn.width / 2, btn.y + btn.height / 2);

    ctx.restore();
  },

  // ---------------------------------------------------------------------------
  // HANDLE TAP
  // ---------------------------------------------------------------------------
  handleTap(screenX, screenY) {
    const hit = (btn) =>
      screenX >= btn.x && screenX <= btn.x + btn.width &&
      screenY >= btn.y && screenY <= btn.y + btn.height;

    if (hit(this.buttons.resume)) {
      window.Game.state.transition('GAMEPLAY');
      return;
    }

    if (hit(this.buttons.restart)) {
      this._restartLevel();
      return;
    }

    if (hit(this.buttons.mainMenu)) {
      if (window.Game.audio) window.Game.audio.stopAll();
      window.Game.state.transition('MAIN_MENU');
      return;
    }

    if (hit(this.buttons.mute)) {
      if (window.Game.audio) window.Game.audio.toggleMute();
      return;
    }
  },

  // ---------------------------------------------------------------------------
  // _restartLevel (private)
  // Full level restart — resets all state and reloads the level.
  // ---------------------------------------------------------------------------
  _restartLevel() {
    const state  = window.Game.state;
    const gender = state.selectedGender || 'male';
    const level  = state.currentLevel   || 1;

    // Reset session state
    state.reset();

    // Reload level data and re-initialize all managers
    if (window.Game.level) {
      window.Game.level.load(gender, level);
    }
    if (window.Game.hud) {
      window.Game.hud.reset();
    }
    if (window.Game.particles) {
      window.Game.particles.clear();
    }

    window.Game.state.transition('GAMEPLAY');
  },

};
