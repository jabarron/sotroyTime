// =============================================================================
// constants.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// THE SINGLE SOURCE OF TRUTH for every tunable number in the game.
// NO other file hardcodes a magic number. They all read from here.
// To retune the game feel, change values here ONLY.
// =============================================================================

window.Game = window.Game || {};  // create the global namespace if not yet made

window.Game.constants = {

  // ---------------------------------------------------------------------------
  // CANVAS & DISPLAY
  // The internal resolution the game renders at.
  // CSS will scale this to fill the screen. devicePixelRatio is handled in main.js
  // ---------------------------------------------------------------------------
  CANVAS_WIDTH:  1280,  // internal render width in pixels
  CANVAS_HEIGHT: 720,   // internal render height in pixels

  // ---------------------------------------------------------------------------
  // PHYSICS — low gravity space feel
  // All values are per-second (multiplied by deltaTime each frame)
  // ---------------------------------------------------------------------------
  GRAVITY:          480,   // pixels per second squared (downward pull)
                           // low vs normal (~980) gives the floaty space feel
  MAX_FALL_SPEED:   400,   // pixels/sec — terminal velocity, slower than normal
  FRICTION_GROUND:  0.82,  // multiplier applied to vx each frame on ground
                           // < 1.0 = slows down, 1.0 = no friction
  FRICTION_AIR:     0.95,  // less friction in air — space floaty feel

  // ---------------------------------------------------------------------------
  // PLAYER MOVEMENT
  // ---------------------------------------------------------------------------
  WALK_SPEED:       260,   // horizontal pixels per second while walking
  WALK_ACCELERATION: 1800, // how fast the player reaches WALK_SPEED (px/sec²)
                           // high value = responsive, snappy feel

  // ---------------------------------------------------------------------------
  // JUMPING
  // Negative values = upward (canvas Y increases downward)
  // ---------------------------------------------------------------------------
  JUMP_VELOCITY:         -520,  // pixels/sec — initial upward burst on first jump
  DOUBLE_JUMP_VELOCITY:  -420,  // slightly weaker than first jump
  JUMP_BUFFER_MS:          80,  // ms — if jump pressed just before landing,
                                // it still registers (feels fair to player)
  COYOTE_TIME_MS:         100,  // ms — player can jump this long after walking
                                // off a platform edge (named after Wile E. Coyote)

  // ---------------------------------------------------------------------------
  // DASH (rocket boost for male path)
  // ---------------------------------------------------------------------------
  DASH_FORCE:          700,   // horizontal pixels/sec burst velocity
  DASH_DURATION_MS:    200,   // ms — how long the boost lasts
  DASH_COOLDOWN_MS:   1000,   // ms — wait before can dash again (1 second)
  DASH_INVINCIBLE_MS:  150,   // ms — invincibility window during dash start
                               // player passes through explosions during this

  // ---------------------------------------------------------------------------
  // WALL JUMP
  // ---------------------------------------------------------------------------
  WALL_JUMP_FORCE_X:  320,   // horizontal push away from wall (px/sec)
  WALL_JUMP_FORCE_Y: -480,   // upward force on wall jump (px/sec)
  WALL_SLIDE_SPEED:   80,    // max fall speed while sliding on a wall

  // ---------------------------------------------------------------------------
  // PLAYER DIMENSIONS
  // ---------------------------------------------------------------------------
  PLAYER_WIDTH:  32,   // pixels — collision box width
  PLAYER_HEIGHT: 48,   // pixels — collision box height

  // ---------------------------------------------------------------------------
  // LIVES & DEATH
  // ---------------------------------------------------------------------------
  MAX_LIVES:             3,    // hearts shown in HUD
  DEATH_FLASH_MS:      500,    // total death animation duration in ms
  DEATH_FLASH_INTERVAL: 80,    // ms between visible/invisible flashes
  SPAWN_INVINCIBLE_MS: 1500,   // invincibility after respawning

  // ---------------------------------------------------------------------------
  // TIMER
  // ---------------------------------------------------------------------------
  LEVEL_TIME_SECONDS:      180,  // 3 minutes per level
  TIMER_WARNING_SECONDS:    30,  // timer turns red and pulses below this
  TIMER_YELLOW_SECONDS:     60,  // timer turns yellow below this
  TIMER_PULSE_SPEED:         3,  // speed of the red pulsing effect (radians/sec)

  // ---------------------------------------------------------------------------
  // COLLECTIBLES (rings)
  // ---------------------------------------------------------------------------
  RING_WIDTH:             20,   // collision/display size in pixels
  RING_HEIGHT:            20,
  RING_COLLECT_RADIUS:    28,   // player must be this close to collect (pixels)
  COMPLETION_THRESHOLD:  0.80,  // 80% of rings needed to unlock exit door
  RING_FLOAT_SPEED:       1.8,  // radians/sec — speed of floating bob animation
  RING_FLOAT_AMOUNT:        6,  // pixels up/down in the float animation
  RING_GLOW_SPEED:         2.2, // radians/sec — speed of glow pulse

  CHECKPOINT_WIDTH:       32,   // checkpoint ring is larger than common ring
  CHECKPOINT_HEIGHT:      32,
  CHECKPOINT_COLLECT_RADIUS: 36,

  // ---------------------------------------------------------------------------
  // OBSTACLES
  // ---------------------------------------------------------------------------
  CRUSHER_SPEED:       220,   // pixels/sec movement speed
  PLATFORM_SPEED:      120,   // pixels/sec for moving platforms
  EXPLOSION_WARNING_MS: 900,  // ms of orange warning glow before it fires
  EXPLOSION_ACTIVE_MS:  300,  // ms the explosion zone is lethal
  EXPLOSION_COOL_MS:   1200,  // ms cooldown before next explosion cycle

  // ---------------------------------------------------------------------------
  // CAMERA
  // ---------------------------------------------------------------------------
  CAMERA_LOOKAHEAD:  200,   // pixels ahead of player the camera targets
  CAMERA_LERP:      0.08,   // 0-1 smoothing — lower = smoother but slower
  CAMERA_Y_LERP:    0.05,   // vertical follow is slightly slower

  // ---------------------------------------------------------------------------
  // PARTICLES
  // ---------------------------------------------------------------------------
  EXHAUST_COUNT:       8,    // particles per dash exhaust burst
  EXHAUST_LIFE_MS:   280,    // how long each exhaust particle lives
  EXHAUST_SPREAD:     60,    // degrees of spread in emission cone
  SPARKLE_COUNT:       6,    // particles on ring collect
  SPARKLE_LIFE_MS:   400,
  CHECKPOINT_BURST:   14,    // larger burst for checkpoint collect

  // ---------------------------------------------------------------------------
  // HUD
  // ---------------------------------------------------------------------------
  HUD_PADDING:         16,   // pixels from screen edge
  HEART_SIZE:          28,   // heart icon size in pixels
  HEART_GAP:           8,    // gap between hearts
  RING_ICON_SIZE:      22,   // ring counter icon size
  CALLOUT_DISPLAY_MS: 2800,  // how long a contextual callout text stays up
  CALLOUT_FADE_MS:     400,  // fade in and fade out duration

  // ---------------------------------------------------------------------------
  // DASH COOLDOWN BAR (shown near right thumb control area)
  // ---------------------------------------------------------------------------
  COOLDOWN_BAR_WIDTH:   60,  // pixels
  COOLDOWN_BAR_HEIGHT:   6,  // pixels

  // ---------------------------------------------------------------------------
  // STAR RATING THRESHOLDS (for level complete screen)
  // 1 star = reached exit (minimum)
  // 2 stars = 100% rings collected
  // 3 stars = 100% rings + no deaths
  // ---------------------------------------------------------------------------
  STAR_RING_THRESHOLD:   1.0,  // must collect 100% for 2+ stars

  // ---------------------------------------------------------------------------
  // AUDIO VOLUMES (0.0 to 1.0)
  // ---------------------------------------------------------------------------
  MUSIC_VOLUME:  0.5,   // background music (quieter so SFX cut through)
  SFX_VOLUME:    0.85,  // sound effects

  // ---------------------------------------------------------------------------
  // SCREEN TRANSITIONS
  // ---------------------------------------------------------------------------
  SPLASH_DURATION_MS:   2800,  // how long the logo splash shows
  FADE_DURATION_MS:      400,  // screen fade in/out duration

  // ---------------------------------------------------------------------------
  // PLAYER START POSITION (overridden by level data, but used as fallback)
  // ---------------------------------------------------------------------------
  PLAYER_START_X: 120,
  PLAYER_START_Y: 580,

  // ---------------------------------------------------------------------------
  // ROTATION WARNING
  // ---------------------------------------------------------------------------
  // If phone is portrait, show a rotate warning. Threshold in degrees.
  PORTRAIT_THRESHOLD: 1.0,  // ratio — if width < height * this, show warning

};

// Freeze the object so no file can accidentally overwrite a constant
Object.freeze(window.Game.constants);
