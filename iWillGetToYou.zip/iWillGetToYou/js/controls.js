// =============================================================================
// controls.js
// iWillGetToYou — J&I Studios, 2026
// -----------------------------------------------------------------------------
// Manages ALL player input — touch buttons (mobile) and keyboard (desktop).
// Maintains a single input state object that movement.js reads every frame.
//
// CRITICAL DESIGN RULE:
//   'jump' and 'dash' are TRUE for exactly ONE frame — the frame the button
//   is first pressed. They are reset to false by clearFrameInputs() at the
//   END of every game loop iteration.
//   'left', 'right', 'jumpHeld' remain true WHILE held.
//
// No other file reads touch events or keyboard events.
// No other file writes to Game.controls.input.
// =============================================================================

window.Game = window.Game || {};

window.Game.controls = {

  // ---------------------------------------------------------------------------
  // INPUT STATE
  // Read every frame by movement.js.
  // Never write to this directly from outside controls.js.
  // ---------------------------------------------------------------------------
  input: {
    left:      false,   // true while left button/key is held
    right:     false,   // true while right button/key is held
    jump:      false,   // true ONLY on the frame the jump button is pressed
    jumpHeld:  false,   // true while jump button is held (for variable jump height)
    dash:      false,   // true ONLY on the frame the dash button is pressed
    pause:     false,   // true ONLY on the frame pause is pressed
  },

  // ---------------------------------------------------------------------------
  // BUTTON DOM REFERENCES
  // Set during init() after the DOM is ready.
  // ---------------------------------------------------------------------------
  buttons: {
    left:  null,
    right: null,
    jump:  null,
    dash:  null,
    pause: null,
  },

  // ---------------------------------------------------------------------------
  // INIT
  // Attaches all event listeners.
  // Must be called after index.html has fully loaded (called by main.js).
  // ---------------------------------------------------------------------------
  init() {
    // --- Get button references from the DOM ---
    this.buttons.left  = document.getElementById('btn-left');
    this.buttons.right = document.getElementById('btn-right');
    this.buttons.jump  = document.getElementById('btn-jump');
    this.buttons.dash  = document.getElementById('btn-dash');
    this.buttons.pause = document.getElementById('btn-pause');

    // --- Attach touch listeners to each button ---
    this._attachTouchButton(this.buttons.left,  'left');
    this._attachTouchButton(this.buttons.right, 'right');
    this._attachTouchButton(this.buttons.jump,  'jump');
    this._attachTouchButton(this.buttons.dash,  'dash');

    // Pause button is press-only (no hold behavior)
    if (this.buttons.pause) {
      this.buttons.pause.addEventListener('touchstart', (e) => {
        e.preventDefault();
        this._onPausePressed();
      }, { passive: false });

      // Also allow click for desktop testing
      this.buttons.pause.addEventListener('mousedown', (e) => {
        e.preventDefault();
        this._onPausePressed();
      });
    }

    // --- Keyboard listeners (desktop testing) ---
    window.addEventListener('keydown', (e) => this._onKeyDown(e));
    window.addEventListener('keyup',   (e) => this._onKeyUp(e));

    // --- Prevent default touch behavior on the canvas ---
    // Stops the page from scrolling or zooming while playing
    const canvas = document.getElementById('game-canvas');
    if (canvas) {
      canvas.addEventListener('touchstart', (e) => e.preventDefault(), { passive: false });
      canvas.addEventListener('touchmove',  (e) => e.preventDefault(), { passive: false });
      canvas.addEventListener('touchend',   (e) => e.preventDefault(), { passive: false });
    }

    // --- iOS audio unlock on first tap anywhere ---
    document.addEventListener('touchstart', () => {
      if (window.Game.audio) {
        window.Game.audio.unlock();
      }
    }, { once: true });   // 'once: true' removes the listener after first fire

    // Also unlock on first click (desktop)
    document.addEventListener('mousedown', () => {
      if (window.Game.audio) {
        window.Game.audio.unlock();
      }
    }, { once: true });

    console.log('controls.js: Input listeners attached.');
  },

  // ---------------------------------------------------------------------------
  // _attachTouchButton (private)
  // Attaches touchstart / touchend to a button element.
  // Maps to the correct input state property.
  // ---------------------------------------------------------------------------
  _attachTouchButton(element, action) {
    if (!element) {
      console.warn(`controls.js: Button element for "${action}" not found in DOM.`);
      return;
    }

    // touchstart — button pressed down
    element.addEventListener('touchstart', (e) => {
      e.preventDefault();   // prevent ghost click and page scroll

      // Only respond during gameplay or pause transitions
      const s = window.Game.state;
      if (!s || (s.current !== 'GAMEPLAY' && s.current !== 'PAUSED')) return;

      if (action === 'jump') {
        this.input.jump     = true;   // single-frame press flag
        this.input.jumpHeld = true;   // sustained hold flag
      } else if (action === 'dash') {
        this.input.dash = true;       // single-frame press flag
      } else {
        this.input[action] = true;    // left, right
      }

    }, { passive: false });

    // touchend — button released
    element.addEventListener('touchend', (e) => {
      e.preventDefault();

      if (action === 'jump') {
        this.input.jumpHeld = false;  // jump key released
        // Note: input.jump is already reset by clearFrameInputs()
      } else if (action === 'dash') {
        // dash is already reset by clearFrameInputs()
      } else {
        this.input[action] = false;   // left, right released
      }

    }, { passive: false });

    // touchcancel — finger lifted outside button (treat as release)
    element.addEventListener('touchcancel', (e) => {
      e.preventDefault();
      if (action === 'jump') {
        this.input.jumpHeld = false;
      } else {
        this.input[action] = false;
      }
    }, { passive: false });

    // Mouse events for desktop testing
    element.addEventListener('mousedown', (e) => {
      e.preventDefault();
      const s = window.Game.state;
      if (!s || s.current !== 'GAMEPLAY') return;

      if (action === 'jump') {
        this.input.jump     = true;
        this.input.jumpHeld = true;
      } else if (action === 'dash') {
        this.input.dash = true;
      } else {
        this.input[action] = true;
      }
    });

    element.addEventListener('mouseup', (e) => {
      e.preventDefault();
      if (action === 'jump') {
        this.input.jumpHeld = false;
      } else {
        this.input[action] = false;
      }
    });
  },

  // ---------------------------------------------------------------------------
  // _onPausePressed (private)
  // Handles pause button — toggles between GAMEPLAY and PAUSED.
  // ---------------------------------------------------------------------------
  _onPausePressed() {
    const s = window.Game.state;
    if (!s) return;

    if (s.current === 'GAMEPLAY') {
      s.transition('PAUSED');
    } else if (s.current === 'PAUSED') {
      s.transition('GAMEPLAY');
    }
  },

  // ---------------------------------------------------------------------------
  // _onKeyDown (private) — keyboard support for desktop testing
  // ---------------------------------------------------------------------------
  _onKeyDown(e) {
    const s = window.Game.state;
    if (!s || s.current !== 'GAMEPLAY') {

      // Allow Escape to pause even without checking state strictly
      if (e.code === 'Escape') {
        this._onPausePressed();
        return;
      }
      return;
    }

    switch (e.code) {
      case 'ArrowLeft':
      case 'KeyA':
        this.input.left = true;
        break;

      case 'ArrowRight':
      case 'KeyD':
        this.input.right = true;
        break;

      case 'ArrowUp':
      case 'KeyW':
      case 'Space':
        if (!this.input.jumpHeld) {
          // Only set single-frame jump flag if not already holding
          this.input.jump = true;
        }
        this.input.jumpHeld = true;
        e.preventDefault();   // prevent Space from scrolling the page
        break;

      case 'ShiftLeft':
      case 'ShiftRight':
      case 'KeyX':
      case 'KeyF':
        this.input.dash = true;
        break;

      case 'Escape':
      case 'KeyP':
        this._onPausePressed();
        break;
    }
  },

  // ---------------------------------------------------------------------------
  // _onKeyUp (private) — keyboard key released
  // ---------------------------------------------------------------------------
  _onKeyUp(e) {
    switch (e.code) {
      case 'ArrowLeft':
      case 'KeyA':
        this.input.left = false;
        break;

      case 'ArrowRight':
      case 'KeyD':
        this.input.right = false;
        break;

      case 'ArrowUp':
      case 'KeyW':
      case 'Space':
        this.input.jumpHeld = false;
        break;
    }
  },

  // ---------------------------------------------------------------------------
  // CLEAR FRAME INPUTS
  // MUST be called at the END of every game loop frame.
  // Resets single-frame flags so they are only true for exactly one frame.
  // 'left', 'right', 'jumpHeld' are NOT cleared — they persist while held.
  // ---------------------------------------------------------------------------
  clearFrameInputs() {
    this.input.jump  = false;
    this.input.dash  = false;
    this.input.pause = false;
  },

  // ---------------------------------------------------------------------------
  // CLEAR ALL
  // Resets every input flag.
  // Called when transitioning to a non-gameplay state (cutscene, menu, etc.)
  // so stale inputs don't carry over.
  // ---------------------------------------------------------------------------
  clearAll() {
    this.input.left      = false;
    this.input.right     = false;
    this.input.jump      = false;
    this.input.jumpHeld  = false;
    this.input.dash      = false;
    this.input.pause     = false;
  },

};
