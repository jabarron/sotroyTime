# Sprite Specification — iWillGetToYou
## J&I Studios, 2026
## For use when commissioning or creating final pixel art assets

---

## Art Style Guide

**Target style:** 16-bit SNES-era pixel art
**Color depth:** 32 colors maximum per sprite sheet
**Outline:** 1px dark outline on all characters and objects
**Shading:** 2-tone shading (base color + 1 highlight + 1 shadow)
**Canvas internal resolution:** 1280×720 (logical pixels)

---

## Character Sprites — Male Path (Astronaut)

All character frames are **32×48 pixels** per frame.
Sprite sheets are horizontal strips. Frame 0 is leftmost.

| Sprite | File | Frames | FPS | Total Size | Notes |
|--------|------|--------|-----|------------|-------|
| Idle | `spacesuit_idle.svg` | 4 | 6 | 128×48 | Gentle breathing bob |
| Run | `spacesuit_run.svg` | 8 | 12 | 256×48 | Full run cycle |
| Jump | `spacesuit_jump.svg` | 3 | 8 | 96×48 | Launch → apex → fall |
| Double Jump | (reuses jump sheet) | 3 | 10 | 96×48 | Bigger particle burst differentiates |
| Dash | `spacesuit_dash.svg` | 3 | 14 | 96×48 | Leaning forward, thrusters firing |
| Wall Slide | (reuses jump sheet) | — | — | — | Particle drips differentiate |
| Death | `spacesuit_death.svg` | 6 | 8 | 192×48 | Impact → slump → fall → spark → still |

### Color Palette — Spacesuit

| Color | Hex | Usage |
|-------|-----|-------|
| Suit base | `#6a9ab0` | Main suit body, arms, legs |
| Suit highlight | `#8ab8d4` | Helmet dome |
| Suit shadow | `#3a5a6a` | Gloves, boots |
| Visor | `#0d1f35` | Helmet visor dark |
| Chest panel | `#3de0b0` | Glowing chest instruments |
| Panel accent 1 | `#ffee44` | Indicator light yellow |
| Panel accent 2 | `#44ffff` | Indicator light cyan |
| Thruster | `#80c8ff` | Rocket exhaust glow |

---

## Environment Tiles — Male Path (Ship Interior)

Tiles are **64×64 pixels**.
They tile seamlessly horizontally and vertically.

| Tile | File | Notes |
|------|------|-------|
| Floor | `tile_floor.svg` | Dark metal, teal top edge (walkable surface) |
| Wall | `tile_wall.svg` | Vertical panels, rivets, horizontal seams |
| Ceiling | `tile_ceiling.svg` | Dark with orange hazard stripe on bottom |

### Color Palette — Ship Interior

| Color | Hex | Usage |
|-------|-----|-------|
| Panel base | `#1a2535` | Main wall/floor color |
| Panel shadow | `#0e1825` | Seams, dark edges |
| Panel highlight | `#2a3a4a` | Bevels, top edges |
| Teal accent | `#3af0b0` | Floor top edge, walkable surface indicator |
| Hazard orange | `#cc4400` | Ceiling bottom edge |
| Rivet | `#2a3a4a` | Corner bolt details |

---

## Collectibles

| Asset | File | Size | Notes |
|-------|------|------|-------|
| Common Ring | `ring.svg` | 20×20 | Gold ring, floats and glows |
| Checkpoint Ring | `ring_checkpoint.svg` | 32×32 | Larger gold ring, cross marker inside |
| Door Locked | `door_locked.svg` | 80×120 | Dark metal, red warning light, padlock |
| Door Open | `door_open.svg` | 80×120 | Glowing gold frame, EXIT label |

---

## UI / HUD Elements

| Asset | File | Size | Notes |
|-------|------|------|-------|
| Logo | `logo_ji.svg` | 200×80 | J&I in Pacifico font, white glow |
| Heart Full | `heart_full.svg` | 28×28 | Red filled heart |
| Heart Empty | `heart_empty.svg` | 28×28 | Dark hollow heart |
| Ring Icon | `ring_icon.svg` | 22×22 | Small ring for HUD counter |
| Star Full | `star_full.svg` | 24×24 | Gold 5-point star |
| Star Empty | `star_empty.svg` | 24×24 | Dark hollow star |

---

## Tools Recommended for Final Art

- **Aseprite** ($20 one-time) — industry standard pixel art editor
- **Piskel** (free, browser-based) — simpler alternative
- **LibreSprite** (free, Aseprite fork) — full-featured open source

## AI Image Generation Prompts

For each sprite, use this prompt structure in Midjourney or Adobe Firefly:

```
16-bit SNES pixel art, [SUBJECT], side view, [COLOR_PALETTE],
transparent background, crisp pixels, no anti-aliasing,
game sprite, [FRAME_COUNT] frame animation strip,
dark navy space aesthetic, teal accent lighting
```

Example for idle:
```
16-bit SNES pixel art, astronaut in blue-grey spacesuit idle breathing animation,
side view, teal chest panel glow, dark visor, transparent background,
crisp pixels, 4 frame horizontal strip, 32x48 pixels per frame
```

---

## Upgrade Path

When replacing SVG placeholders with final pixel art:
1. Export from Aseprite as PNG sprite sheets at the exact dimensions above
2. Replace the SVG file with the PNG file in the same folder
3. Update `preloader.js` manifest to use `.png` extensions instead of `.svg`
4. No other code changes needed — the game is built to hot-swap assets

